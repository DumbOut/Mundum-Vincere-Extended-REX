#!/usr/bin/env python3
"""
Rome: Total War ground-type terrain generator.

Fills every pixel of a target colour (default 255,0,170 -- magenta) in an input
.tga with procedurally generated, "very detailed" RTW ground-type terrain, using
ONLY the 14 official ground-type colours. Output is 24-bit, uncompressed TGA:
no alpha, no transparency, no anti-aliasing / colour bleeding. Every generated
pixel is snapped to an exact palette colour.

Workflow for a real map:
    python rtw_terrain_generator.py map_ground_types.tga -o out.tga
    # paint your new landmass in 255,0,170 first; everything else is untouched
    # add --sea-rings to also grade the existing sea around the new coastline

Try it with no input:
    python rtw_terrain_generator.py --demo
"""

import argparse
import os
import sys
import numpy as np

# ----------------------------------------------------------------------------
# Palette (exact RTW ground-type colours, RGB)
# ----------------------------------------------------------------------------
PALETTE = {
    "fertile_low":   (0, 128, 128),    # Grey-Blue
    "fertile_med":   (96, 160, 64),    # Light Green
    "fertile_high":  (101, 124, 0),    # Olive
    "wilderness":    (0, 0, 0),        # Black
    "mtn_high":      (196, 128, 128),  # Light Brown
    "mtn_low":       (98, 65, 65),     # Brown
    "hills":         (128, 128, 64),   # Olive-Brown
    "forest_dense":  (0, 64, 0),       # Dark Green
    "forest_sparse": (0, 128, 0),      # Green
    "swamp":         (0, 255, 128),    # Bright Green
    "ocean":         (64, 0, 0),       # Dark Maroon
    "sea_deep":      (128, 0, 0),      # Dark Red
    "sea_shallow":   (196, 0, 0),      # Red
    "beach":         (255, 255, 255),  # White
}
LABELS = {
    "fertile_low": "Fertile Low", "fertile_med": "Fertile Medium",
    "fertile_high": "Fertile High", "wilderness": "Wilderness",
    "mtn_high": "Mountains High", "mtn_low": "Mountains Low", "hills": "Hills",
    "forest_dense": "Forest Dense", "forest_sparse": "Forest Sparse",
    "swamp": "Swamp", "ocean": "Ocean", "sea_deep": "Sea Deep",
    "sea_shallow": "Sea Shallow", "beach": "Beach",
}
SEA_COLORS = [PALETTE["ocean"], PALETTE["sea_deep"], PALETTE["sea_shallow"]]
PALETTE_ARR = np.array(list(PALETTE.values()), dtype=np.int16)
DEFAULT_TARGET = (255, 0, 170)

try:
    import scipy.ndimage as _ndi
    HAVE_SCIPY = True
except Exception:
    HAVE_SCIPY = False

# ----------------------------------------------------------------------------
# TGA read / write (self-contained, full control over format)
# ----------------------------------------------------------------------------
def _rle_decode(buf, w, h, bpp):
    out = bytearray()
    i = 0
    total = w * h
    count = 0
    while count < total and i < len(buf):
        header = buf[i]; i += 1
        n = (header & 0x7F) + 1
        if header & 0x80:  # run-length packet
            out += bytes(buf[i:i + bpp]) * n
            i += bpp
        else:              # raw packet
            out += bytes(buf[i:i + n * bpp])
            i += n * bpp
        count += n
    arr = np.frombuffer(bytes(out[:total * bpp]), dtype=np.uint8)
    return arr.reshape(h, w, bpp)


def tga_read(path):
    """Return (rgb HxWx3 uint8, top_down_flag). Internal array is top-down."""
    with open(path, "rb") as f:
        data = f.read()
    idlen = data[0]
    cmaptype = data[1]
    imgtype = data[2]
    cmap_len = int.from_bytes(data[5:7], "little")
    cmap_depth = data[7]
    w = int.from_bytes(data[12:14], "little")
    h = int.from_bytes(data[14:16], "little")
    depth = data[16]
    desc = data[17]
    off = 18 + idlen
    if cmaptype == 1:
        off += cmap_len * ((cmap_depth + 7) // 8)
    bpp = depth // 8
    npix = w * h
    if imgtype in (2, 3):
        raw = data[off:off + npix * bpp]
        arr = np.frombuffer(raw, dtype=np.uint8).reshape(h, w, bpp)
    elif imgtype in (10, 11):
        arr = _rle_decode(data[off:], w, h, bpp)
    else:
        raise ValueError(f"Unsupported TGA image type {imgtype} "
                         "(need uncompressed/RLE true-colour or grayscale).")
    if bpp >= 3:
        rgb = arr[:, :, :3][:, :, ::-1].copy()       # BGR(A) -> RGB
    else:
        rgb = np.repeat(arr[:, :, :1], 3, axis=2).copy()
    top_down = bool(desc & 0x20)
    if not top_down:
        rgb = rgb[::-1].copy()                        # store internally top-down
    return rgb, top_down


def tga_write(path, rgb, top_down=False):
    """Write 24-bit uncompressed TGA (BGR, no alpha)."""
    h, w, _ = rgb.shape
    desc = 0x20 if top_down else 0x00                 # bit5 = top-origin
    header = bytes([0, 0, 2, 0, 0, 0, 0, 0])          # id, no cmap, type 2
    header += (0).to_bytes(2, "little") + (0).to_bytes(2, "little")  # x/y origin
    header += w.to_bytes(2, "little") + h.to_bytes(2, "little")
    header += bytes([24, desc])
    rows = rgb if top_down else rgb[::-1]
    bgr = rows[:, :, ::-1]
    with open(path, "wb") as f:
        f.write(header)
        f.write(np.ascontiguousarray(bgr, dtype=np.uint8).tobytes())


# ----------------------------------------------------------------------------
# Distance fields
# ----------------------------------------------------------------------------
def _capped_distance(mask, cap):
    """Chebyshev distance from True pixels to nearest False pixel, capped."""
    cap = int(cap)
    dist = np.full(mask.shape, float(cap), dtype=np.float32)
    dist[~mask] = 0.0
    cur = ~mask
    for i in range(1, cap + 1):
        nxt = cur.copy()
        nxt[1:, :] |= cur[:-1, :]; nxt[:-1, :] |= cur[1:, :]
        nxt[:, 1:] |= cur[:, :-1]; nxt[:, :-1] |= cur[:, 1:]
        nxt[1:, 1:] |= cur[:-1, :-1]; nxt[1:, :-1] |= cur[:-1, 1:]
        nxt[:-1, 1:] |= cur[1:, :-1]; nxt[:-1, :-1] |= cur[1:, 1:]
        newly = nxt & ~cur & mask
        if not newly.any():
            break
        dist[newly] = i
        cur = nxt
    return dist


def dist_to_zero(mask, cap=64):
    """Distance from each True pixel to the nearest False pixel."""
    if HAVE_SCIPY:
        return _ndi.distance_transform_edt(mask).astype(np.float32)
    return _capped_distance(mask, cap)


# ----------------------------------------------------------------------------
# Procedural noise (numpy-only value-noise fBm)
# ----------------------------------------------------------------------------
def _smoothstep(t):
    return t * t * (3.0 - 2.0 * t)


def value_noise(h, w, cell, seed):
    cell = max(2, int(round(cell)))
    gh = h // cell + 2
    gw = w // cell + 2
    rng = np.random.default_rng(seed)
    grid = rng.random((gh, gw)).astype(np.float32)
    ys = np.arange(h) / cell
    xs = np.arange(w) / cell
    y0 = np.floor(ys).astype(int); x0 = np.floor(xs).astype(int)
    fy = _smoothstep(ys - y0)[:, None]
    fx = _smoothstep(xs - x0)[None, :]
    g00 = grid[y0][:, x0]; g01 = grid[y0][:, x0 + 1]
    g10 = grid[y0 + 1][:, x0]; g11 = grid[y0 + 1][:, x0 + 1]
    top = g00 * (1 - fx) + g01 * fx
    bot = g10 * (1 - fx) + g11 * fx
    return top * (1 - fy) + bot * fy


def fbm(h, w, base_cell, octaves, persistence, lacunarity, seed, ridged=False):
    total = np.zeros((h, w), np.float32)
    amp = 1.0; freqcell = float(base_cell); norm = 0.0
    for o in range(octaves):
        v = value_noise(h, w, freqcell, seed + o * 101)
        if ridged:
            v = 1.0 - np.abs(2.0 * v - 1.0)
            v = v * v
        total += v * amp
        norm += amp
        amp *= persistence
        freqcell = max(2.0, freqcell / lacunarity)
    total /= max(norm, 1e-6)
    mn, mx = float(total.min()), float(total.max())
    if mx > mn:
        total = (total - mn) / (mx - mn)
    return total


# ----------------------------------------------------------------------------
# Terrain generation
# ----------------------------------------------------------------------------
def generate(land_mask, seed=1337, scale=None, detail=6, beach_width=2.0,
             mountains=1.0, forests=1.0, fertility=1.0, swamps=1.0, ramp=18.0):
    H, W = land_mask.shape
    ys, xs = np.where(land_mask)
    if len(xs) == 0:
        raise ValueError("No target-colour pixels found; nothing to generate.")
    bb_h = ys.max() - ys.min() + 1
    bb_w = xs.max() - xs.min() + 1
    if scale is None:
        scale = max(6, int(min(bb_h, bb_w) / 10))

    # how far inland each land pixel is -> coasts become lowlands
    cap = int(max(ramp, beach_width) + 2)
    dland = dist_to_zero(land_mask, cap=cap)
    coast_ramp = _smoothstep(np.clip(dland / max(ramp, 1e-3), 0.0, 1.0))

    # noise fields
    elev   = fbm(H, W, scale * 1.0, detail, 0.50, 2.0, seed + 1, ridged=True)
    moist  = fbm(H, W, scale * 1.4, detail, 0.55, 2.0, seed + 2)
    fert   = fbm(H, W, scale * 0.9, detail, 0.50, 2.0, seed + 3)
    regA   = fbm(H, W, scale * 3.0, 3,      0.60, 2.0, seed + 4)  # wet/dry zones
    regB   = fbm(H, W, scale * 3.2, 3,      0.60, 2.0, seed + 5)  # lush/barren zones

    moist = np.clip(0.70 * moist + 0.30 * regA, 0.0, 1.0)
    fert  = np.clip(0.70 * fert + 0.30 * regB, 0.0, 1.0)
    E = elev * coast_ramp                                         # coasts low

    # thresholds (knobs shift them)
    t_mh = 0.80 - 0.12 * (mountains - 1)
    t_ml = 0.66 - 0.12 * (mountains - 1)
    t_h  = 0.54 - 0.10 * (mountains - 1)
    t_fd = 0.70 - 0.12 * (forests - 1)
    t_fs = 0.55 - 0.12 * (forests - 1)
    f_hi = 0.66 - 0.12 * (fertility - 1)
    f_md = 0.42 - 0.12 * (fertility - 1)
    f_lo = 0.20 - 0.10 * (fertility - 1)
    swamp_M = 0.72 - 0.12 * (swamps - 1)
    swamp_band = max(2.0, ramp * 0.6)

    out = np.zeros((H, W, 3), np.uint8)
    L = land_mask
    assigned = np.zeros((H, W), bool)

    def put(cond, color):
        m = L & cond & ~assigned
        out[m] = color
        assigned[m] = True

    # organic beach ring
    beach_noise = value_noise(H, W, max(3, scale // 2), seed + 9)
    put(dland <= (beach_width + (beach_noise - 0.5) * beach_width), PALETTE["beach"])
    # mountains -> hills (ridged elevation gives ranges)
    put(E >= t_mh, PALETTE["mtn_high"])
    put(E >= t_ml, PALETTE["mtn_low"])
    put(E >= t_h,  PALETTE["hills"])
    # swamp: very low, wet, near water
    put((E < 0.10) & (moist > swamp_M) & (dland < swamp_band), PALETTE["swamp"])
    # forests by moisture
    put(moist >= t_fd, PALETTE["forest_dense"])
    put(moist >= t_fs, PALETTE["forest_sparse"])
    # fertile bands -> wilderness for the driest leftovers
    put(fert >= f_hi, PALETTE["fertile_high"])
    put(fert >= f_md, PALETTE["fertile_med"])
    put(fert >= f_lo, PALETTE["fertile_low"])
    put(np.ones((H, W), bool), PALETTE["wilderness"])
    return out


def add_sea_rings(img, land_mask, seed=1337, shallow_w=4.0, deep_w=12.0):
    """Grade EXISTING sea pixels around the new coast: shallow -> deep -> ocean.
    Only pixels already coloured as sea/ocean are touched; land is never altered."""
    H, W = land_mask.shape
    is_sea = np.zeros((H, W), bool)
    for c in SEA_COLORS:
        is_sea |= np.all(img == np.array(c, np.uint8), axis=2)
    cap = int(deep_w + 2)
    dsea = dist_to_zero(~land_mask, cap=cap)          # offshore distance
    n = (value_noise(H, W, 6, seed + 21) - 0.5) * 2.0
    shallow = is_sea & (dsea > 0) & (dsea <= shallow_w + n)
    deep = is_sea & (dsea > shallow_w + n) & (dsea <= deep_w + n)
    img[shallow] = PALETTE["sea_shallow"]
    img[deep] = PALETTE["sea_deep"]
    return img


# ----------------------------------------------------------------------------
# Helpers: snapping, verification, demo, preview
# ----------------------------------------------------------------------------
def snap_to_palette(img):
    flat = img.reshape(-1, 3).astype(np.int16)
    d = ((flat[:, None, :] - PALETTE_ARR[None, :, :]) ** 2).sum(axis=2)
    idx = d.argmin(axis=1)
    return PALETTE_ARR[idx].astype(np.uint8).reshape(img.shape)


def verify_palette_only(img):
    """Return list of (color, count) for any pixel not in the palette."""
    pal = {tuple(c) for c in PALETTE.values()}
    colors, counts = np.unique(img.reshape(-1, 3), axis=0, return_counts=True)
    bad = [(tuple(int(x) for x in c), int(n))
           for c, n in zip(colors, counts) if tuple(int(x) for x in c) not in pal]
    return bad


def make_demo(h, w, seed):
    rng_seed = seed + 50
    img = np.empty((h, w, 3), np.uint8)
    img[:] = PALETTE["ocean"]
    yy, xx = np.mgrid[0:h, 0:w]
    n1 = fbm(h, w, min(h, w) / 6, 5, 0.6, 2.0, rng_seed)
    r1 = np.sqrt(((yy - h * 0.52) / (h * 0.40)) ** 2 +
                 ((xx - w * 0.40) / (w * 0.40)) ** 2)
    land = (1.0 - r1) + (n1 - 0.5) * 0.95 > 0.25
    n2 = fbm(h, w, min(h, w) / 9, 5, 0.6, 2.0, rng_seed + 7)
    r2 = np.sqrt(((yy - h * 0.30) / (h * 0.15)) ** 2 +
                 ((xx - w * 0.78) / (w * 0.15)) ** 2)
    land |= (1.0 - r2) + (n2 - 0.5) * 0.8 > 0.30
    img[land] = DEFAULT_TARGET
    return img


def save_preview(img, path, scale_min=560):
    try:
        from PIL import Image, ImageDraw, ImageFont
    except Exception:
        return None
    h, w, _ = img.shape
    factor = max(1, int(np.ceil(scale_min / max(w, h))))
    big = np.kron(img, np.ones((factor, factor, 1), np.uint8))
    bh, bw, _ = big.shape
    # legend
    sw = 18; pad = 8; cols = 2
    rows = (len(PALETTE) + cols - 1) // cols
    legend_h = rows * (sw + 6) + 2 * pad
    canvas = Image.new("RGB", (bw, bh + legend_h), (28, 28, 30))
    canvas.paste(Image.fromarray(big, "RGB"), (0, 0))
    d = ImageDraw.Draw(canvas)
    try:
        font = ImageFont.truetype(
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 12)
    except Exception:
        font = ImageFont.load_default()
    col_w = bw // cols
    for i, (k, c) in enumerate(PALETTE.items()):
        cx = pad + (i % cols) * col_w
        cy = bh + pad + (i // cols) * (sw + 6)
        d.rectangle([cx, cy, cx + sw, cy + sw], fill=tuple(c),
                    outline=(90, 90, 90))
        d.text((cx + sw + 8, cy + 2),
               f"{LABELS[k]}  ({c[0]},{c[1]},{c[2]})", fill=(225, 225, 225),
               font=font)
    canvas.save(path)
    return path


# ----------------------------------------------------------------------------
# CLI
# ----------------------------------------------------------------------------
def parse_color(s):
    parts = [int(x) for x in s.replace(" ", "").split(",")]
    if len(parts) != 3:
        raise argparse.ArgumentTypeError("colour must be R,G,B")
    return tuple(parts)


def main(argv=None):
    p = argparse.ArgumentParser(
        description="Generate RTW ground-type terrain for target-colour landmasses.")
    p.add_argument("input", nargs="?", help="input .tga path")
    p.add_argument("-o", "--output", help="output .tga path")
    p.add_argument("--target", type=parse_color, default=DEFAULT_TARGET,
                   help="landmass marker colour R,G,B (default 255,0,170)")
    p.add_argument("--tolerance", type=int, default=0,
                   help="max per-channel diff to count as target (default 0=exact)")
    p.add_argument("--seed", type=int, default=1337)
    p.add_argument("--scale", type=float, default=None,
                   help="base feature size in px (default ~landmass/10)")
    p.add_argument("--detail", type=int, default=6, help="fBm octaves")
    p.add_argument("--beach-width", type=float, default=2.0)
    p.add_argument("--ramp", type=float, default=18.0,
                   help="coast->highland transition distance in px")
    p.add_argument("--mountains", type=float, default=1.0)
    p.add_argument("--forests", type=float, default=1.0)
    p.add_argument("--fertility", type=float, default=1.0)
    p.add_argument("--swamps", type=float, default=1.0)
    p.add_argument("--sea-rings", action="store_true",
                   help="grade existing sea around the new coast")
    p.add_argument("--shallow-width", type=float, default=4.0)
    p.add_argument("--deep-width", type=float, default=12.0)
    p.add_argument("--snap-existing", action="store_true",
                   help="snap ALL non-target pixels to nearest palette colour")
    p.add_argument("--demo", action="store_true", help="synthesize a demo input")
    p.add_argument("--demo-size", default="384x256")
    p.add_argument("--outdir", default=".")
    p.add_argument("--no-preview", action="store_true")
    p.add_argument("--list-colors", action="store_true")
    args = p.parse_args(argv)

    if args.list_colors:
        for k, c in PALETTE.items():
            print(f"{LABELS[k]:16s} {c}")
        return 0

    os.makedirs(args.outdir, exist_ok=True)
    top_down = False
    demo_in_path = None

    if args.demo or not args.input:
        dw, dh = (int(x) for x in args.demo_size.lower().split("x"))
        rgb = make_demo(dh, dw, args.seed)
        stem = "demo"
        demo_in_path = os.path.join(args.outdir, "demo_input.tga")
        tga_write(demo_in_path, rgb, top_down)
        print(f"[demo] wrote synthetic input -> {demo_in_path}")
    else:
        rgb, top_down = tga_read(args.input)
        stem = os.path.splitext(os.path.basename(args.input))[0]

    H, W, _ = rgb.shape
    t = np.array(args.target, np.int16)
    if args.tolerance <= 0:
        mask = np.all(rgb == t.astype(np.uint8), axis=2)
    else:
        mask = np.all(np.abs(rgb.astype(np.int16) - t) <= args.tolerance, axis=2)
    n_land = int(mask.sum())
    print(f"[info] image {W}x{H}, target {tuple(args.target)} -> "
          f"{n_land} pixels ({100*n_land/(H*W):.1f}%)")
    if n_land == 0:
        print("[error] no target-colour pixels found. Paint your landmass in "
              f"{tuple(args.target)} (exact) or raise --tolerance.")
        return 2

    terrain = generate(
        mask, seed=args.seed, scale=args.scale, detail=args.detail,
        beach_width=args.beach_width, mountains=args.mountains,
        forests=args.forests, fertility=args.fertility, swamps=args.swamps,
        ramp=args.ramp)

    out = rgb.copy()
    out[mask] = terrain[mask]

    if args.sea_rings:
        out = add_sea_rings(out, mask, seed=args.seed,
                            shallow_w=args.shallow_width, deep_w=args.deep_width)

    if args.snap_existing:
        out = snap_to_palette(out)

    bad = verify_palette_only(out)
    if bad:
        worst = sorted(bad, key=lambda x: -x[1])[:6]
        print(f"[warn] {len(bad)} non-palette colour(s) remain OUTSIDE the "
              "generated area (your input had them). "
              "Use --snap-existing to force palette-only. Sample:")
        for c, n in worst:
            print(f"        {c}: {n} px")
    else:
        print("[ok] every pixel is an exact palette colour (24-bit, no alpha).")

    out_path = args.output or os.path.join(args.outdir, f"{stem}_terrain.tga")
    tga_write(out_path, out, top_down)
    print(f"[done] wrote {out_path}")

    preview_path = None
    if not args.no_preview:
        preview_path = os.path.join(args.outdir, f"{stem}_preview.png")
        if save_preview(out, preview_path) is None:
            preview_path = None
            print("[note] preview skipped (Pillow not available).")
        else:
            print(f"[done] wrote {preview_path}")

    # machine-readable summary for callers
    print("RESULT_OUTPUT=" + out_path)
    if preview_path:
        print("RESULT_PREVIEW=" + preview_path)
    if demo_in_path:
        print("RESULT_DEMO_INPUT=" + demo_in_path)
    return 0


if __name__ == "__main__":
    sys.exit(main())
