# RTW Ground-Type Terrain Generator

Fills every pixel of a marker colour (default `255,0,170`) in a `.tga` with
procedurally generated Rome: Total War ground-type terrain, using **only** the
14 official ground-type colours. Output is **24-bit, uncompressed TGA**: no
alpha, no transparency, no anti-aliasing / colour bleeding. Every generated
pixel is snapped to an exact palette colour, and pixels outside the marked
region are left byte-for-byte untouched.

Requires Python 3 + numpy (scipy and Pillow optional: scipy speeds up distance
maps, Pillow enables the `*_preview.png`).

## Use on your own map

1. Open your ground-types map and paint the **new landmass** in pure `255,0,170`
   (flat fill, no feathering / anti-alias).
2. Run:

```bash
python rtw_terrain_generator.py map_ground_types.tga -o out.tga
# also grade the existing sea around the new coastline:
python rtw_terrain_generator.py map_ground_types.tga -o out.tga --sea-rings
```

## Demo (no input needed)

```bash
python rtw_terrain_generator.py --demo --sea-rings
```

Produces `demo_input.tga`, `demo_terrain.tga`, `demo_preview.png`.

## Key options

| flag | what it does | default |
|---|---|---|
| `--target R,G,B` | marker colour for new land | `255,0,170` |
| `--tolerance N`  | per-channel slack for the marker (0 = exact) | `0` |
| `--seed N`       | change the whole layout | `1337` |
| `--scale N`      | base feature size in px (smaller = busier) | ~landmass/10 |
| `--detail N`     | fBm octaves (higher = finer detail) | `6` |
| `--beach-width N`| coastal beach thickness in px | `2` |
| `--ramp N`       | coast→highland transition distance | `18` |
| `--mountains N`  | more/less mountains (0–2) | `1` |
| `--forests N`    | more/less forest | `1` |
| `--fertility N`  | more/less fertile land | `1` |
| `--swamps N`     | more/less swamp | `1` |
| `--sea-rings`    | grade existing sea: shallow→deep→ocean | off |
| `--shallow-width`, `--deep-width` | sea-ring widths in px | `4`, `12` |
| `--snap-existing`| force the WHOLE image to palette-only | off |
| `--list-colors`  | print the palette and exit | — |

## Guarantees

- Header: image type 2 (uncompressed true-colour), depth 24, descriptor `0x00`
  (alpha bits = 0). No colour-map, exact byte size.
- Output contains only the 14 ground-type colours.
- Land/biome logic: ridged elevation → mountain ranges/hills; coasts forced to
  lowland then a beach ring; moisture → forests/swamp; fertility → fertile
  bands, driest leftovers → wilderness.
