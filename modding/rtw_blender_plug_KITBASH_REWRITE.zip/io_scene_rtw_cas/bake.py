# SPDX-License-Identifier: GPL-3.0-or-later
"""
bake.py
=======
RTW kitbash texture baker.

This version is built for the real Rome: Total War kitbash workflow:
  * keep body / shield / helmet / weapon as SEPARATE mesh objects
  * read each object's existing material texture(s)
  * create one shared atlas image
  * make a new RTW_Atlas UV layer on every object
  * allocate non-overlapping atlas rectangles automatically
  * bake all selected meshes into the same atlas
  * assign one new atlas material to every selected object

It does NOT require joining meshes.  Joining is left as an optional legacy mode,
but the default is multi-object baking.
"""

import os
import math
import bpy
from bpy.props import (StringProperty, EnumProperty, IntProperty,
                       BoolProperty, FloatProperty)

_POT_SIZES = [
    ('128', "128", ""), ('256', "256", ""), ('512', "512", ""),
    ('1024', "1024", ""), ('2048', "2048", ""), ('4096', "4096", ""),
]


def _selected_meshes(context):
    return [o for o in context.selected_objects if o.type == 'MESH' and o.data]


def _active_source_uv(obj):
    if not obj.data.uv_layers:
        return None
    uv = obj.data.uv_layers.active
    if uv and uv.name != "RTW_Atlas":
        return uv.name
    for u in obj.data.uv_layers:
        if u.name != "RTW_Atlas":
            return u.name
    return obj.data.uv_layers.active.name


def _find_basecolor_image_nodes(mat):
    """Return image texture nodes used by a material, preferring Base Color."""
    if not mat or not mat.use_nodes:
        return []
    nt = mat.node_tree
    found = []
    bsdf = next((n for n in nt.nodes if n.type == 'BSDF_PRINCIPLED'), None)
    if bsdf:
        bc = bsdf.inputs.get("Base Color")
        if bc and bc.is_linked:
            src = bc.links[0].from_node
            if src.type == 'TEX_IMAGE' and src.image:
                found.append(src)
    if not found:
        found = [n for n in nt.nodes if n.type == 'TEX_IMAGE' and n.image]
    return found


def _first_source_image(obj):
    for slot in obj.material_slots:
        for n in _find_basecolor_image_nodes(slot.material):
            if n.image:
                return n.image
    return None


def _copy_materials_for_bake(obj):
    """Copy materials so temporary bake nodes do not damage user's originals."""
    originals = [s.material for s in obj.material_slots]
    copies = []
    for i, mat in enumerate(originals):
        if mat:
            cp = mat.copy()
            cp.name = mat.name + "_RTW_bakecopy"
            copies.append(cp)
            obj.material_slots[i].material = cp
        else:
            copies.append(None)
    return originals, copies


def _restore_materials(obj, originals, remove_copies=True):
    for i, mat in enumerate(originals):
        if i < len(obj.material_slots):
            obj.material_slots[i].material = mat
    if remove_copies:
        for m in list(bpy.data.materials):
            if m.name.endswith("_RTW_bakecopy") or "_RTW_bakecopy." in m.name:
                try:
                    bpy.data.materials.remove(m)
                except Exception:
                    pass


def _force_pin_sources_to_uv(obj, src_uv_name):
    """Make source image nodes sample from the object's original UV layer.

    This is critical: during baking the active render UV becomes RTW_Atlas. If
    source images are not explicitly pinned to the old UV layer they sample from
    the new atlas UV and bake garbage/empty textures.
    """
    for slot in obj.material_slots:
        mat = slot.material
        if not mat or not mat.use_nodes:
            continue
        nt = mat.node_tree
        for img_node in _find_basecolor_image_nodes(mat):
            vec_in = img_node.inputs.get("Vector")
            if vec_in is None:
                continue
            # Remove existing Vector links on the bake copy.  Old links often
            # point to the active UV implicitly or to stale UVMap nodes.
            for link in list(vec_in.links):
                nt.links.remove(link)
            uvnode = nt.nodes.new("ShaderNodeUVMap")
            uvnode.uv_map = src_uv_name
            uvnode.location = (img_node.location.x - 220, img_node.location.y)
            nt.links.new(uvnode.outputs["UV"], vec_in)


def _uv_bbox(obj, uv_name):
    uv = obj.data.uv_layers.get(uv_name)
    if not uv:
        return (0.0, 0.0, 1.0, 1.0)
    vals = [luv.uv.copy() for luv in uv.data]
    if not vals:
        return (0.0, 0.0, 1.0, 1.0)
    min_u = min(v.x for v in vals); max_u = max(v.x for v in vals)
    min_v = min(v.y for v in vals); max_v = max(v.y for v in vals)
    if max_u - min_u < 1e-6:
        max_u = min_u + 1.0
    if max_v - min_v < 1e-6:
        max_v = min_v + 1.0
    return (min_u, min_v, max_u, max_v)


def _mesh_weight(obj, uv_name):
    """Heuristic area weight for atlas space.

    Body pieces usually have more faces than shields/weapons, so this stops a
    newly added shield from stealing half the texture.
    """
    poly_count = max(1, len(obj.data.polygons))
    img = _first_source_image(obj)
    img_area = 1024 * 1024
    if img:
        try:
            img_area = max(1, img.size[0] * img.size[1])
        except Exception:
            pass
    min_u, min_v, max_u, max_v = _uv_bbox(obj, uv_name)
    uv_area = max(0.02, min(1.0, (max_u - min_u) * (max_v - min_v)))
    return math.sqrt(poly_count) * math.sqrt(img_area / (1024 * 1024)) * math.sqrt(uv_area)


def _pack_object_rects(items, atlas_size, margin_px):
    """Shelf-pack one rectangle per object.

    Each item is dict with object/src_uv/bbox/weight. Returns rects in UV space.
    It intentionally packs by object, not by face, so meshes remain separate but
    never overlap in atlas UV space.
    """
    usable = atlas_size - margin_px * 2
    total_w = sum(max(0.1, it['weight']) for it in items) or 1.0

    # Initial rectangle dimensions.  Aspect follows each object's original UV
    # bbox so the transferred texture is not squashed.
    rects = []
    total_pixels = usable * usable * 0.78
    for it in items:
        min_u, min_v, max_u, max_v = it['bbox']
        aspect = max(0.1, min(10.0, (max_u - min_u) / max(1e-6, max_v - min_v)))
        area = total_pixels * (max(0.1, it['weight']) / total_w)
        w = int(max(24, math.sqrt(area * aspect)))
        h = int(max(24, math.sqrt(area / aspect)))
        w = min(w, usable); h = min(h, usable)
        rects.append({'item': it, 'w': w, 'h': h})

    # Try packing, scaling down if needed.
    for scale in [1.0, .92, .84, .76, .68, .60, .52, .44, .36, .28, .20]:
        packed = []
        x = margin_px; y = margin_px; shelf_h = 0
        ok = True
        for r in sorted(rects, key=lambda z: z['h'], reverse=True):
            w = max(8, int(r['w'] * scale)); h = max(8, int(r['h'] * scale))
            if x + w + margin_px > atlas_size:
                x = margin_px
                y += shelf_h + margin_px
                shelf_h = 0
            if y + h + margin_px > atlas_size:
                ok = False
                break
            packed.append((r['item'], x, y, w, h))
            x += w + margin_px
            shelf_h = max(shelf_h, h)
        if ok:
            out = {}
            for it, x, y, w, h in packed:
                out[it['obj'].name] = (x / atlas_size, y / atlas_size,
                                       (x + w) / atlas_size, (y + h) / atlas_size)
            return out
    raise RuntimeError("Could not pack selected meshes into atlas; use a larger texture size")


def _write_atlas_uv(obj, src_uv_name, rect):
    me = obj.data
    src = me.uv_layers.get(src_uv_name)
    if not src:
        raise RuntimeError("%s has no source UV layer" % obj.name)
    if "RTW_Atlas" in me.uv_layers:
        me.uv_layers.remove(me.uv_layers["RTW_Atlas"])
    dst = me.uv_layers.new(name="RTW_Atlas")

    min_u, min_v, max_u, max_v = _uv_bbox(obj, src_uv_name)
    ru0, rv0, ru1, rv1 = rect
    su = max(1e-6, max_u - min_u)
    sv = max(1e-6, max_v - min_v)
    rw = ru1 - ru0; rh = rv1 - rv0

    for i, luv in enumerate(src.data):
        u = (luv.uv.x - min_u) / su
        v = (luv.uv.y - min_v) / sv
        # Clamp crazy tiled UVs into the object's allocated rect. RTW unit parts
        # normally use 0..1 UVs; this stops accidental tiling from overlapping.
        u = max(0.0, min(1.0, u)); v = max(0.0, min(1.0, v))
        dst.data[i].uv = (ru0 + u * rw, rv0 + v * rh)

    me.uv_layers.active = dst
    dst.active_render = True
    return dst


def _make_target_image(name, size, alpha):
    img = bpy.data.images.new(name, width=size, height=size, alpha=alpha)
    if alpha:
        img.alpha_mode = 'STRAIGHT'
    # Transparent clear, not black opaque.
    try:
        clear = [0.0] * (size * size * 4)
        img.pixels[:] = clear
    except Exception:
        pass
    return img


def _add_bake_targets(obj, image):
    for slot in obj.material_slots:
        mat = slot.material
        if not mat:
            continue
        if not mat.use_nodes:
            mat.use_nodes = True
        nt = mat.node_tree
        tnode = nt.nodes.new("ShaderNodeTexImage")
        tnode.image = image
        tnode.location = (-700, -400)
        tnode.label = "RTW_BAKE_TARGET"
        for n in nt.nodes:
            n.select = False
        tnode.select = True
        nt.nodes.active = tnode


def _remove_bake_targets(obj):
    for slot in obj.material_slots:
        mat = slot.material
        if not mat or not mat.use_nodes:
            continue
        for n in [n for n in mat.node_tree.nodes if n.label == "RTW_BAKE_TARGET"]:
            mat.node_tree.nodes.remove(n)


def _bake_alpha_into(objects, atlas_image, source_uv_names, size):
    """Bake source image alpha into atlas alpha using emission materials."""
    tmp_img = _make_target_image(atlas_image.name + "_alpha", size, alpha=False)
    saved = []
    try:
        for obj in objects:
            src_uv_name = source_uv_names[obj.name]
            obj_saved = []
            for i, slot in enumerate(obj.material_slots):
                old = slot.material
                obj_saved.append(old)
                tmp = bpy.data.materials.new((old.name if old else obj.name) + "_RTW_alphabake")
                tmp.use_nodes = True
                nt = tmp.node_tree
                nt.nodes.clear()
                out = nt.nodes.new("ShaderNodeOutputMaterial")
                emit = nt.nodes.new("ShaderNodeEmission")
                nt.links.new(emit.outputs["Emission"], out.inputs["Surface"])
                src_imgs = _find_basecolor_image_nodes(old) if old else []
                if src_imgs and src_imgs[0].image:
                    src = nt.nodes.new("ShaderNodeTexImage")
                    src.image = src_imgs[0].image
                    uvn = nt.nodes.new("ShaderNodeUVMap")
                    uvn.uv_map = src_uv_name
                    nt.links.new(uvn.outputs["UV"], src.inputs["Vector"])
                    nt.links.new(src.outputs["Alpha"], emit.inputs["Color"])
                else:
                    emit.inputs["Color"].default_value = (1, 1, 1, 1)
                tnode = nt.nodes.new("ShaderNodeTexImage")
                tnode.image = tmp_img
                for n in nt.nodes:
                    n.select = False
                tnode.select = True
                nt.nodes.active = tnode
                slot.material = tmp
            saved.append((obj, obj_saved))

        bpy.ops.object.bake(type='EMIT')
        ap = list(atlas_image.pixels)
        gp = list(tmp_img.pixels)
        for px in range(0, len(ap), 4):
            ap[px + 3] = gp[px]
        atlas_image.pixels[:] = ap
    finally:
        for obj, mats in saved:
            for i, mat in enumerate(mats):
                if i < len(obj.material_slots):
                    obj.material_slots[i].material = mat
        for m in list(bpy.data.materials):
            if m.name.endswith("_RTW_alphabake") or "_RTW_alphabake." in m.name:
                bpy.data.materials.remove(m)
        try:
            bpy.data.images.remove(tmp_img)
        except Exception:
            pass


def _make_atlas_material(image, name, ext):
    new_mat = bpy.data.materials.new("RTW_" + name)
    new_mat.use_nodes = True
    nt = new_mat.node_tree
    nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputMaterial"); out.location = (300, 0)
    bsdf = nt.nodes.new("ShaderNodeBsdfPrincipled"); bsdf.location = (0, 0)
    tex = nt.nodes.new("ShaderNodeTexImage"); tex.location = (-350, 0)
    tex.image = image
    nt.links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    nt.links.new(tex.outputs["Alpha"], bsdf.inputs["Alpha"])
    nt.links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    new_mat.blend_method = 'CLIP'
    new_mat.use_screen_refraction = False
    new_mat["rtw_texture"] = name + ext
    return new_mat


def _save_image(image, name, out_dir, fmt, save_tga_dds_copy):
    ext = ".tga" if fmt == 'TARGA' else ".png"
    folder = bpy.path.abspath(out_dir) if out_dir else bpy.path.abspath("//")
    if not folder or not os.path.isdir(folder):
        folder = bpy.app.tempdir
    path = os.path.join(folder, name + ext)
    image.filepath_raw = path
    image.file_format = fmt
    image.save()
    # RTW mod folders often use the filename pattern .tga.dds. Blender cannot
    # always encode DDS without external add-ons, so this is only a name copy of
    # the TGA bytes for pipelines that rename/convert later.
    if save_tga_dds_copy and fmt == 'TARGA':
        try:
            import shutil
            shutil.copyfile(path, path + ".dds")
        except Exception as e:
            print("[RTW bake] .tga.dds copy skipped: %s" % e)
    return path, ext


def _assign_atlas_material(objects, atlas_mat, keep_atlas_only):
    for obj in objects:
        obj.data.materials.clear()
        obj.data.materials.append(atlas_mat)
        for poly in obj.data.polygons:
            poly.material_index = 0
        if keep_atlas_only:
            for uv in list(obj.data.uv_layers):
                if uv.name != "RTW_Atlas":
                    obj.data.uv_layers.remove(uv)
            if obj.data.uv_layers.get("RTW_Atlas"):
                obj.data.uv_layers.active = obj.data.uv_layers["RTW_Atlas"]
                obj.data.uv_layers["RTW_Atlas"].active_render = True


class RTW_OT_bake_atlas(bpy.types.Operator):
    """Bake selected kitbashed RTW parts into one shared texture atlas without merging meshes"""
    bl_idname = "rtw.bake_atlas"
    bl_label = "Bake Kitbash Atlas"
    bl_options = {'REGISTER', 'UNDO'}

    asset_name: StringProperty(name="Asset Name", default="new_unit_atlas")
    size: EnumProperty(name="Texture Size", items=_POT_SIZES, default='1024')
    uv_method: EnumProperty(
        name="UV Layout",
        items=[('OBJECT_PACK', "Object atlas pack", "Keep meshes separate; pack each object's used UVs into free atlas space"),
               ('REPACK', "Legacy repack selected object", "Old single-object repack mode"),
               ('SMART', "Legacy Smart UV Project", "Old single-object automatic unwrap"),
               ('LIGHTMAP', "Legacy Lightmap pack", "Old single-object per-face packing")],
        default='OBJECT_PACK')
    join_parts: BoolProperty(name="Join Parts First (legacy)", default=False,
                             description="Legacy mode only. Leave OFF to keep shield/body/weapon separate")
    bake_alpha: BoolProperty(name="Bake Alpha Mask", default=True,
                             description="Carry source alpha into the atlas")
    margin: FloatProperty(name="UV Margin", default=0.03, min=0.0, max=0.2)
    bake_pixel_margin: IntProperty(name="Bleed (px)", default=16, min=0, max=128)
    smart_angle: FloatProperty(name="Smart Angle", default=1.15, min=0.0, max=1.57)
    out_dir: StringProperty(name="Output Folder", subtype='DIR_PATH', default="//")
    file_format: EnumProperty(name="Format", items=[('TARGA', "TGA (RTW)", ""), ('PNG', "PNG", "")], default='TARGA')
    remove_old_materials: BoolProperty(name="Replace Materials", default=True)
    keep_atlas_uv_only: BoolProperty(name="Keep Only Atlas UV", default=True)
    save_tga_dds_copy: BoolProperty(name="Also Save .tga.dds Copy", default=True)

    @classmethod
    def poll(cls, context):
        return any(o.type == 'MESH' for o in context.selected_objects)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=420)

    def draw(self, context):
        lay = self.layout
        lay.prop(self, "asset_name")
        row = lay.row(); row.prop(self, "size"); row.prop(self, "file_format")
        lay.prop(self, "uv_method")
        if self.uv_method in {'SMART'}:
            lay.prop(self, "smart_angle")
        lay.prop(self, "margin")
        lay.prop(self, "bake_pixel_margin")
        lay.prop(self, "join_parts")
        lay.prop(self, "bake_alpha")
        lay.prop(self, "remove_old_materials")
        lay.prop(self, "keep_atlas_uv_only")
        lay.prop(self, "save_tga_dds_copy")
        lay.prop(self, "out_dir")

    def execute(self, context):
        meshes = _selected_meshes(context)
        if not meshes:
            self.report({'ERROR'}, "Select the body/shield/weapon mesh parts first")
            return {'CANCELLED'}
        missing_uv = [o.name for o in meshes if not o.data.uv_layers]
        if missing_uv:
            self.report({'ERROR'}, "These meshes have no UVs: %s" % ", ".join(missing_uv))
            return {'CANCELLED'}

        scene = context.scene
        prev_engine = scene.render.engine
        prev_active = context.view_layer.objects.active
        prev_selection = list(context.selected_objects)
        originals_by_obj = {}
        path = None

        try:
            size_px = int(self.size)
            margin_px = max(2, int(size_px * self.margin))

            # Copy materials and pin source textures to original UVs BEFORE the
            # atlas UV becomes active/rendered.
            source_uv_names = {}
            items = []
            for obj in meshes:
                src_uv = _active_source_uv(obj)
                if not src_uv:
                    raise RuntimeError("%s has no source UV layer" % obj.name)
                source_uv_names[obj.name] = src_uv
                originals_by_obj[obj.name] = _copy_materials_for_bake(obj)
                _force_pin_sources_to_uv(obj, src_uv)
                items.append({'obj': obj, 'src_uv': src_uv,
                              'bbox': _uv_bbox(obj, src_uv),
                              'weight': _mesh_weight(obj, src_uv)})

            if self.uv_method == 'OBJECT_PACK' or not self.join_parts:
                rects = _pack_object_rects(items, size_px, margin_px)
                for it in items:
                    _write_atlas_uv(it['obj'], it['src_uv'], rects[it['obj'].name])
            else:
                # Legacy single-object workflows are kept for old projects, but
                # the new default and recommended path is OBJECT_PACK.
                raise RuntimeError("Legacy joined bake disabled in this build; use Object atlas pack to keep meshes separate")

            image = _make_target_image("RTW_" + self.asset_name + "_atlas", size_px, self.bake_alpha)
            for obj in meshes:
                _add_bake_targets(obj, image)

            scene.render.engine = 'CYCLES'
            try:
                scene.cycles.samples = 1
            except Exception:
                pass
            scene.render.bake.margin = self.bake_pixel_margin
            try:
                scene.render.bake.margin_type = 'EXTEND'
            except Exception:
                pass
            scene.render.bake.use_selected_to_active = False

            for o in context.selected_objects:
                o.select_set(False)
            for obj in meshes:
                obj.select_set(True)
            context.view_layer.objects.active = meshes[0]

            bpy.ops.object.bake(type='DIFFUSE', pass_filter={'COLOR'})

            if self.bake_alpha:
                try:
                    _bake_alpha_into(meshes, image, source_uv_names, size_px)
                except Exception as e:
                    print("[RTW bake] alpha bake skipped: %s" % e)

            for obj in meshes:
                _remove_bake_targets(obj)

            path, ext = _save_image(image, self.asset_name, self.out_dir,
                                    self.file_format, self.save_tga_dds_copy)

            # Restore original materials first, then replace with one atlas mat
            # if requested. If not replacing, leave originals plus atlas UV.
            for obj in meshes:
                originals, copies = originals_by_obj.get(obj.name, ([], []))
                _restore_materials(obj, originals, remove_copies=False)
            if self.remove_old_materials:
                atlas_mat = _make_atlas_material(image, self.asset_name, ext)
                _assign_atlas_material(meshes, atlas_mat, self.keep_atlas_uv_only)
            else:
                for obj in meshes:
                    if self.keep_atlas_uv_only:
                        for uv in list(obj.data.uv_layers):
                            if uv.name != "RTW_Atlas":
                                obj.data.uv_layers.remove(uv)

            # Remove bake copies after they are no longer assigned.
            for m in list(bpy.data.materials):
                if m.name.endswith("_RTW_bakecopy") or "_RTW_bakecopy." in m.name:
                    try:
                        bpy.data.materials.remove(m)
                    except Exception:
                        pass

        except Exception as e:
            for obj in meshes:
                originals, copies = originals_by_obj.get(obj.name, (None, None))
                if originals:
                    _restore_materials(obj, originals, remove_copies=True)
            self.report({'ERROR'}, "Bake failed: %s" % e)
            return {'CANCELLED'}
        finally:
            scene.render.engine = prev_engine
            for o in context.selected_objects:
                o.select_set(False)
            for o in prev_selection:
                try:
                    o.select_set(True)
                except Exception:
                    pass
            if prev_active:
                context.view_layer.objects.active = prev_active

        self.report({'INFO'}, "Baked selected meshes to one shared atlas: %s" % path)
        return {'FINISHED'}


classes = (RTW_OT_bake_atlas,)
