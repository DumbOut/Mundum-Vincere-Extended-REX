import re

def adjust_coordinates(input_file, output_file, dx, dy):
    with open(input_file, 'r') as file:
        lines = file.readlines()

    with open(output_file, 'w') as file:
        for line in lines:
            # Regular expression to find x, y coordinates in the format "fort 4 15"
            match = re.search(r'fort (\-?\d+)\s*(\-?\d+)', line)
            if match:
                # Extract current coordinates
                x = int(match.group(1))
                y = int(match.group(2))
                
                # Apply the adjustment
                x_new = x + dx
                y_new = y + dy
                
                # Replace the old coordinates with the new ones
                new_line = re.sub(r'fort (\-?\d+)\s*(\-?\d+)', f'fort {x_new} {y_new}', line)
                file.write(new_line)
                
            else:
                # If no coordinates are found, just write the line as is
                file.write(line)

# Example usage
input_file = 'descr_strat.txt'  # Your input text file
output_file = 'FORTdescr_strat.txt'  # The output text file
dx = 12  # Adjustment to x coordinates
dy = 0  # Adjustment to y coordinates

adjust_coordinates(input_file, output_file, dx, dy)
