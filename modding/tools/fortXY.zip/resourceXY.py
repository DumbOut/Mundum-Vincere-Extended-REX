import re

def adjust_coordinates(input_file, output_file, dx, dy):
    with open(input_file, 'r') as file:
        lines = file.readlines()

    with open(output_file, 'w') as file:
        for line in lines:
            match = re.search(r'(\-?\d+),\s*(\-?\d+)', line)
            # Regular expression to find x, y coordinates in the format "4, 15"
            if match:
                # Extract current coordinates
                x = int(match.group(1))
                y = int(match.group(2))
                
                # Apply the adjustment
                x_new = x + dx
                y_new = y + dy
                
                # Replace the old coordinates with the new ones
                new_line = re.sub(r'(\-?\d+),\s*(\-?\d+)', f'{x_new}, {y_new}', line)
                file.write(new_line)
                
            else:
                # If no coordinates are found, just write the line as is
                file.write(line)

# Example usage
input_file = 'resource.txt'  # Your input text file
output_file = 'NEWresource.txt'  # The output text file
dx = 37  # Adjustment to x coordinates
dy = 0  # Adjustment to y coordinates

adjust_coordinates(input_file, output_file, dx, dy)
