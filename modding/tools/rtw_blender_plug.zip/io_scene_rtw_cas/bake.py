# SPDX-License-Identifier: GPL-3.0-or-later
"""
bake.py
=======
Kitbash baker: turn several differently-textured meshes (e.g. shield rim from
unit A + boss from unit B + face plate from unit C) into ONE clean Rome: Total
War style asset — a single square power-of-two diffuse .tga with one packed UV
layout — without manually re-puzzling UVs in Photoshop.

How it works (texture-transfer bake):
  1. (optional) Join the selected parts into one mesh. Because parts usually
     share the UV-layer name "UVMap", joining merges them into one layer where
     every part still holds ITS OWN original coordinates on its own faces.
  2. Add a new UV layer "RTW_Atlas" and pack all islands into it cleanly
     (repack existing islands, Smart UV Project, or lightmap pack).
  3. Pin every source image texture to the ORIGINAL UV layer (via a UV Map
     node) so the bake reads each part's texture from the right place.
  4. Create one target image, add it to each material as the bake target, set
     "RTW_Atlas" as the active UV, and bake the DIFFUSE colour (lighting-free)
     into it. Optionally bake the combined alpha mask too.
  5. Save as .tga, build one clean material that uses the atlas, assign it, and
     (optionally) drop the old materials/UVs.

Note: baking uses Cycles and a real render context, so it must run inside
Blender; it can't be exercised head-less. The logic is defensive and restores
render settings afterwards.
"""

import os
import bpy
from bpy.props import (StringProperty, EnumProperty, IntProperty,
                       BoolProperty, FloatProperty)

_POT_SIZES = [
    ('128', "128", ""), ('256', "256", ""), ('512', "512", ""),
    ('1024', "1024", ""), ('2048', "2048", ""),
]


def _selected_meshes(context):
    return [o for o in context.selected_objects if o.type == 'MESH']


def _find_basecolor_image_nodes(mat):
    """Yield image-texture nodes that feed (directly) the Principled Base Color."""
    if not mat or not mat.use_nodes:
        return []
    nt = mat.node_tree
    bsdf = next((n for n in nt.nodes if n.type == 'BSDF_PRINCIPLED'), None)
    found = []
    if bsdf:
        bc = bsdf.inputs.get("Base Color")
        if bc and bc.is_linked:
            src = bc.links[0].from_node
            if src.type == 'TEX_IMAGE' and src.image:
                found.append(src)
    # fall back: any image node in the tree
    if not found:
        found = [n for n in nt.nodes if n.type == 'TEX_IMAGE' and n.image]
    return found


def _pin_sources_to_uv(obj, src_uv_name):
    """Ensure each source image node samples via the original UV layer."""
    for slot in obj.material_slots:
        mat = slot.material
        if not mat or not mat.use_nodes:
            continue
        nt = mat.node_tree
        for img_node in _find_basecolor_image_nodes(mat):
            vec_in = img_node.inputs.get("Vector")
            if vec_in is None or vec_in.is_linked:
                continue
            uvnode = nt.nodes.new("ShaderNodeUVMap")
            uvnode.uv_map = src_uv_name
            uvnode.location = (img_node.location.x - 220, img_node.location.y)
            nt.links.new(uvnode.outputs["UV"], vec_in)


def _ensure_atlas_uv(obj, method, margin, angle_limit, context):
    me = obj.data
    if "RTW_Atlas" in me.uv_layers:
        me.uv_layers.remove(me.uv_layers["RTW_Atlas"])
    atlas = me.uv_layers.new(name="RTW_Atlas")
    me.uv_layers.active = atlas
    atlas.active_render = True

    context.view_layer.objects.active = obj
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')
    try:
        if method == 'SMART':
            bpy.ops.uv.smart_project(angle_limit=angle_limit,
                                     island_margin=margin)
        elif method == 'LIGHTMAP':
            bpy.ops.uv.lightmap_pack(PREF_MARGIN_DIV=max(0.1, margin * 10))
        else:  # REPACK — keep island shapes, just average + pack them together
            bpy.ops.uv.select_all(action='SELECT')
            try:
                bpy.ops.uv.average_islands_scale()
            except Exception:
                pass
            bpy.ops.uv.pack_islands(margin=margin)
    finally:
        bpy.ops.object.mode_set(mode='OBJECT')
    return atlas


def _make_target_image(name, size, alpha):
    img = bpy.data.images.new(name, width=size, height=size, alpha=alpha)
    if alpha:
        img.alpha_mode = 'STRAIGHT'
    return img


def _add_bake_targets(obj, image):
    """Add the target image node to every material and make it the active node."""
    for slot in obj.material_slots:
        mat = slot.material
        if not mat:
            continue
        if not mat.use_nodes:
            mat.use_nodes = True
        nt = mat.node_tree
        tnode = nt.nodes.new("ShaderNodeTexImage")
        tnode.image = image
        tnode.location = (-700, -400)
        tnode.label = "RTW_BAKE_TARGET"
        for n in nt.nodes:
            n.select = False
        tnode.select = True
        nt.nodes.active = tnode


def _remove_bake_targets(obj):
    for slot in obj.material_slots:
        mat = slot.material
        if not mat or not mat.use_nodes:
            continue
        for n in [n for n in mat.node_tree.nodes if n.label == "RTW_BAKE_TARGET"]:
            mat.node_tree.nodes.remove(n)


def _bake_alpha_into(obj, atlas_image, src_uv_name, size, context):
    """Best-effort: bake each material's source ALPHA into the atlas alpha."""
    tmp_img = _make_target_image(atlas_image.name + "_A", size, alpha=False)
    saved = []  # (slot_index, original_material)
    try:
        for i, slot in enumerate(obj.material_slots):
            mat = slot.material
            saved.append((i, mat))
            tmp = bpy.data.materials.new(mat.name + "_alphabake" if mat else "ab")
            tmp.use_nodes = True
            nt = tmp.node_tree
            nt.nodes.clear()
            out = nt.nodes.new("ShaderNodeOutputMaterial")
            emit = nt.nodes.new("ShaderNodeEmission")
            nt.links.new(emit.outputs["Emission"], out.inputs["Surface"])
            # source alpha
            src_imgs = _find_basecolor_image_nodes(mat) if mat else []
            if src_imgs and src_imgs[0].image:
                src = nt.nodes.new("ShaderNodeTexImage")
                src.image = src_imgs[0].image
                uvn = nt.nodes.new("ShaderNodeUVMap")
                uvn.uv_map = src_uv_name
                nt.links.new(uvn.outputs["UV"], src.inputs["Vector"])
                nt.links.new(src.outputs["Alpha"], emit.inputs["Color"])
            else:
                emit.inputs["Color"].default_value = (1, 1, 1, 1)
            tnode = nt.nodes.new("ShaderNodeTexImage")
            tnode.image = tmp_img
            for n in nt.nodes:
                n.select = False
            tnode.select = True
            nt.nodes.active = tnode
            slot.material = tmp

        bpy.ops.object.bake(type='EMIT')

        # Merge grayscale bake into atlas alpha channel.
        ap = list(atlas_image.pixels)
        gp = list(tmp_img.pixels)
        for px in range(0, len(ap), 4):
            ap[px + 3] = gp[px]  # red of grayscale -> alpha
        atlas_image.pixels[:] = ap
    finally:
        for i, mat in saved:
            obj.material_slots[i].material = mat
        for m in list(bpy.data.materials):
            if m.name.endswith("_alphabake"):
                bpy.data.materials.remove(m)
        bpy.data.images.remove(tmp_img)


def _finalize(obj, image, name, remove_old, keep_atlas_only, out_dir, fmt):
    # Save the baked image.
    ext = ".tga" if fmt == 'TARGA' else ".png"
    folder = bpy.path.abspath(out_dir) if out_dir else bpy.path.abspath("//")
    if not folder or not os.path.isdir(folder):
        folder = bpy.app.tempdir
    path = os.path.join(folder, name + ext)
    image.filepath_raw = path
    image.file_format = fmt
    try:
        image.save()
    except Exception as e:
        print("[RTW bake] could not save image: %s" % e)

    # Build one clean RTW-style material on the atlas.
    new_mat = bpy.data.materials.new("RTW_" + name)
    new_mat.use_nodes = True
    nt = new_mat.node_tree
    nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputMaterial"); out.location = (300, 0)
    bsdf = nt.nodes.new("ShaderNodeBsdfPrincipled"); bsdf.location = (0, 0)
    tex = nt.nodes.new("ShaderNodeTexImage"); tex.location = (-350, 0)
    tex.image = image
    nt.links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    nt.links.new(tex.outputs["Alpha"], bsdf.inputs["Alpha"])
    nt.links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    new_mat.blend_method = 'CLIP'
    new_mat["rtw_texture"] = name + ext

    if remove_old:
        obj.data.materials.clear()
    obj.data.materials.append(new_mat)
    # point all faces at the new (last) material
    for poly in obj.data.polygons:
        poly.material_index = len(obj.data.materials) - 1

    if keep_atlas_only:
        for uv in list(obj.data.uv_layers):
            if uv.name != "RTW_Atlas":
                obj.data.uv_layers.remove(uv)
    return path


class RTW_OT_bake_atlas(bpy.types.Operator):
    """Repack UVs of kitbashed parts and bake their textures into one clean RTW diffuse"""
    bl_idname = "rtw.bake_atlas"
    bl_label = "Bake Kitbash Atlas"
    bl_options = {'REGISTER', 'UNDO'}

    asset_name: StringProperty(name="Asset Name", default="new_shield")
    size: EnumProperty(name="Texture Size", items=_POT_SIZES, default='512')
    uv_method: EnumProperty(
        name="UV Layout",
        items=[('REPACK', "Repack islands", "Keep island shapes, just pack them (best texel match)"),
               ('SMART', "Smart UV Project", "Fresh automatic unwrap"),
               ('LIGHTMAP', "Lightmap pack", "Per-face packing")],
        default='REPACK')
    join_parts: BoolProperty(name="Join Parts First", default=True,
                             description="Merge selected meshes into one asset")
    bake_alpha: BoolProperty(name="Bake Alpha Mask", default=True,
                            description="Carry source alpha into the atlas (RTW masking)")
    margin: FloatProperty(name="UV Margin", default=0.02, min=0.0, max=0.2)
    bake_pixel_margin: IntProperty(name="Bleed (px)", default=8, min=0, max=64,
                                  description="Edge padding to avoid seam bleed")
    smart_angle: FloatProperty(name="Smart Angle", default=1.15, min=0.0, max=1.57)
    out_dir: StringProperty(name="Output Folder", subtype='DIR_PATH', default="//")
    file_format: EnumProperty(
        name="Format",
        items=[('TARGA', "TGA (RTW)", ""), ('PNG', "PNG", "")], default='TARGA')
    remove_old_materials: BoolProperty(name="Replace Materials", default=True)
    keep_atlas_uv_only: BoolProperty(name="Keep Only Atlas UV", default=True)

    @classmethod
    def poll(cls, context):
        return any(o.type == 'MESH' for o in context.selected_objects)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=360)

    def draw(self, context):
        lay = self.layout
        lay.prop(self, "asset_name")
        row = lay.row(); row.prop(self, "size"); row.prop(self, "file_format")
        lay.prop(self, "uv_method")
        if self.uv_method == 'SMART':
            lay.prop(self, "smart_angle")
        lay.prop(self, "margin")
        lay.prop(self, "bake_pixel_margin")
        lay.prop(self, "join_parts")
        lay.prop(self, "bake_alpha")
        lay.prop(self, "remove_old_materials")
        lay.prop(self, "keep_atlas_uv_only")
        lay.prop(self, "out_dir")

    def execute(self, context):
        meshes = _selected_meshes(context)
        if not meshes:
            self.report({'ERROR'}, "Select the kitbash mesh parts first")
            return {'CANCELLED'}

        scene = context.scene
        prev_engine = scene.render.engine
        prev_active = context.view_layer.objects.active

        # --- combine parts -------------------------------------------------
        if self.join_parts and len(meshes) > 1:
            for o in meshes:
                o.select_set(True)
            context.view_layer.objects.active = meshes[0]
            try:
                bpy.ops.object.join()
            except Exception as e:
                self.report({'ERROR'}, "Join failed: %s" % e)
                return {'CANCELLED'}
            obj = context.view_layer.objects.active
        else:
            obj = context.active_object if context.active_object in meshes else meshes[0]

        if not obj.data.uv_layers:
            self.report({'ERROR'}, "Parts have no UVs to transfer")
            return {'CANCELLED'}

        # Remember the original (merged) source UV name before adding the atlas.
        src_uv_name = obj.data.uv_layers.active.name
        if src_uv_name == "RTW_Atlas" and len(obj.data.uv_layers) > 1:
            src_uv_name = next(u.name for u in obj.data.uv_layers
                               if u.name != "RTW_Atlas")

        size_px = int(self.size)

        try:
            scene.render.engine = 'CYCLES'
            scene.render.bake.margin = self.bake_pixel_margin
            try:
                scene.render.bake.margin_type = 'EXTEND'
            except Exception:
                pass
            scene.render.bake.use_selected_to_active = False

            _pin_sources_to_uv(obj, src_uv_name)
            _ensure_atlas_uv(obj, self.uv_method, self.margin,
                             self.smart_angle, context)

            image = _make_target_image("RTW_" + self.asset_name + "_atlas",
                                       size_px, alpha=self.bake_alpha)
            _add_bake_targets(obj, image)

            # isolate selection for bake
            for o in context.selected_objects:
                o.select_set(False)
            obj.select_set(True)
            context.view_layer.objects.active = obj

            bpy.ops.object.bake(type='DIFFUSE', pass_filter={'COLOR'})

            if self.bake_alpha:
                try:
                    _add_bake_targets(obj, image)  # ensure target still active
                    _bake_alpha_into(obj, image, src_uv_name, size_px, context)
                except Exception as e:
                    print("[RTW bake] alpha bake skipped: %s" % e)

            _remove_bake_targets(obj)
            path = _finalize(obj, image, self.asset_name,
                             self.remove_old_materials, self.keep_atlas_uv_only,
                             self.out_dir, self.file_format)
        except Exception as e:
            self.report({'ERROR'}, "Bake failed: %s" % e)
            return {'CANCELLED'}
        finally:
            scene.render.engine = prev_engine
            if prev_active:
                context.view_layer.objects.active = prev_active

        self.report({'INFO'}, "Baked %s (%dx%d) -> %s"
                     % (self.asset_name, size_px, size_px, path))
        return {'FINISHED'}


classes = (RTW_OT_bake_atlas,)
