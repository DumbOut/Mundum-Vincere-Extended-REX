# SPDX-License-Identifier: GPL-3.0-or-later
"""
skeletons.py
============
Built-in bind-pose tables for the standard Rome: Total War skeletons.

WHY THIS EXISTS
A model .cas stores every vertex relative to its bind bone, but it does NOT
store where the bones actually are (the bind pose lives in the external
skeleton .dat). Without the bind pose, a bare .cas cannot be placed in world
space by ANY tool.

RTW units, however, share a small number of standard skeletons, and every .cas
lists its bone names. So we ship bind-pose tables keyed by the set of bone
names. Given a .cas, we match its bone-name set to a known skeleton and use
those world-space bind translations to reconstruct the model — for any unit
that uses that skeleton, no per-file sidecar needed.

Each table maps bone_name -> (x, y, z) WORLD bind translation (Y-up).
Derived from a verified reference (gaul_revenger / fs_semi_naked family).

To add more skeletons: import one reference unit that uses it (with a glTF
sidecar once), run the "Inspect .cas Header" / a quick export of the bind
positions, and paste a new table here keyed by its bone names. The matcher will
pick it up automatically.
"""

# --------------------------------------------------------------------------- #
SKELETON_FS_SEMI_NAKED = {
    "Scene Root": (0.0, 0.0, 0.0),
    "bone_pelvis": (0.0, 0.0, 0.0),
    "bone_RThigh": (0.09524, 0.00075, -0.0),
    "bone_Rlowerleg": (0.11865, -0.46385, 0.005),
    "bone_Rfoot": (0.14181, -0.86448, 0.0174),
    "bone_abs": (-0.0, 0.21246, -0.0),
    "bone_torso": (-0.00029, 0.42402, -0.0),
    "bone_head": (-0.00036, 0.65899, -0.0),
    "bone_cloak_top": (0.00372, 0.33969, 0.20399),
    "bone_cloak_mid": (0.00372, 0.0794, 0.27373),
    "bone_cloak_bottom": (0.00372, -0.18063, 0.34341),
    "bone_Rupperarm": (0.17832, 0.50225, 0.0239),
    "bone_Relbow": (0.48053, 0.51334, 0.03769),
    "bone_Rhand": (0.76436, 0.51033, 0.01133),
    "bone_Lupperarm": (-0.17832, 0.50225, 0.0239),
    "bone_Lelbow": (-0.48053, 0.51334, 0.03769),
    "bone_Lhand": (-0.76436, 0.51033, 0.01133),
    "bone_LThigh": (-0.09524, 0.00075, -0.0),
    "bone_Llowerleg": (-0.11865, -0.46385, 0.005),
    "bone_Lfoot": (-0.14181, -0.86448, 0.0174),
}

# Registry of all known skeletons (extend freely).
KNOWN_SKELETONS = {
    "fs_semi_naked": SKELETON_FS_SEMI_NAKED,
}


def match_skeleton(bone_names):
    """Return (skeleton_name, bind_dict) whose bone set best matches the file's
    bones, or (None, None) if nothing matches well enough.

    A file may legitimately carry MORE bones than a table (weapon / shield /
    finger bones) or FEWER (a stripped LOD). Judging only by the fraction of the
    *file's* bones that are recognised punished the extra-bone case and made the
    importer fall back to the scattered auto-layout. We therefore score with
    both recall (how much of the table the file covers) and precision (how much
    of the file the table explains) and accept a strong match on either axis,
    as long as a meaningful number of bones overlap."""
    file_set = set(bone_names)
    best = None
    for sk_name, table in KNOWN_SKELETONS.items():
        table_set = set(table.keys())
        common = file_set & table_set
        ncommon = len(common)
        if ncommon == 0:
            continue
        recall = ncommon / max(1, len(table_set))
        precision = ncommon / max(1, len(file_set))
        score = (ncommon, recall + precision)
        if best is None or score > best[0]:
            best = (score, ncommon, recall, precision, sk_name, table)
    if best:
        _score, ncommon, recall, precision, sk_name, table = best
        if ncommon >= 6 and (recall >= 0.5 or precision >= 0.6):
            return sk_name, table
    return None, None


def bind_positions_for(bone_names):
    """Return a list of (x,y,z) world bind positions aligned to *bone_names*,
    or None if no skeleton matches. Unknown bones fall back to their parent's
    position (caller passes resolved order)."""
    sk_name, table = match_skeleton(bone_names)
    if not table:
        return None, None
    out = []
    for nm in bone_names:
        out.append(table.get(nm))
    return sk_name, out
