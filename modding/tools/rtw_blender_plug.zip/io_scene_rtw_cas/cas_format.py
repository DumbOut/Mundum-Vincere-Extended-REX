# SPDX-License-Identifier: GPL-3.0-or-later
"""
cas_format.py
=============
Reader / writer for Rome: Total War ".cas" files. Single point of truth for
on-disk bytes.

This version was reconciled against a real vanilla file (gaul_revenger.cas):

VERIFIED vanilla layout (RTW "Full" model, version ~3.18):
  * offset 0x00 : float32 version (e.g. 3.18)
  * a parent-index array of (numBones-1) int32 values early in the header; each
    entry is the parent bone index of bone (k+1); the root (bone 0) is omitted.
  * bone names stored later as: int32 length (INCLUDING the null terminator),
    then `length` bytes (latin-1, last byte = 0x00). The original parser's bug
    was treating the length as excluding the terminator, which desynced and
    produced the "implausible string length" crash.
  * mesh group / object / texture names use the same length-prefix-incl-null.
  * bone BIND POSITIONS are NOT stored in the model file (RTW takes the bind
    pose from the external skeleton .dat); the per-bone slots are zero here.
  * full mesh vertex/face/uv chunk layout and embedded-animation frames vary by
    file/version and are not yet byte-decoded from a single sample.

Because of the above, `read_model` runs in two modes:
  * If the file is one WE exported, it carries the MAGIC tag right after the
    version float and is read back exactly (full geometry + animation
    round-trip — this is the FBX-like Blender<->cas workflow).
  * Otherwise it is treated as a vanilla file and parsed defensively: version,
    bones (names + hierarchy) and group/texture names are extracted robustly and
    NEVER crash; geometry that can't be safely decoded is left empty and flagged
    in `model.notes` / `model.partial` instead of raising.

To extend vanilla geometry decoding, share an IWTE/casconv-converted reference
of the same file and adjust ONLY this module.
"""

import struct
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

RTW_ANIM_FPS = 20
NO_PARENT = -1
TYPE3_MARKER = 3

# Tag written right after the version float in files THIS add-on exports, so we
# can read our own full-fidelity format back without guessing.
MAGIC = b"CASB"


# --------------------------------------------------------------------------- #
#  Data containers
# --------------------------------------------------------------------------- #
@dataclass
class CasBone:
    name: str
    parent: int = NO_PARENT
    translation: Tuple[float, float, float] = (0.0, 0.0, 0.0)
    rotation: Tuple[float, ...] = (1, 0, 0, 0, 1, 0, 0, 0, 1)


@dataclass
class CasVertex:
    co: Tuple[float, float, float]
    normal: Tuple[float, float, float] = (0.0, 0.0, 1.0)
    uv: Tuple[float, float] = (0.0, 0.0)
    bone0: int = 0
    weight0: float = 1.0
    bone1: int = -1
    weight1: float = 0.0


@dataclass
class CasGroup:
    name: str = "group"
    texture: str = ""
    is_type3: bool = False
    vertices: List[CasVertex] = field(default_factory=list)
    faces: List[Tuple[int, int, int]] = field(default_factory=list)


@dataclass
class CasAnimFrame:
    rotations: List[Tuple[float, ...]] = field(default_factory=list)
    translations: Optional[List[Tuple[float, float, float]]] = None


@dataclass
class CasAnimation:
    fps: int = RTW_ANIM_FPS
    frames: List[CasAnimFrame] = field(default_factory=list)
    bones_with_position: List[bool] = field(default_factory=list)


@dataclass
class CasModel:
    version: float = 3.18
    bones: List[CasBone] = field(default_factory=list)
    groups: List[CasGroup] = field(default_factory=list)
    animation: Optional[CasAnimation] = None
    embedded_texture: Optional[bytes] = None
    # Set when the file was parsed in defensive vanilla mode and some data
    # (typically geometry) could not be byte-decoded.
    partial: bool = False
    notes: List[str] = field(default_factory=list)


# --------------------------------------------------------------------------- #
#  Binary primitives
# --------------------------------------------------------------------------- #
class _Reader:
    __slots__ = ("buf", "pos")

    def __init__(self, data):
        self.buf = data
        self.pos = 0

    def remaining(self):
        return len(self.buf) - self.pos

    def _take(self, n):
        if self.pos + n > len(self.buf):
            raise EOFError("read past end")
        b = self.buf[self.pos:self.pos + n]
        self.pos += n
        return b

    def f32(self):
        return struct.unpack("<f", self._take(4))[0]

    def i32(self):
        return struct.unpack("<i", self._take(4))[0]

    def f32n(self, n):
        return struct.unpack("<%df" % n, self._take(4 * n))

    def string_no_null(self):
        n = self.i32()
        if n < 0 or n > 8192:
            raise ValueError("bad string length %d" % n)
        return self._take(n).decode("latin-1")


class _Writer:
    __slots__ = ("parts",)

    def __init__(self):
        self.parts = []

    def f32(self, v):
        self.parts.append(struct.pack("<f", float(v)))

    def i32(self, v):
        self.parts.append(struct.pack("<i", int(v)))

    def f32n(self, vals):
        self.parts.append(struct.pack("<%df" % len(vals), *[float(x) for x in vals]))

    def string_no_null(self, s):
        raw = s.encode("latin-1", "replace")
        self.i32(len(raw))
        self.parts.append(raw)

    def raw(self, b):
        self.parts.append(b)

    def getvalue(self):
        return b"".join(self.parts)


# --------------------------------------------------------------------------- #
#  Public API
# --------------------------------------------------------------------------- #
def read_model(data: bytes) -> CasModel:
    """Read a .cas file. Auto-detects our own exports vs vanilla files.

    This function never raises: any unexpected problem degrades to a defensive
    extraction (or an empty model with the error recorded in `notes`), so the
    importer can always report something useful instead of failing."""
    try:
        if len(data) >= 8 and data[4:8] == MAGIC:
            return _read_structured(data)
    except Exception as e:
        # Our own format failed unexpectedly; fall through to vanilla scan.
        try:
            m = _extract_vanilla(data)
            m.notes.insert(0, "Structured read failed (%s); used defensive "
                              "scan instead." % e)
            return m
        except Exception:
            pass
    try:
        return _extract_vanilla(data)
    except Exception as e:
        m = CasModel(partial=True)
        m.notes.append("Could not parse this .cas (%s). The file may be an "
                       "unpacked animation or an unsupported variant." % e)
        return m


def write_model(model: CasModel) -> bytes:
    """Write our own full-fidelity format (round-trips in Blender)."""
    w = _Writer()
    w.f32(model.version)
    w.raw(MAGIC)
    w.i32(len(model.bones))
    for b in model.bones:
        w.string_no_null(b.name)
        w.i32(b.parent)
        w.f32n(b.translation)
        w.f32n(b.rotation)
    w.i32(len(model.groups))
    for g in model.groups:
        w.i32(TYPE3_MARKER if g.is_type3 else 0)
        w.string_no_null(g.name)
        w.string_no_null(g.texture)
        w.i32(len(g.vertices))
        for v in g.vertices:
            w.f32n(v.co)
            w.f32n(v.normal)
            w.f32n(v.uv)
            w.i32(v.bone0)
            w.f32(v.weight0)
            w.i32(v.bone1)
            w.f32(v.weight1)
        w.i32(len(g.faces))
        for (a, b_, c) in g.faces:
            w.i32(a)
            w.i32(b_)
            w.i32(c)
    if model.animation is not None:
        w.i32(1)
        _write_anim_block(w, model.animation, len(model.bones))
    else:
        w.i32(0)
    if model.embedded_texture:
        w.i32(len(model.embedded_texture))
        w.raw(model.embedded_texture)
    else:
        w.i32(0)
    return w.getvalue()


# --------------------------------------------------------------------------- #
#  Structured (our own exports) read
# --------------------------------------------------------------------------- #
def _read_structured(data: bytes) -> CasModel:
    r = _Reader(data)
    m = CasModel()
    m.version = r.f32()
    assert r._take(4) == MAGIC
    for _ in range(r.i32()):
        name = r.string_no_null()
        parent = r.i32()
        trans = r.f32n(3)
        rot = r.f32n(9)
        m.bones.append(CasBone(name, parent, trans, rot))
    for _ in range(r.i32()):
        marker = r.i32()
        g = CasGroup(is_type3=(marker == TYPE3_MARKER))
        g.name = r.string_no_null()
        g.texture = r.string_no_null()
        for _v in range(r.i32()):
            co = r.f32n(3)
            nrm = r.f32n(3)
            uv = r.f32n(2)
            b0 = r.i32()
            w0 = r.f32()
            b1 = r.i32()
            w1 = r.f32()
            g.vertices.append(CasVertex(co, nrm, uv, b0, w0, b1, w1))
        for _fc in range(r.i32()):
            g.faces.append((r.i32(), r.i32(), r.i32()))
        m.groups.append(g)
    if r.remaining() >= 4 and r.i32() == 1:
        m.animation = _read_anim_block(r, len(m.bones))
    if r.remaining() >= 4:
        sz = r.i32()
        if 0 < sz <= r.remaining():
            m.embedded_texture = r._take(sz)
    return m


# --------------------------------------------------------------------------- #
#  Vanilla defensive extraction
# --------------------------------------------------------------------------- #
def _length_prefixed_strings(data: bytes):
    """All (offset, text) where int32 length INCLUDES the null terminator."""
    out = []
    o = 0
    n = len(data)
    while o + 4 < n:
        L = struct.unpack("<i", data[o:o + 4])[0]
        if 2 <= L <= 64 and o + 4 + L <= n:
            b = data[o + 4:o + 4 + L]
            if b[-1] == 0 and all(32 <= c < 127 for c in b[:-1]):
                out.append((o, b[:-1].decode("latin-1")))
                o += 4 + L
                continue
        o += 1
    return out


def _scan_texture_path(data: bytes) -> str:
    """Find any printable run containing a texture extension; return basename."""
    run = bytearray()
    start = 0
    candidates = []
    for idx, b in enumerate(data):
        if 32 <= b < 127:
            if not run:
                start = idx
            run.append(b)
        else:
            if len(run) >= 5:
                candidates.append(run.decode("latin-1"))
            run = bytearray()
    if len(run) >= 5:
        candidates.append(run.decode("latin-1"))
    for s in candidates:
        sl = s.lower()
        for ext in (".tga", ".dds"):
            if ext in sl:
                frag = s[:sl.index(ext) + 4]
                return frag.replace("\\", "/").split("/")[-1]
    return ""


def _is_bone_name(s: str) -> bool:
    sl = s.lower()
    return sl == "scene root" or sl.startswith("bone")


def _find_parent_array(data: bytes, nb: int):
    """Locate the (nb-1)-entry int32 parent array. Disambiguate overlapping
    valid runs by choosing the one with the fewest root-children (parents==0)."""
    if nb < 2:
        return None
    best = None
    n = len(data)
    for start in range(4, min(0x400, n - 4 * (nb - 1)), 4):
        vals = []
        ok = True
        for k in range(nb - 1):
            v = struct.unpack("<i", data[start + 4 * k:start + 4 * k + 4])[0]
            if not (0 <= v < nb and v <= k):   # parent index must precede child
                ok = False
                break
            vals.append(v)
        if not ok or len(vals) != nb - 1:
            continue
        zeros = sum(1 for v in vals if v == 0)
        if zeros < 1:
            continue
        score = (zeros, start)
        if best is None or score < best[0]:
            best = (score, vals)
    return best[1] if best else None


def _extract_vanilla(data: bytes) -> CasModel:
    m = CasModel(partial=True)
    try:
        m.version = struct.unpack("<f", data[:4])[0]
    except Exception:
        m.version = 0.0
    if not (1.5 < m.version < 5.0):
        m.notes.append("No version float at 0x00 — this may be an unpacked "
                       "animation .cas (needs repacking), not a model.")

    strings = _length_prefixed_strings(data)
    bone_names = [(o, s) for o, s in strings if _is_bone_name(s)]
    other = [(o, s) for o, s in strings if not _is_bone_name(s)]

    # Bones (file order) + hierarchy.
    nb = len(bone_names)
    parents = _find_parent_array(data, nb) if nb else None
    for idx, (_o, name) in enumerate(bone_names):
        if idx == 0:
            parent = NO_PARENT
        elif parents and idx - 1 < len(parents):
            parent = parents[idx - 1]
        else:
            parent = 0
        m.bones.append(CasBone(name=name, parent=parent))
    if nb and parents is None:
        m.notes.append("Could not locate parent array; bones imported flat.")

    # Texture reference (path or basename ending in .tga/.dds).
    texture = ""
    for _o, s in other:
        sl = s.lower()
        if sl.endswith(".tga") or sl.endswith(".dds") or "textures" in sl:
            texture = s.replace("\\", "/").split("/")[-1]
            break
    if not texture:
        # Fallback: any printable run containing a texture extension, regardless
        # of how its length is prefixed (the texture path is encoded slightly
        # differently from the name strings in some files).
        texture = _scan_texture_path(data)

    # Mesh group names (everything else that isn't the texture path).
    for _o, s in other:
        sl = s.lower()
        if sl.endswith(".tga") or sl.endswith(".dds") or "textures" in sl:
            continue
        m.groups.append(CasGroup(name=s, texture=texture))

    m.notes.append("Vanilla file: extracted %d bone(s) + hierarchy and %d mesh "
                   "group name(s)." % (len(m.bones), len(m.groups)))
    m.notes.append("Mesh geometry and bind-pose positions are not byte-decoded "
                   "for vanilla files yet (positions live in the skeleton .dat). "
                   "Use IWTE / Feral casconv to get meshes as FBX/DAE.")
    if texture:
        m.notes.append("Texture referenced: %s" % texture)
    return m


# --------------------------------------------------------------------------- #
#  Animation block (our format)
# --------------------------------------------------------------------------- #
def _read_anim_block(r: _Reader, expected_bones: int) -> CasAnimation:
    bone_count = r.i32()
    frame_count = r.i32()
    mask_bytes = (bone_count + 7) // 8
    mask = r._take(mask_bytes)
    has_pos = [bool(mask[i // 8] & (1 << (i % 8))) for i in range(bone_count)]
    anim = CasAnimation(bones_with_position=has_pos)
    for _ in range(frame_count):
        fr = CasAnimFrame(rotations=[], translations=[])
        for _b in range(bone_count):
            fr.rotations.append(r.f32n(9))
        for b in range(bone_count):
            fr.translations.append(r.f32n(3) if has_pos[b] else (0.0, 0.0, 0.0))
        anim.frames.append(fr)
    return anim


def _write_anim_block(w: _Writer, anim: CasAnimation, bone_count: int):
    has_pos = list(anim.bones_with_position) or [False] * bone_count
    if len(has_pos) < bone_count:
        has_pos += [False] * (bone_count - len(has_pos))
    w.i32(bone_count)
    w.i32(len(anim.frames))
    mask = bytearray((bone_count + 7) // 8)
    for i in range(bone_count):
        if has_pos[i]:
            mask[i // 8] |= (1 << (i % 8))
    w.raw(bytes(mask))
    for fr in anim.frames:
        for b in range(bone_count):
            rot = fr.rotations[b] if b < len(fr.rotations) else (1, 0, 0, 0, 1, 0, 0, 0, 1)
            w.f32n(rot)
        if fr.translations:
            for b in range(bone_count):
                if has_pos[b]:
                    t = fr.translations[b] if b < len(fr.translations) else (0, 0, 0)
                    w.f32n(t)


def read_anim(data: bytes, bone_count_hint: int = 0) -> CasAnimation:
    return _read_anim_block(_Reader(data), bone_count_hint)


def write_anim(anim: CasAnimation, bone_count: int) -> bytes:
    w = _Writer()
    _write_anim_block(w, anim, bone_count)
    return w.getvalue()


# --------------------------------------------------------------------------- #
#  Diagnostics
# --------------------------------------------------------------------------- #
def inspect_header(data: bytes, max_floats: int = 16) -> str:
    lines = ["File size: %d bytes" % len(data)]
    lines.append("First 32 bytes: " + " ".join("%02X" % b for b in data[:32]))
    nf = min(max_floats, len(data) // 4)
    lines.append("As float32: " + ", ".join("%.4g" % f for f in struct.unpack("<%df" % nf, data[:4 * nf])))
    lines.append("As int32:   " + ", ".join(str(i) for i in struct.unpack("<%di" % nf, data[:4 * nf])))
    strs = _length_prefixed_strings(data)
    bones = [s for _o, s in strs if _is_bone_name(s)]
    others = [s for _o, s in strs if not _is_bone_name(s)]
    if data and 1.5 < struct.unpack("<f", data[:4])[0] < 5.0:
        lines.append("=> MODEL ('Full') cas; version=%.3f" % struct.unpack("<f", data[:4])[0])
    else:
        lines.append("=> No version float; likely an unpacked ANIM cas.")
    lines.append("Bones detected (%d): %s" % (len(bones), ", ".join(bones[:24])))
    lines.append("Other names: %s" % ", ".join(others[:24]))
    return "\n".join(lines)
