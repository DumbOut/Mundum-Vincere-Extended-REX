# SPDX-License-Identifier: GPL-3.0-or-later
"""
Rome: Total War .cas Tools for Blender
======================================
Import & export Rome: Total War (and M2TW / Remastered) .cas models with bone
hierarchy, vertex weighting and animation, plus automatic .tga/.dds texture
loading — wired into Blender's File > Import / Export menus like the FBX add-on,
with a dedicated sidebar panel headed by the Julii faction icon.

Structure (inspired by the Blender Source Tools layout):
    __init__.py    - registration + custom icon loading
    blender_manifest.toml - extension metadata (Blender 4.2+/5.x)
    cas_format.py  - the binary layout (single point of truth)
    import_cas.py  - importer operator
    export_cas.py  - exporter operator
    textures.py    - .tga/.dds discovery + material building
    extras.py      - LODs, weight tools, validator, inspector, unit cards
    ui.py          - sidebar panel
    icons/         - Julii icon used in menus & panel

This is a Blender Extension (4.2+/5.x): metadata lives in
blender_manifest.toml, NOT in a bl_info dict. Do not add bl_info back — having
both a manifest and bl_info can break loading under the Extensions system.
"""

# Version mirrored from blender_manifest.toml (kept as a plain constant so the
# code never relies on bl_info, which extensions do not provide).
RTW_VERSION = (2, 0, 2)

import os
import bpy

from . import cas_format
from . import cas_geometry
from . import skeletons
from . import skeleton_dat
from . import textures
from . import import_cas
from . import export_cas
from . import extras
from . import bake
from . import ui


# --------------------------------------------------------------------------- #
#  Custom icons (Julii) via the previews API
# --------------------------------------------------------------------------- #
_preview_collection = None


def _load_icons():
    global _preview_collection
    import bpy.utils.previews
    pcoll = bpy.utils.previews.new()
    icons_dir = os.path.join(os.path.dirname(__file__), "icons")
    for key, fname in (("julii", "julii.png"), ("julii_small", "julii_small.png")):
        path = os.path.join(icons_dir, fname)
        if os.path.isfile(path):
            pcoll.load(key, path, 'IMAGE')
    _preview_collection = pcoll


def get_icon_id(key="julii"):
    """Return the int icon id for use as icon_value=..., or 0 if unavailable."""
    if _preview_collection and key in _preview_collection:
        return _preview_collection[key].icon_id
    return 0


# --------------------------------------------------------------------------- #
#  Registration
# --------------------------------------------------------------------------- #
_classes = (
    import_cas.ImportCAS,
    export_cas.ExportCAS,
    *extras.classes,
    *bake.classes,
    *ui.classes,
)


def register():
    print("[RTW .cas Tools] registering v%s" % ".".join(map(str, RTW_VERSION)))
    _load_icons()
    for cls in _classes:
        bpy.utils.register_class(cls)
    bpy.types.TOPBAR_MT_file_import.append(import_cas.menu_func_import)
    bpy.types.TOPBAR_MT_file_export.append(export_cas.menu_func_export)


def unregister():
    bpy.types.TOPBAR_MT_file_import.remove(import_cas.menu_func_import)
    bpy.types.TOPBAR_MT_file_export.remove(export_cas.menu_func_export)
    for cls in reversed(_classes):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    global _preview_collection
    if _preview_collection:
        bpy.utils.previews.remove(_preview_collection)
        _preview_collection = None


if __name__ == "__main__":
    register()
