# SPDX-License-Identifier: GPL-3.0-or-later
"""
skeleton_dat.py
===============
Reader for Rome: Total War 'skeletons.dat' (the SKEL.PACK animation/skeleton
pack found in data/animations/). It provides the BIND POSE that model .cas
files need but do not contain.

Reverse-engineered and validated against a glTF reference: each bone record is
24 bytes = three float32 local-translation components (relative to the parent)
followed by three trailing float32s. Walking the parent hierarchy and summing
local translations yields each bone's world bind position. Z is negated versus
a Blender Y-up world (the same flip used for the mesh data).

In practice the bone *order* and parent hierarchy come from the model .cas
(which lists bone names + a parent array); this reader supplies the matching
local translations so we can compute world positions for exactly those bones.

Because the .dat packs many skeletons back-to-back without per-skeleton bone
names, we extract the local-translation table that best fits the requested bone
hierarchy: we read a contiguous run of 24-byte records and validate that the
resulting world positions are physically plausible (bounded, non-NaN).
"""

import struct

REC = 24  # bytes per bone local record
_F = struct.Struct("<f")


def _f(d, o):
    return _F.unpack_from(d, o)[0]


def _plausible(v):
    return all(-50.0 < c < 50.0 for c in v) and not any(c != c for c in v)


def read_local_table(data, max_bones=64):
    """Read the first skeleton's contiguous run of 24-byte local-translation
    records. The first skeleton's records begin at offset 0x3C in the SKEL.PACK
    layout (validated against a reference); we read until a record stops being
    physically plausible."""
    n = len(data)
    recs = []
    o = 0x3C
    while o + REC <= n and len(recs) < max_bones:
        v = (_f(data, o), _f(data, o + 4), _f(data, o + 8))
        if not _plausible(v):
            break
        recs.append(v)
        o += REC
    return recs


def bind_world_positions(data, bone_names, parents):
    """Compute world bind positions for the given bones.

    bone_names : list of bone names in file order (index 0 = root).
    parents    : list of parent indices aligned to bone_names (root = -1).
    Returns a list of (x, y, z) world positions (Z flipped to Y-up), or None.

    The .dat stores local translations for the moving bones; the root chain
    ("Scene Root", "bone_pelvis") sits at the origin and has no record, so the
    first record corresponds to the first non-origin bone.
    """
    table = read_local_table(data, max_bones=len(bone_names) + 4)
    if len(table) < max(1, len(bone_names) - 3):
        return None

    nbones = len(bone_names)
    # Count leading origin bones (root + pelvis-style) that carry no record.
    # Standard RTW human skeletons have 2 (Scene Root, bone_pelvis).
    origin_lead = 0
    for nm in bone_names:
        low = nm.lower()
        if low == "scene root" or low.endswith("pelvis") or low.endswith("root"):
            origin_lead += 1
        else:
            break
    origin_lead = max(1, min(origin_lead, 2))

    locals_aligned = [(0.0, 0.0, 0.0)] * nbones
    for k in range(origin_lead, nbones):
        ri = k - origin_lead
        if ri < len(table):
            lx, ly, lz = table[ri]
            locals_aligned[k] = (lx, ly, -lz)   # flip Z to Y-up

    world = [None] * nbones
    for i in range(nbones):
        lt = locals_aligned[i]
        p = parents[i] if i < len(parents) else -1
        if 0 <= p < nbones and world[p] is not None and p < i:
            wp = world[p]
            world[i] = (wp[0] + lt[0], wp[1] + lt[1], wp[2] + lt[2])
        else:
            world[i] = lt
    return world


def looks_like_skeleton_dat(path):
    try:
        with open(path, "rb") as fh:
            head = fh.read(16)
        return head[:9] == b"SKEL.PACK"
    except Exception:
        return False
