# SPDX-License-Identifier: GPL-3.0-or-later
"""
textures.py
===========
Automatic discovery and loading of Rome: Total War unit textures (.tga / .dds)
and construction of a Principled-BSDF material for each mesh group.

RTW unit textures live next to / near the model, typically under
    .../data/models_unit/textures/<name>.tga
    .../data/characters/textures/<name>.dds   (Remastered, PBR)
The .cas group stores only a basename, so we search a set of likely folders.
"""

import os
import bpy

# Folders (relative to the .cas) that commonly hold the matching textures.
_SEARCH_SUBDIRS = [
    ".",
    "textures",
    "../textures",
    "../textures",          # common CA typo seen in some packs
    "../../textures",
    "../characters/textures",
    "../models_unit/textures",
]

_TEXTURE_EXTS = (".dds", ".tga", ".png")   # preference order: DDS (RR) then TGA


def _strip_tex_ext(fn):
    """Strip texture extensions, including RTW's doubled '.tga.dds'."""
    low = fn.lower()
    for ext in (".tga.dds", ".dds", ".tga", ".png"):
        if low.endswith(ext):
            return fn[: len(fn) - len(ext)]
    return os.path.splitext(fn)[0]


def find_texture(cas_path: str, basename: str):
    """Return the first existing texture path matching *basename*, or None.
    Handles RTW's '.tga', '.dds', and doubled '.tga.dds' naming."""
    if not basename:
        return None
    base_dir = os.path.dirname(os.path.abspath(cas_path))
    stem = _strip_tex_ext(os.path.basename(basename))

    # If the basename already carries an extension and exists verbatim, use it.
    direct = os.path.join(base_dir, basename)
    if os.path.isfile(direct):
        return direct

    # Extensions to try, doubled ones first (Remastered ships <name>.tga.dds).
    exts = (".tga.dds", ".dds", ".tga", ".png")
    for sub in _SEARCH_SUBDIRS:
        folder = os.path.normpath(os.path.join(base_dir, sub))
        if not os.path.isdir(folder):
            continue
        for ext in exts:
            cand = os.path.join(folder, stem + ext)
            if os.path.isfile(cand):
                return cand
        # case-insensitive fallback comparing the stripped stems
        try:
            for fn in os.listdir(folder):
                if _strip_tex_ext(fn).lower() == stem.lower() \
                        and fn.lower().endswith(exts):
                    return os.path.join(folder, fn)
        except OSError:
            pass
    return None


def _load_image(path: str):
    """Load (or reuse) an image datablock. Blender reads TGA natively and DDS
    via its built-in DDS loader."""
    norm = os.path.normpath(path)
    for img in bpy.data.images:
        try:
            if img.filepath and os.path.normpath(bpy.path.abspath(img.filepath)) == norm:
                return img
        except Exception:
            continue
    try:
        return bpy.data.images.load(path, check_existing=True)
    except RuntimeError:
        return None


def build_material(name: str, cas_path: str, texture_ref: str,
                   auto_load: bool = True):
    """Create a Principled BSDF material, wiring the diffuse texture if found.

    Returns (material, texture_path_or_None).
    """
def build_material(name: str, cas_path: str, texture_ref: str,
                   auto_load: bool = True, backface_cull: bool = False):
    """Create a Principled BSDF material, wiring the diffuse texture if found.

    RTW always renders units with an alpha channel (RENDER_ALPHA in the engine),
    so the material is always alpha-enabled. backface_cull comes from the .cas
    material flag when known; default False so single-sided shields show solid.

    Returns (material, texture_path_or_None).
    """
    mat = bpy.data.materials.new(name=name or "rtw_material")
    mat.use_nodes = True
    # Honour the .cas backface-cull flag; default off so single-sided RTW
    # shields/cloaks render solid from both sides instead of black/see-through.
    mat.use_backface_culling = bool(backface_cull)
    try:
        mat.show_transparent_back = True
    except Exception:
        pass
    nt = mat.node_tree
    nt.nodes.clear()

    out = nt.nodes.new("ShaderNodeOutputMaterial")
    out.location = (400, 0)
    bsdf = nt.nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.location = (80, 0)
    nt.links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])

    # RTW units always use an alpha channel (engine renders with RENDER_ALPHA).
    # Enable alpha-clip up front so it's active even before/without a texture.
    mat.blend_method = 'CLIP'
    try:
        mat.shadow_method = 'CLIP'
    except Exception:
        pass

    tex_path = None
    if auto_load and texture_ref:
        tex_path = find_texture(cas_path, texture_ref)
        if tex_path:
            img = _load_image(tex_path)
            if img:
                try:
                    img.alpha_mode = 'CHANNEL_PACKED'
                except Exception:
                    pass
                tnode = nt.nodes.new("ShaderNodeTexImage")
                tnode.image = img
                tnode.location = (-360, 60)
                nt.links.new(tnode.outputs["Color"], bsdf.inputs["Base Color"])
                # RTW unit textures use the alpha channel for masking.
                nt.links.new(tnode.outputs["Alpha"], bsdf.inputs["Alpha"])

                # Optional companion maps (Remastered PBR): _normal, _gloss, _mask
                _wire_companion(nt, bsdf, tex_path)

    # Store the original reference so export can write it back unchanged.
    mat["rtw_texture"] = texture_ref or ""
    return mat, tex_path


def _wire_companion(nt, bsdf, diffuse_path):
    """Best-effort hook-up of Remastered companion maps if they sit alongside."""
    folder = os.path.dirname(diffuse_path)
    stem = os.path.splitext(os.path.basename(diffuse_path))[0]
    for suffix in ("_normal", "_n"):
        for ext in (".dds", ".tga", ".png"):
            cand = os.path.join(folder, stem + suffix + ext)
            if os.path.isfile(cand):
                img = _load_image(cand)
                if img:
                    img.colorspace_settings.name = 'Non-Color'
                    nmap_tex = nt.nodes.new("ShaderNodeTexImage")
                    nmap_tex.image = img
                    nmap_tex.location = (-360, -260)
                    nmap = nt.nodes.new("ShaderNodeNormalMap")
                    nmap.location = (-100, -260)
                    nt.links.new(nmap_tex.outputs["Color"], nmap.inputs["Color"])
                    nt.links.new(nmap.outputs["Normal"], bsdf.inputs["Normal"])
                return
