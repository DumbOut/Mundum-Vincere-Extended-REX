# SPDX-License-Identifier: GPL-3.0-or-later
"""
cas_vanilla.py
==============
Writer for the *vanilla* Rome: Total War .cas format that the GAME loads
(as opposed to the add-on's tagged round-trip format in cas_format.py).

Structure (confirmed against Creative Assembly's cas_loader.cpp and validated
against a real model file):

    float32 version
    chunk: scene        (class_id 9)
    chunk: rigid list   (class_id 1)   [int32 count][CAS_RIGID]*     (single-bone)
    chunk: flexi list   (class_id 2)   [int32 count][CAS_FLEXI]*     (multi-bone)
    chunk: material     (class_id 5)   [int32 num_materials][CAS_MATERIAL]*

Each chunk is written as: [int32 chunk_size][int32 class_id][data...], where
chunk_size counts from the size field itself to the end of the chunk (matching
CAS::write_chunk_size, which stores bof_pos - chunk_start).

Per-object CAS_FLEXI / CAS_RIGID layout (version 3.x):
    int32  name_len (includes null)         name bytes
    int32  props_len                        props bytes (we write 1 + "\0")
    quat(4f) + vec3(3f)                     local origin (identity)
    uint16 vert_count   uint16 face_count
    uint8  is_textured  uint8 uses_cverts
    [flexi only] int32 node_index * vert_count    (per-vertex bone)
    vec3 * vert_count                       positions (bone-local, Z negated)
    vec3 * vert_count                       normals
    (uint16,uint16,uint16) * face_count     faces
    int32  mtrl_index
    [if textured] vec2 * vert_count         uvs (V already in RTW space)
    [if cverts]   (r,g,b,a bytes) * vert_count
    int32  num_excluded_lights (0)

Rigid parts additionally carry a single header node index; here we write rigid
parts in the *flexi* form when they are single-bone by emitting them as flexi
with a constant per-vertex node index. This is accepted by the loader (a flexi
with one bone per vertex is valid) and keeps the writer simple and robust.
"""

import struct

SCENE_CLASS_ID = 9
RIGID_CLASS_ID = 1
FLEXI_CLASS_ID = 2
MATERIAL_CLASS_ID = 5

DEFAULT_VERSION = 3.18


class _W:
    def __init__(self):
        self.b = bytearray()

    def i32(self, v):
        self.b += struct.pack("<i", int(v))

    def u32(self, v):
        self.b += struct.pack("<I", int(v))

    def u16(self, v):
        self.b += struct.pack("<H", int(v) & 0xFFFF)

    def u8(self, v):
        self.b += struct.pack("<B", int(v) & 0xFF)

    def f(self, v):
        self.b += struct.pack("<f", float(v))

    def raw(self, data):
        self.b += data

    def tell(self):
        return len(self.b)

    def patch_u32(self, at, v):
        self.b[at:at + 4] = struct.pack("<I", int(v))


def _write_scene_chunk(w):
    """Write the scene chunk (class_id 9) exactly as CAS_SCENE::write_to_file
    does, so CAS_SCENE::init's assert (class_id == CAS_SCENE_CLASS_ID) passes.

    Layout: [u32 chunk_size][i32 class_id=9][f32 start][f32 end]
            [i32 num_bg_keys] {f32 time, u8 r,g,b}*
            [i32 num_amb_keys]{f32 time, u8 r,g,b}*
    chunk_size counts from the size field to the end of the chunk."""
    start = w.tell()
    w.u32(0)                       # chunk_size placeholder
    w.i32(SCENE_CLASS_ID)          # class_id = 9
    w.f(0.0)                       # start_time
    w.f(3.3333333)                 # end_time
    # one background colour key (neutral grey, as in real unit files)
    w.i32(1)
    w.f(0.0); w.u8(104); w.u8(104); w.u8(104)
    # one ambient light key (black)
    w.i32(1)
    w.f(0.0); w.u8(0); w.u8(0); w.u8(0)
    w.patch_u32(start, w.tell() - start)


def _write_flexi_object(w, obj, version):
    """Write one CAS_FLEXI (multi-bone) object exactly per CAS_FLEXI::init."""
    name = obj["name"].encode("latin-1", "replace")
    # CAS_FLEXI writes name_len = str_len(name)+1 (INCLUDES null), then name+null
    name_buf = name + b"\x00"
    w.i32(len(name_buf))
    w.raw(name_buf)
    # properties (version >= 3.03): int32 len, ascii (write empty => len 1, "\0"… 
    # actually write_ascii writes the chars; UNI_STRING "" writes 1 byte length)
    if version >= 3.03:
        w.i32(1)            # properties.length()+1 for empty string
        w.u8(0)             # the ascii content (empty string terminator)
    # local origin (version >= 2.24): identity quaternion + zero translation
    if version >= 2.24:
        w.f(0.0); w.f(0.0); w.f(0.0); w.f(1.0)   # quaternion (w=1 identity)
        w.f(0.0); w.f(0.0); w.f(0.0)             # translation
    verts = obj["verts"]; faces = obj["faces"]; uvs = obj.get("uvs")
    nv = len(verts); nf = len(faces)
    is_textured = 1 if uvs else 0
    w.u16(nv); w.u16(nf)
    w.u8(is_textured); w.u8(0)                   # is_textured, uses_cverts
    # per-vertex node indices
    bt = obj.get("bone_table") or [0] * nv
    for i in range(nv):
        w.i32(int(bt[i]) if i < len(bt) else 0)
    for v in verts:
        w.f(v[0]); w.f(v[1]); w.f(v[2])
    nrms = obj.get("normals") or [(0.0, 0.0, 1.0)] * nv
    for nrm in nrms:
        w.f(nrm[0]); w.f(nrm[1]); w.f(nrm[2])
    for fc in faces:
        w.u16(fc[0]); w.u16(fc[1]); w.u16(fc[2])
    if version >= 2.22:
        w.i32(int(obj.get("mtrl_index", 0)))
    if is_textured:
        for uv in uvs:
            w.f(uv[0]); w.f(uv[1])
    # exclude lights (version >= 3.17): int count = 0
    w.i32(0)


def _write_rigid_object(w, obj, version):
    """Write one CAS_RIGID (single-bone) object exactly per CAS_RIGID::init.
    Differs from flexi: a group_name (v>=3.01) and a single header node_index,
    and NO per-vertex node table."""
    name = obj["name"].encode("latin-1", "replace")
    # Real RTW unit files write rigid name_len INCLUDING the null terminator
    # (e.g. "Object03\0" -> 9), so we match that for byte-compatibility.
    name_buf = name + b"\x00"
    w.i32(len(name_buf))
    w.raw(name_buf)
    if version >= 3.03:
        w.i32(1); w.u8(0)        # empty properties
    if version >= 3.01:
        # group_name (length-prefixed, include null like the name)
        w.i32(1); w.u8(0)        # empty group name + null
    # single node index for the whole part
    bt = obj.get("bone_table") or [0]
    node = bt[0] if bt else 0
    w.i32(int(node))
    if version >= 2.24:
        w.f(0.0); w.f(0.0); w.f(0.0); w.f(1.0)   # quaternion identity
        w.f(0.0); w.f(0.0); w.f(0.0)             # translation
    verts = obj["verts"]; faces = obj["faces"]; uvs = obj.get("uvs")
    nv = len(verts); nf = len(faces)
    is_textured = 1 if uvs else 0
    w.u16(nv); w.u16(nf)
    w.u8(is_textured); w.u8(0)
    for v in verts:
        w.f(v[0]); w.f(v[1]); w.f(v[2])
    nrms = obj.get("normals") or [(0.0, 0.0, 1.0)] * nv
    for nrm in nrms:
        w.f(nrm[0]); w.f(nrm[1]); w.f(nrm[2])
    for fc in faces:
        w.u16(fc[0]); w.u16(fc[1]); w.u16(fc[2])
    if version >= 2.22:
        w.i32(int(obj.get("mtrl_index", 0)))
    if is_textured:
        for uv in uvs:
            w.f(uv[0]); w.f(uv[1])
    w.i32(0)                      # exclude lights count


def _write_rigid_chunk(w, objs, version):
    """rigid chunk: [count][CAS_RIGID]*[card16 num_vert_sel][...]
    [int32 num_alpha_rigids]  (per CAS_MODEL::init_rigid)."""
    if not objs:
        return
    start = w.tell()
    w.u32(0)                       # chunk_size placeholder
    w.i32(RIGID_CLASS_ID)
    w.i32(len(objs))               # num_rigids
    for obj in objs:
        _write_rigid_object(w, obj, version)
    # vertex selection sets (version >= 2.21): count card16 = 0
    if version >= 2.21:
        w.u16(0)
    # number of alpha-textured rigids (int32). Mark all as alpha so the engine
    # renders them with the alpha channel (RENDER_ALPHA), matching unit files.
    w.i32(len(objs))
    w.patch_u32(start, w.tell() - start)


def _write_flexi_chunk(w, objs, version):
    """flexi chunk: [count][CAS_FLEXI]*[int32 num_alpha_flexis]."""
    if not objs:
        return
    start = w.tell()
    w.u32(0)
    w.i32(FLEXI_CLASS_ID)
    w.i32(len(objs))               # num_flexis
    for obj in objs:
        _write_flexi_object(w, obj, version)
    w.i32(len(objs))               # num_alpha_flexis (all alpha)
    w.patch_u32(start, w.tell() - start)


def _write_material_chunk(w, texture_name):
    """Write a single-material chunk (class_id 5) byte-compatible with a real
    unit file. Material body layout (validated against gaul_revenger.cas):
        int32  num_textures (=1)
        uint8  texture_type (0 = colour map)
        cstring "\\textures\\<name>" + NUL
        float32 * 7  (colour/coefficients, all 1.0)
        int32   * 7  (reserved, all 0)
        uint8   trailing flag (=1)
    """
    start = w.tell()
    w.u32(0)                       # chunk_size placeholder
    w.i32(MATERIAL_CLASS_ID)       # class_id = 5
    w.i32(1)                       # num_materials

    # --- one material ---
    w.i32(1)                       # num_textures in this material
    w.u8(0)                        # texture type (0 = colour map)
    tex = texture_name
    if not tex.lower().startswith("\\textures\\") and "\\" not in tex:
        tex = "\\textures\\" + tex
    w.raw(tex.encode("latin-1", "replace"))
    w.u8(0)                        # NUL terminator
    for _ in range(7):
        w.f(1.0)                   # colour/coefficient floats
    for _ in range(7):
        w.i32(0)                   # reserved
    w.u8(1)                        # trailing flag (backface/alpha marker)

    w.patch_u32(start, w.tell() - start)


def write_vanilla(objects, texture_name="unit.tga", version=DEFAULT_VERSION):
    """Build a vanilla, game-loadable .cas from a list of object dicts.

    Each object dict: {name, verts, normals, faces, uvs, bone_table,
    is_flexi, mtrl_index}. Rigid (single-bone) objects go in the rigid chunk,
    flexi (multi-bone) in the flexi chunk.
    """
    w = _W()
    w.f(version)                  # version float32
    _write_scene_chunk(w)

    rigids = [o for o in objects if not o.get("is_flexi")]
    flexis = [o for o in objects if o.get("is_flexi")]

    _write_rigid_chunk(w, rigids, version)
    _write_flexi_chunk(w, flexis, version)
    _write_material_chunk(w, texture_name)
    return bytes(w.b)


# =========================================================================== #
#  TEMPLATE INJECTION  (added: produces files the GAME actually loads)
# =========================================================================== #
#  A from-scratch writer must reproduce, byte-exactly, chunks that the loader
#  requires but that are tedious/perilous to synthesise: the class-0 scene /
#  node-graph chunk (the bones + bind pose; its absence is the "Scene data
#  chunk not found" fatal), the empty list chunks (class 3 / 8 / 10), the scene
#  settings (class 9) and the material (class 5). Worse, the geometry chunks
#  themselves carry per-vertex colours and per-part origin transforms that the
#  naive writer dropped.
#
#  So instead of guessing, we INJECT: keep every non-geometry chunk from the
#  original .cas verbatim (the game's own validated bytes) and rebuild only the
#  rigid (class 1) and flexi (class 2) geometry, in the exact verified layout.
#  This was confirmed by reproducing a real unit file's geometry chunks
#  byte-for-byte from their own decoded contents.
#
#  Verified top-level layout of a vanilla unit .cas:
#     float32 version
#     [i32 size][i32 class_id][body...]   repeated, size counts from the size
#                                         field to the chunk end (NOT 4-aligned)
#     class 9  = scene settings        class 0  = scene / node graph (skeleton)
#     class 1  = rigid (single-bone)   class 2  = flexi (multi-bone)
#     class 3/8/10 = (empty) lists     class 5  = materials
#
#  Verified rigid object:  name, props, group_name, i32 node, origin(4f+3f),
#     u16 nv,u16 nf,u8 textured,u8 cverts, nv*3f pos, nv*3f nrm, nf*3u16 face,
#     i32 mtrl, [tex] nv*2f uv, [cv] nv*4u8 rgba, i32 exclude_lights.
#     Rigid chunk trailer: u16 num_vertex_selection_sets, i32 num_alpha.
#  Verified flexi object:  name, props, origin(4f+3f), u16 nv,u16 nf,u8 tex,
#     u8 cv, nv*i32 node, nv*3f pos, nv*3f nrm, nf*3u16 face, i32 mtrl,
#     [tex] nv*2f uv, [cv] nv*4u8 rgba, i32 exclude_lights.
#     Flexi chunk trailer: i32 num_alpha.

RIGID_CLASS_ID = 1
FLEXI_CLASS_ID = 2


class _CR:
    """Minimal sequential reader over a bytes object."""
    def __init__(self, d, o=0):
        self.d = d
        self.o = o

    def i32(self):
        v = struct.unpack_from("<i", self.d, self.o)[0]; self.o += 4; return v

    def u16(self):
        v = struct.unpack_from("<H", self.d, self.o)[0]; self.o += 2; return v

    def u8(self):
        v = self.d[self.o]; self.o += 1; return v

    def f(self):
        v = struct.unpack_from("<f", self.d, self.o)[0]; self.o += 4; return v

    def take(self, n):
        b = self.d[self.o:self.o + n]; self.o += n; return b


def split_top_chunks(data):
    """Walk the top-level chunk list. Returns (version_bytes, version_float,
    [ (class_id, raw_chunk_bytes), ... ] ). raw_chunk_bytes includes the
    [size][class_id] header so chunks can be re-emitted verbatim."""
    version_bytes = data[:4]
    version = struct.unpack_from("<f", data, 0)[0]
    chunks = []
    o = 4
    n = len(data)
    while o + 8 <= n:
        size = struct.unpack_from("<i", data, o)[0]
        cid = struct.unpack_from("<i", data, o + 4)[0]
        if size <= 0 or o + size > n:
            break
        chunks.append((cid, data[o:o + size]))
        o += size
    return version_bytes, version, chunks


def _parse_geo_object(r, multi):
    """Parse one rigid (multi=False) or flexi (multi=True) object into a dict
    whose raw byte runs (name/props/grp/origin/verts/norms/faces/uvs/cverts)
    are preserved so the object can be re-emitted byte-for-byte, while the
    geometry runs can be swapped out for edited data."""
    name_len = r.i32(); name = r.take(name_len)
    props_len = r.i32(); props = r.take(props_len)
    grp = node = None
    if not multi:
        grp_len = r.i32(); grp = r.take(grp_len)
        node = r.i32()
    origin = r.take(28)                      # 4f quaternion + 3f translation
    nv = r.u16(); nf = r.u16(); tex = r.u8(); cv = r.u8()
    nodes = [r.i32() for _ in range(nv)] if multi else None
    verts = r.take(nv * 12)
    norms = r.take(nv * 12)
    faces = r.take(nf * 6)
    mtrl = r.i32()
    uvs = r.take(nv * 8) if tex else b""
    cverts = r.take(nv * 4) if cv else b""
    excl = r.i32()
    return dict(kind="flexi" if multi else "rigid", name=name, props=props,
                grp=grp, node=node, origin=origin, nv=nv, nf=nf, tex=tex, cv=cv,
                nodes=nodes, verts=verts, norms=norms, faces=faces, mtrl=mtrl,
                uvs=uvs, cverts=cverts, excl=excl)


def parse_geometry(data):
    """Decode the rigid and flexi geometry from a vanilla .cas.
    Returns (rigids, flexis, rigid_trailer, flexi_trailer) where each list holds
    object dicts (see _parse_geo_object) and the trailers preserve the per-chunk
    tail bytes (selection-sets / alpha counts) for byte-exact re-emission."""
    _vb, _ver, chunks = split_top_chunks(data)
    rigids, flexis = [], []
    rigid_trailer = (0, 0)       # (num_vertex_selection_sets, num_alpha)
    flexi_trailer = (0,)         # (num_alpha,)
    for cid, raw in chunks:
        if cid == RIGID_CLASS_ID:
            r = _CR(raw, 8); cnt = r.i32()
            for _ in range(cnt):
                rigids.append(_parse_geo_object(r, multi=False))
            nsel = r.u16(); nalpha = r.i32()
            rigid_trailer = (nsel, nalpha)
        elif cid == FLEXI_CLASS_ID:
            r = _CR(raw, 8); cnt = r.i32()
            for _ in range(cnt):
                flexis.append(_parse_geo_object(r, multi=True))
            nalpha = r.i32()
            flexi_trailer = (nalpha,)
    return rigids, flexis, rigid_trailer, flexi_trailer


def _emit_geo_object(ob):
    """Serialise one object dict back to bytes in the exact verified layout."""
    multi = ob["kind"] == "flexi"
    b = bytearray()
    b += struct.pack("<i", len(ob["name"])); b += ob["name"]
    b += struct.pack("<i", len(ob["props"])); b += ob["props"]
    if not multi:
        b += struct.pack("<i", len(ob["grp"])); b += ob["grp"]
        b += struct.pack("<i", ob["node"])
    b += ob["origin"]
    b += struct.pack("<HHBB", ob["nv"], ob["nf"], ob["tex"], ob["cv"])
    if multi:
        for nd in ob["nodes"]:
            b += struct.pack("<i", nd)
    b += ob["verts"]; b += ob["norms"]; b += ob["faces"]
    b += struct.pack("<i", ob["mtrl"])
    b += ob["uvs"]; b += ob["cverts"]
    b += struct.pack("<i", ob["excl"])
    return bytes(b)


def _emit_chunk(class_id, body):
    """Wrap a chunk body with [size][class_id]; size counts from the size field."""
    inner = struct.pack("<i", class_id) + body
    return struct.pack("<i", len(inner) + 4) + inner


def _emit_rigid_chunk(rigids, trailer):
    body = bytearray(struct.pack("<i", len(rigids)))
    for ob in rigids:
        body += _emit_geo_object(ob)
    body += struct.pack("<H", trailer[0]) + struct.pack("<i", trailer[1])
    return _emit_chunk(RIGID_CLASS_ID, bytes(body))


def _emit_flexi_chunk(flexis, trailer):
    body = bytearray(struct.pack("<i", len(flexis)))
    for ob in flexis:
        body += _emit_geo_object(ob)
    body += struct.pack("<i", trailer[0])
    return _emit_chunk(FLEXI_CLASS_ID, bytes(body))


def inject_geometry(template_bytes, rigids, flexis,
                    rigid_trailer=(0, 0), flexi_trailer=(0,)):
    """Rebuild a vanilla .cas from a TEMPLATE, keeping every non-geometry chunk
    (scene, node graph / skeleton, empty lists, material) byte-for-byte and
    substituting freshly-emitted rigid (class 1) and flexi (class 2) chunks.

    The original chunk ORDER is preserved. If the template lacked a rigid or
    flexi chunk but new objects of that kind exist, the chunk is appended right
    after the scene/node-graph chunks (before the material chunk) so ordering
    still matches what the loader walks."""
    version_bytes, _ver, chunks = split_top_chunks(template_bytes)
    out = bytearray(version_bytes)
    wrote_rigid = wrote_flexi = False
    # First pass: emit in original order, swapping geometry chunks in place.
    for cid, raw in chunks:
        if cid == RIGID_CLASS_ID:
            if rigids:
                out += _emit_rigid_chunk(rigids, rigid_trailer)
            wrote_rigid = True
        elif cid == FLEXI_CLASS_ID:
            if flexis:
                out += _emit_flexi_chunk(flexis, flexi_trailer)
            wrote_flexi = True
        else:
            # If we are about to write the material chunk but never hit a
            # geometry chunk we still need to add, insert it first.
            if cid == MATERIAL_CLASS_ID:
                if rigids and not wrote_rigid:
                    out += _emit_rigid_chunk(rigids, rigid_trailer); wrote_rigid = True
                if flexis and not wrote_flexi:
                    out += _emit_flexi_chunk(flexis, flexi_trailer); wrote_flexi = True
            out += raw
    # Any remaining geometry (template had neither material nor that chunk).
    if rigids and not wrote_rigid:
        out += _emit_rigid_chunk(rigids, rigid_trailer)
    if flexis and not wrote_flexi:
        out += _emit_flexi_chunk(flexis, flexi_trailer)
    return bytes(out)


def read_node_names(data):
    """Return the skeleton node names in node-index order, taken from the
    class-0 scene/node-graph chunk. The per-vertex node indices in flexi parts
    (and a rigid part's single node index) refer to THIS ordering, so the
    exporter maps Blender bone names to these indices when it has to rebuild
    geometry whose vertex count changed."""
    _vb, _ver, chunks = split_top_chunks(data)
    for cid, raw in chunks:
        if cid != 0:
            continue
        names = []
        p = 8  # past [size][class_id]
        n = len(raw)
        while p + 4 <= n:
            L = struct.unpack_from("<i", raw, p)[0]
            if 2 <= L <= 64 and p + 4 + L <= n:
                chars = raw[p + 4:p + 4 + L]
                if chars[-1:] == b"\x00" and \
                        all(32 <= c < 127 or c == 0 for c in chars) and \
                        sum(32 <= c < 127 for c in chars) >= 2:
                    names.append(chars.rstrip(b"\x00").decode("latin-1"))
                    p += 4 + L
                    continue
            p += 1
        return names
    return []
