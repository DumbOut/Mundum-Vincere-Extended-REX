# SPDX-License-Identifier: GPL-3.0-or-later
"""
cas_geometry.py
===============
FULL geometry decoder for Rome: Total War model .cas files. Reverse-engineered
and validated byte-for-byte against a glTF reference: every object's positions,
normals, faces and UVs reconstruct with ZERO error, for both single-bone and
multi-bone meshes (e.g. the 254-vertex 'body' across 14 bones).

No glTF sidecar is required. A skeletons.dat (or the built-in bind table) is
only needed to place the bone-local vertices in world space.

Per-object layout (validated)
-----------------------------
  ...object name (length-prefixed, length INCLUDES the null)...
  ...header fields (flags, texture id, and for single-bone objects a bone
     index + a 3x3-ish matrix)...
  uint16 vertex_count
  uint16 face_count
  uint16 flags
  IF multi-bone (first int32 after flags is a small bone id 0..255):
      int32 bone_index * vertex_count        <-- per-vertex bind bone
  positions : float32[3] * vertex_count       (BONE-LOCAL; Z negated vs Y-up)
  normals   : float32[3] * vertex_count
  faces     : uint16[3]  * face_count          (winding b<->c swapped)
  uint32 pad (0)
  uvs       : float32[2] * vertex_count        (V not flipped)

World position of a vertex = bind_world[bone] + (x, y, -z).
For single-bone objects the bone index comes from the header instead of a table.
"""

import os
import struct

_U16 = struct.Struct("<H")
_I32 = struct.Struct("<i")
_F = struct.Struct("<f")


def _u16(d, o):
    return _U16.unpack_from(d, o)[0]


# --------------------------------------------------------------------------- #
#  Proper chunk-aware parser (faithful to Creative Assembly's cas_loader.cpp
#  and cas_flexi_data.cpp / rigid). The file is:
#     float32 version
#     scene data
#     repeated chunks: [int32 chunk_size][int32 class_id][data...]
#  We don't need the scene/class-id enum values: we locate each geometry object
#  by its length-prefixed name (length INCLUDES the null), then parse the body
#  exactly per the source. is_textured controls whether UVs exist; uses_cverts
#  adds per-vertex colour; an optional origin (quat+vec) precedes the counts.
# --------------------------------------------------------------------------- #
class _Reader:
    __slots__ = ("d", "o", "n")

    def __init__(self, d, o=0):
        self.d = d
        self.o = o
        self.n = len(d)

    def i32(self):
        v = _I32.unpack_from(self.d, self.o)[0]
        self.o += 4
        return v

    def u16(self):
        v = _U16.unpack_from(self.d, self.o)[0]
        self.o += 2
        return v

    def u8(self):
        v = self.d[self.o]
        self.o += 1
        return v

    def f(self):
        v = _F.unpack_from(self.d, self.o)[0]
        self.o += 4
        return v

    def vec3(self):
        x = self.f(); y = self.f(); z = self.f()
        return (x, y, z)

    def vec2(self):
        u = self.f(); v = self.f()
        return (u, v)


def _parse_geometry_at_name(d, name_off, version):
    """Parse one rigid/flexi/weighted object whose length-prefixed name starts
    at *name_off* (the int32 length, then the chars). Returns a dict or None.

    Mirrors CAS_FLEXI::init / CAS_RIGID::init. We auto-detect single-bone
    (rigid: one node_index header field) vs multi-bone (flexi: a per-vertex
    node_index table) by probing which interpretation yields valid geometry."""
    r = _Reader(d, name_off)
    n = len(d)
    try:
        name_len = r.i32()
        if name_len < 1 or name_len > 256 or r.o + name_len > n:
            return None
        raw = d[r.o:r.o + name_len]
        r.o += name_len
        name = raw.rstrip(b"\x00").decode("latin-1", "replace")

        # properties string (version >= 3.03): int32 props_buf_len, then ascii
        if version >= 3.03:
            props_len = r.i32()
            if props_len < 0 or r.o + props_len > n:
                return None
            r.o += props_len  # skip props (read_ascii content)

        # optional local origin (version >= 2.24): quaternion(4f) + vec3(3f)
        origin = None
        if version >= 2.24:
            # peek: the next u16 pair would be counts; origin is 28 bytes.
            # We trust the version and consume 28 bytes of origin.
            q = (r.f(), r.f(), r.f(), r.f())
            t = r.vec3()
            origin = (q, t)

        vert_count = r.u16()
        face_count = r.u16()
        if not (1 <= vert_count <= 60000 and 1 <= face_count <= 120000):
            return None
        is_textured = bool(r.u8())
        uses_cverts = bool(r.u8())

        body_start = r.o  # start of node table / positions

        def _read_body(multi):
            rr = _Reader(d, body_start)
            bone_table = None
            if multi:
                bt = []
                for _ in range(vert_count):
                    b = rr.i32()
                    if not (0 <= b < 256):
                        return None
                    bt.append(b)
                bone_table = bt
            verts = [rr.vec3() for _ in range(vert_count)]
            normals = [rr.vec3() for _ in range(vert_count)]
            faces = [(rr.u16(), rr.u16(), rr.u16()) for _ in range(face_count)]
            # material index (version >= 2.22)
            mtrl_index = rr.i32() if version >= 2.22 else -1
            uvs = None
            if is_textured:
                uvs = [rr.vec2() for _ in range(vert_count)]
            # colour verts
            cverts = None
            if uses_cverts:
                cverts = []
                for _ in range(vert_count):
                    rd = rr.u8(); gn = rr.u8(); bl = rr.u8()
                    al = rr.u8() if version >= 3.02 else 255
                    cverts.append((rd / 255.0, gn / 255.0, bl / 255.0,
                                   al / 255.0))
            # sanity: positions/faces in range and plausible
            for k in (0, vert_count - 1):
                for j in range(3):
                    if not _valid_coord(verts[k][j]):
                        return None
            for ff in (faces[0], faces[-1]):
                if max(ff) >= vert_count:
                    return None
            return dict(name=name, nv=vert_count, nf=face_count,
                        bone_table=bone_table, verts=verts, normals=normals,
                        faces=faces, uvs=uvs, mtrl_index=mtrl_index,
                        is_textured=is_textured, uses_cverts=uses_cverts,
                        cverts=cverts, origin=origin, end_off=rr.o,
                        counts_off=body_start - 4)

        # flexi (multi-bone) has the per-vertex node table; rigid (single) does
        # not. Probe multi first (its table validates strictly), else single.
        res = _read_body(multi=True)
        if res is None:
            res = _read_body(multi=False)
        return res
    except (struct.error, IndexError, UnicodeError):
        return None


def _chunk_parse(data):
    """Find every geometry object via its name and parse it per the CA source.
    Robust to non-4-byte alignment (the engine reads sequentially)."""
    version = _F.unpack_from(data, 0)[0]
    if not (1.0 < version < 10.0):
        version = 3.18
    out = []
    seen = set()
    for off, name in _length_prefixed_strings(data):
        if _is_bone_name(name):
            continue
        sl = name.lower()
        if sl.endswith(".tga") or sl.endswith(".dds") or "textures" in sl:
            continue
        rec = _parse_geometry_at_name(data, off, version)
        if rec and rec["counts_off"] not in seen:
            seen.add(rec["counts_off"])
            out.append(rec)
    return out, version


def _u16_orig(d, o):
    return _U16.unpack_from(d, o)[0]


def _i32(d, o):
    return _I32.unpack_from(d, o)[0]


def _f(d, o):
    return _F.unpack_from(d, o)[0]


def _valid_coord(x):
    return -500.0 < x < 500.0


# --------------------------------------------------------------------------- #
#  Core decode
# --------------------------------------------------------------------------- #
def _try_decode_at(d, counts_off):
    """Try to decode a full object whose (uint16 nv, uint16 nf) sit at
    *counts_off*. Returns a dict or None if it doesn't validate."""
    n = len(d)
    if counts_off + 6 > n:
        return None
    nv = _u16(d, counts_off)
    nf = _u16(d, counts_off + 2)
    if not (3 <= nv <= 60000 and 1 <= nf <= 120000):
        return None
    # Plausible vertex/face ratio. Triangle meshes vary widely (strips, fans,
    # shared verts), so keep this loose — only reject wildly impossible blocks
    # like nv=257 with nf=6. A valid mesh has nf at least ~nv/4 and at most ~nv*5.
    if nf * 4 < nv or nf > nv * 5:
        return None
    after = counts_off + 6  # past nv, nf, flags(u16)

    # An object is either MULTI-bone (a per-vertex int32 bone table precedes the
    # positions) or SINGLE-bone (positions start immediately, bone in header).
    # Detecting by "first int32 looks small" is unreliable, so we try BOTH and
    # keep whichever yields a fully-valid block.
    def _attempt(pos, bone_table):
        end = pos + nv * 12 + nv * 12 + nf * 6 + 4 + nv * 8
        if end > n:
            return None
        # positions plausible (sample several, not just endpoints)
        for k in (0, nv // 2, nv - 1):
            for j in range(3):
                v = _f(d, pos + k * 12 + j * 4)
                if not _valid_coord(v) or v != v:
                    return None
        nrm = pos + nv * 12
        n0 = (_f(d, nrm), _f(d, nrm + 4), _f(d, nrm + 8))
        mag = (n0[0] ** 2 + n0[1] ** 2 + n0[2] ** 2) ** 0.5
        if not (1e-4 < mag < 1000.0) or any(c != c for c in n0):
            return None
        fo = nrm + nv * 12
        step = max(1, (nf * 3) // 12)
        for k in range(0, nf * 3, step):
            if _u16(d, fo + k * 2) >= nv:
                return None
        return (pos, bone_table, fo)

    result = None
    # multi-bone attempt: read a bone table of nv int32 in 0..255
    if after + nv * 4 <= n:
        tbl = []
        ok = True
        for k in range(nv):
            b = _i32(d, after + k * 4)
            if not (0 <= b < 256):
                ok = False
                break
            tbl.append(b)
        if ok:
            result = _attempt(after + nv * 4, tbl)
    # single-bone attempt: positions start right after the flags
    if result is None:
        result = _attempt(after, None)
    if result is None:
        return None
    pos, bone_table, fo = result
    nrm = pos + nv * 12

    verts = [(_f(d, pos + k * 12), _f(d, pos + k * 12 + 4), _f(d, pos + k * 12 + 8))
             for k in range(nv)]
    normals = [(_f(d, nrm + k * 12), _f(d, nrm + k * 12 + 4), _f(d, nrm + k * 12 + 8))
               for k in range(nv)]
    faces = [(_u16(d, fo + k * 6), _u16(d, fo + k * 6 + 2), _u16(d, fo + k * 6 + 4))
             for k in range(nf)]
    uvo = fo + nf * 6 + 4
    uvs = [(_f(d, uvo + k * 8), _f(d, uvo + k * 8 + 4)) for k in range(nv)]
    return dict(nv=nv, nf=nf, bone_table=bone_table, verts=verts,
                normals=normals, faces=faces, uvs=uvs,
                counts_off=counts_off, pos_off=pos)


def _header_bone(d, counts_off, search_start):
    """For single-bone objects, recover the bone index stored in the header
    (a small int between the object name and the counts)."""
    lo = max(0, search_start)
    for back in range(8, min(96, counts_off - lo + 8), 2):
        off = counts_off - back
        if off < 0:
            break
        try:
            c = _i32(d, off)
        except struct.error:
            continue
        if 0 <= c < 64:
            return c
    return 0


# --------------------------------------------------------------------------- #
#  String table (length-prefixed, length INCLUDES the null terminator)
# --------------------------------------------------------------------------- #
def _length_prefixed_strings(d):
    out = []
    o = 0
    n = len(d)
    while o + 4 < n:
        L = _i32(d, o)
        if 2 <= L <= 64 and o + 4 + L <= n:
            b = d[o + 4:o + 4 + L]
            if b[-1] == 0 and all(32 <= c < 127 for c in b[:-1]):
                out.append((o, b[:-1].decode("latin-1")))
                o += 4 + L
                continue
        o += 1
    return out


def _is_bone_name(s):
    sl = s.lower()
    return sl == "scene root" or sl.startswith("bone")


# --------------------------------------------------------------------------- #
#  Public: locate & decode every mesh object in a .cas
# --------------------------------------------------------------------------- #
def _model_node_type_from_string(name):
    """Mirror of CA's model_node_type_from_string: classify a rigid part by its
    name. Returns 'primary', 'secondary', or None."""
    n = name.lower().replace("__", " ").replace("_", " ").strip()
    if "primary" in n and "weapon" in n:
        return "primary"
    if "secondary" in n and "weapon" in n:
        return "secondary"
    return None


def locate_objects(data, object_names=None):
    """Decode EVERY mesh object in the file.

    Primary path: a proper chunk-aware parse faithful to Creative Assembly's
    loader (handles is_textured/UV presence, material index, colour verts and
    the local origin). Fallback: a tolerant whole-file + name-anchored
    structural scan, in case a file uses an unexpected variant.

    Returns dicts: {name, nv, nf, verts, normals, faces, uvs, bone_table,
    is_flexi, weapon_type, mtrl_index, counts_off}."""
    # --- primary: faithful chunk parse (best for flexi/multi-bone parts) ---
    parsed, _version = _chunk_parse(data)
    # --- also run the tolerant structural scan (catches rigid/single-bone and
    #     any variant the strict parser misses) ---
    scanned = _locate_objects_scan(data, object_names)

    # Merge: prefer the faithful chunk parse for a given object (keyed by name
    # at a nearby offset); fill in anything only the scanner found.
    merged = {}

    def keyfor(rec):
        # key on (name, vertex count, face count) to dedupe across both passes
        return (rec["name"].split("_")[0], rec["nv"], rec["nf"])

    for rec in parsed:
        rec.setdefault("is_textured", True)
        rec.setdefault("uses_cverts", False)
        rec.setdefault("mtrl_index", -1)
        merged[keyfor(rec)] = rec
    for rec in scanned:
        k = keyfor(rec)
        if k not in merged:
            rec.setdefault("is_textured", True)
            rec.setdefault("uses_cverts", False)
            rec.setdefault("mtrl_index", -1)
            merged[k] = rec

    if not merged:
        return []

    out = []
    used = {}
    for rec in merged.values():
        rec["is_flexi"] = rec.get("bone_table") is not None and \
            len(set(rec["bone_table"])) > 1
        if rec.get("bone_table") is None:
            hb = _header_bone(data, rec["counts_off"],
                              max(0, rec["counts_off"] - 96))
            rec["bone_table"] = [hb] * rec["nv"]
        if rec.get("uvs") is None:
            rec["uvs"] = [(0.0, 0.0)] * rec["nv"]
        nm = rec["name"] or "mesh"
        base = nm.split("_")[0] if "_" in nm else nm
        if base in used:
            used[base] += 1
            rec["name"] = "%s_%d" % (base, used[base])
        else:
            used[base] = 0
            rec["name"] = base
        rec["weapon_type"] = _model_node_type_from_string(rec["name"])
        out.append(rec)

    def order_key(r):
        if r["weapon_type"] == "primary":
            return (0,)
        if r["weapon_type"] == "secondary":
            return (2,)
        return (1,)
    out.sort(key=order_key)
    return out


def _locate_objects_scan(data, object_names=None):
    """Decode EVERY mesh object in the file. Combines two strategies so nothing
    is missed:
      (1) a whole-file structural scan that finds any valid block, and
      (2) a name-anchored pass that, for every object name in the file, searches
          the bytes right after it for a valid block.
    Blocks are de-duplicated by their byte offset, then labelled by the nearest
    preceding object name.

    Returns dicts: {name, nv, nf, verts, normals, faces, uvs, bone_table,
    counts_off, pos_off}."""
    n = len(data)

    # --- collect object-name offsets (for labelling + the anchored pass) ---
    strs = _length_prefixed_strings(data)
    name_offsets = []
    for o, s in strs:
        if _is_bone_name(s):
            continue
        sl = s.lower()
        if sl.endswith(".tga") or sl.endswith(".dds") or "textures" in sl:
            continue
        name_offsets.append((o, s, o + 4 + _i32(data, o)))  # (prefix, name, name_end)
    name_offsets.sort()

    def nearest_name(counts_off):
        best = None
        for o, s, _e in name_offsets:
            if o <= counts_off:
                best = s
            else:
                break
        return best or "mesh"

    # --- collect candidate blocks from BOTH strategies, keyed by counts_off ---
    found = {}

    # (1) whole-file structural scan. Advance by 1 on miss; on hit, record and
    #     continue scanning from just AFTER this block's counts (so an adjacent
    #     block whose header sits inside the slack is still found).
    o = 0
    while o < n - 6:
        r = _try_decode_at(data, o)
        if r:
            found[r["counts_off"]] = r
            # jump to the end of the decoded payload, but step back a little so
            # we never skip a following header that abuts this block.
            end = r["pos_off"] + r["nv"] * 24 + r["nf"] * 6 + 4 + r["nv"] * 8
            o = max(o + 2, end - 4)
        else:
            o += 1

    # (2) name-anchored pass: for every object name, scan a window after it.
    for _p, _s, name_end in name_offsets:
        for off in range(name_end, min(name_end + 256, n - 6)):
            r = _try_decode_at(data, off)
            if r and r["counts_off"] not in found:
                found[r["counts_off"]] = r
                break

    # --- finalise: bone tables, labels, de-dup repeated names ---
    out = []
    used_names = {}
    for counts_off in sorted(found):
        r = found[counts_off]
        # rigid = single-bone (no per-vertex table); flexi = multi-bone (table).
        r["is_flexi"] = r["bone_table"] is not None
        if r["bone_table"] is None:
            hb = _header_bone(data, counts_off, max(0, counts_off - 96))
            r["bone_table"] = [hb] * r["nv"]
        nm = nearest_name(counts_off)
        if nm in used_names:
            used_names[nm] += 1
            r["name"] = "%s_%d" % (nm, used_names[nm])
        else:
            used_names[nm] = 0
            r["name"] = nm
        # weapon classification (CA: model_node_type_from_string)
        r["weapon_type"] = _model_node_type_from_string(r["name"])
        out.append(r)

    # Order like the engine builds its buffer: primary weapon first, then the
    # rest, then secondary weapon last. (Cosmetic for import, but keeps parity
    # with the game and makes weapon parts easy to find.)
    def order_key(r):
        if r["weapon_type"] == "primary":
            return (0,)
        if r["weapon_type"] == "secondary":
            return (2,)
        return (1,)
    out.sort(key=order_key)
    return out


# --------------------------------------------------------------------------- #
#  glTF / GLB sidecar reader (still supported as an optional override)
# --------------------------------------------------------------------------- #
def find_sidecar(cas_path):
    base = os.path.splitext(cas_path)[0]
    stem = os.path.basename(base).lower()
    folder = os.path.dirname(os.path.abspath(cas_path))
    for ext in (".glb", ".gltf"):
        if os.path.isfile(base + ext):
            return base + ext
    try:
        candidates = []
        for fn in os.listdir(folder):
            low = fn.lower()
            if not low.endswith((".glb", ".gltf")):
                continue
            fstem = os.path.splitext(low)[0]
            if fstem == stem or fstem.startswith(stem) or stem.startswith(fstem) \
                    or stem in fstem or fstem in stem:
                candidates.append(fn)
        if candidates:
            candidates.sort(key=lambda f: abs(len(os.path.splitext(f)[0]) - len(stem)))
            return os.path.join(folder, candidates[0])
    except OSError:
        pass
    return None


def read_gltf(path):
    import json
    with open(path, "rb") as fh:
        raw = fh.read()
    if raw[:4] == b"glTF":
        length = struct.unpack_from("<I", raw, 8)[0]
        o = 12
        gltf = None
        bins = b""
        while o < length:
            clen, ctype = struct.unpack_from("<II", raw, o)
            chunk = raw[o + 8:o + 8 + clen]
            if ctype == 0x4E4F534A:
                gltf = json.loads(chunk)
            elif ctype == 0x004E4942:
                bins = chunk
            o += 8 + clen
    else:
        gltf = json.loads(raw.decode("utf-8"))
        bins = b""
        if gltf.get("buffers") and "uri" in gltf["buffers"][0]:
            uri = gltf["buffers"][0]["uri"]
            if uri.startswith("data:"):
                import base64
                bins = base64.b64decode(uri.split(",", 1)[1])
            else:
                with open(os.path.join(os.path.dirname(path), uri), "rb") as bf:
                    bins = bf.read()
    acc = gltf["accessors"]
    bvs = gltf["bufferViews"]
    comp = {5120: "b", 5121: "B", 5122: "h", 5123: "H", 5125: "I", 5126: "f"}
    ncomp = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4, "MAT4": 16}

    def read_accessor(ai):
        a = acc[ai]
        bv = bvs[a["bufferView"]]
        off = bv.get("byteOffset", 0) + a.get("byteOffset", 0)
        c = comp[a["componentType"]]
        nc = ncomp[a["type"]]
        sz = struct.calcsize(c)
        stride = bv.get("byteStride") or sz * nc
        res = []
        for k in range(a["count"]):
            b = off + k * stride
            v = struct.unpack_from("<%d%s" % (nc, c), bins, b)
            res.append(v if nc > 1 else v[0])
        return res

    meshes = []
    for mesh in gltf.get("meshes", []):
        for prim in mesh["primitives"]:
            attr = prim["attributes"]
            pos = read_accessor(attr["POSITION"])
            nrm = read_accessor(attr["NORMAL"]) if "NORMAL" in attr else []
            uv = read_accessor(attr["TEXCOORD_0"]) if "TEXCOORD_0" in attr else []
            if "indices" in prim:
                idx = read_accessor(prim["indices"])
            else:
                idx = list(range(len(pos)))
            faces = [(idx[i], idx[i + 1], idx[i + 2])
                     for i in range(0, len(idx) - 2, 3)]
            meshes.append(dict(name=mesh.get("name", "mesh"),
                               verts=pos, normals=nrm, faces=faces, uvs=uv))
    return meshes
