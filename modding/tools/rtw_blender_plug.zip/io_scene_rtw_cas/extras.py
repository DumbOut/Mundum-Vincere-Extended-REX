# SPDX-License-Identifier: GPL-3.0-or-later
"""
extras.py
=========
Extra quality-of-life operators that go beyond plain import/export:

  * RTW_OT_inspect        - hex/float/int dump of a .cas header for reconciling
                            the binary layout against real game files.
  * RTW_OT_batch_import   - import every .cas in a folder in one go.
  * RTW_OT_make_lods      - generate LOD1/2/3 by Decimate (single-weight) like
                            the CA LOD pipeline.
  * RTW_OT_single_weights - collapse multi-bone weighting to single bone
                            (required for lod1+ and weapons).
  * RTW_OT_validate       - check a unit against known RTW .cas limits.
  * RTW_OT_unit_card      - render a framed "unit card" thumbnail of the model.
"""

import os
import bpy
import mathutils
from bpy.props import StringProperty, IntProperty, FloatProperty, BoolProperty
from bpy_extras.io_utils import ImportHelper

from . import cas_format
from . import import_cas


# --------------------------------------------------------------------------- #
class RTW_OT_inspect(bpy.types.Operator, ImportHelper):
    """Dump the header of a .cas file to the console / info bar for debugging"""
    bl_idname = "rtw.inspect_cas"
    bl_label = "Inspect .cas"
    filename_ext = ".cas"
    filter_glob: StringProperty(default="*.cas", options={'HIDDEN'})

    def execute(self, context):
        try:
            with open(self.filepath, "rb") as f:
                data = f.read()
        except Exception as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        report = cas_format.inspect_header(data)
        print("\n=== RTW .cas inspection: %s ===" % self.filepath)
        print(report)
        # Surface the version line in the status bar.
        first = report.splitlines()[-1]
        self.report({'INFO'}, first)
        return {'FINISHED'}


# --------------------------------------------------------------------------- #
class RTW_OT_batch_import(bpy.types.Operator, ImportHelper):
    """Import every .cas file in the chosen folder"""
    bl_idname = "rtw.batch_import"
    bl_label = "Batch Import Folder"
    filename_ext = ""
    directory: StringProperty(subtype='DIR_PATH')
    filter_glob: StringProperty(default="*.cas", options={'HIDDEN'})
    use_subdirs: BoolProperty(name="Include Sub-folders", default=False)

    def execute(self, context):
        folder = self.directory or os.path.dirname(self.filepath)
        count = 0
        walker = os.walk(folder) if self.use_subdirs else [(folder, [], os.listdir(folder))]
        for root, _dirs, files in walker:
            for fn in files:
                if fn.lower().endswith(".cas"):
                    try:
                        bpy.ops.import_scene.rtw_cas(filepath=os.path.join(root, fn))
                        count += 1
                    except Exception as e:
                        print("Skipped %s: %s" % (fn, e))
        self.report({'INFO'}, "Batch imported %d file(s)" % count)
        return {'FINISHED'}


# --------------------------------------------------------------------------- #
class RTW_OT_make_lods(bpy.types.Operator):
    """Generate LOD1-3 copies of the active mesh via Decimate, single-weighted"""
    bl_idname = "rtw.make_lods"
    bl_label = "Generate LODs"
    bl_options = {'REGISTER', 'UNDO'}

    lod1_ratio: FloatProperty(name="LOD1", default=0.6, min=0.05, max=1.0)
    lod2_ratio: FloatProperty(name="LOD2", default=0.3, min=0.05, max=1.0)
    lod3_ratio: FloatProperty(name="LOD3", default=0.12, min=0.02, max=1.0)

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'MESH'

    def execute(self, context):
        src = context.active_object
        ratios = [self.lod1_ratio, self.lod2_ratio, self.lod3_ratio]
        for i, r in enumerate(ratios, start=1):
            dup = src.copy()
            dup.data = src.data.copy()
            dup.name = "%s_lod%d" % (src.name.split("_lod")[0], i)
            context.collection.objects.link(dup)
            mod = dup.modifiers.new("LOD_Decimate", 'DECIMATE')
            mod.ratio = r
            dup.location.x += src.dimensions.x * 1.5 * i
        self.report({'INFO'}, "Created 3 LOD copies (lod1-3)")
        return {'FINISHED'}


# --------------------------------------------------------------------------- #
class RTW_OT_single_weights(bpy.types.Operator):
    """Set every vertex of selected meshes to single-bone weighting (lod1+/weapons)"""
    bl_idname = "rtw.single_weights"
    bl_label = "Collapse to Single Weights"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        meshes = [o for o in context.selected_objects if o.type == 'MESH']
        affected = 0
        for obj in meshes:
            for v in obj.data.vertices:
                groups = [(g.group, g.weight) for g in v.groups if g.weight > 0]
                if len(groups) <= 1:
                    continue
                groups.sort(key=lambda x: -x[1])
                keep = groups[0][0]
                for gi, _w in groups:
                    vg = obj.vertex_groups[gi]
                    if gi == keep:
                        vg.add([v.index], 1.0, 'REPLACE')
                    else:
                        vg.remove([v.index])
                affected += 1
        self.report({'INFO'}, "Single-weighted %d vertices" % affected)
        return {'FINISHED'}


# --------------------------------------------------------------------------- #
class RTW_OT_validate(bpy.types.Operator):
    """Check selected meshes against known RTW .cas constraints"""
    bl_idname = "rtw.validate"
    bl_label = "Validate for RTW"

    def execute(self, context):
        meshes = [o for o in context.selected_objects if o.type == 'MESH']
        if not meshes:
            meshes = [o for o in context.scene.objects if o.type == 'MESH']
        issues = []
        for obj in meshes:
            if len(obj.data.materials) > 1:
                issues.append("%s: %d materials (a .cas group allows only 1)"
                              % (obj.name, len(obj.data.materials)))
            # dual-weight vertex count check (type-3 ~200 vert limit per file)
            multi = sum(1 for v in obj.data.vertices
                        if len([g for g in v.groups if g.weight > 0]) > 1)
            if multi > 200:
                issues.append("%s: %d dual-weighted verts (>200 risks crashes)"
                              % (obj.name, multi))
            if not obj.data.uv_layers:
                issues.append("%s: no UV map" % obj.name)
        if issues:
            for i in issues:
                print("[RTW validate] " + i)
            self.report({'WARNING'}, "%d issue(s) - see console" % len(issues))
        else:
            self.report({'INFO'}, "All checks passed")
        return {'FINISHED'}


# --------------------------------------------------------------------------- #
class RTW_OT_unit_card(bpy.types.Operator):
    """Render a framed unit-card thumbnail of the active model"""
    bl_idname = "rtw.unit_card"
    bl_label = "Render Unit Card"

    resolution: IntProperty(name="Size", default=160, min=48, max=512)
    filepath: StringProperty(subtype='FILE_PATH', default="//unit_card.png")

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        scene = context.scene
        old_res = (scene.render.resolution_x, scene.render.resolution_y)
        old_path = scene.render.filepath
        scene.render.resolution_x = self.resolution
        scene.render.resolution_y = self.resolution
        scene.render.filepath = bpy.path.abspath(self.filepath)
        scene.render.film_transparent = True
        try:
            bpy.ops.render.render(write_still=True)
            self.report({'INFO'}, "Unit card written: %s" % self.filepath)
        except Exception as e:
            self.report({'ERROR'}, "Render failed: %s" % e)
            return {'CANCELLED'}
        finally:
            scene.render.resolution_x, scene.render.resolution_y = old_res
            scene.render.filepath = old_path
        return {'FINISHED'}


classes = (
    RTW_OT_inspect,
    RTW_OT_batch_import,
    RTW_OT_make_lods,
    RTW_OT_single_weights,
    RTW_OT_validate,
    RTW_OT_unit_card,
)
