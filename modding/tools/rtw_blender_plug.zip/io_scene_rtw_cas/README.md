# Rome: Total War `.cas` Tools for Blender

Import and export Rome: Total War (also M2TW / Rome Remastered) `.cas` models —
mesh, skeleton, vertex weighting and animation — wired into Blender's
**File ▸ Import / Export** menus just like the FBX add-on, with a dedicated
**Rome: Total War** sidebar tab headed by the Julii icon. Matching `.tga` / `.dds`
textures are found and loaded automatically.

Structure follows the Blender Source Tools pattern (a small package of focused
modules) rather than one giant script.

## Install

1. Keep the folder zipped as `io_scene_rtw_cas.zip` (don't unzip).
2. Blender ▸ **Edit ▸ Preferences ▸ Add-ons ▸ Install…** ▸ pick the zip.
3. Enable **"Rome: Total War .cas Tools"**.
4. Use **File ▸ Import ▸ Rome: Total War (.cas)** / **Export**, or the sidebar
   (press **N** in the 3D viewport ▸ **Rome: Total War** tab).

Works on Blender 3.0–4.x. (For the 4.2+ extensions system you can wrap it with a
`blender_manifest.toml`, but legacy install-from-zip works as-is.)

## Features

- **Import**: builds an armature from the bones, one mesh per group, restores
  UVs/normals, single **and** dual ("type 3" / `model_flexi_m`) bone weights,
  materials, and embedded animation as a 20 fps Action.
- **Export**: bone hierarchy (parents written before children), per-vertex
  weights (single or dual), UVs, normals, the texture reference, and a baked
  armature action. FBX-like loop-splitting so UV/normal seams survive.
- **Auto textures**: searches nearby `textures/` folders for the group's
  `.tga`/`.dds` (DDS preferred for Remastered PBR), wires Base Color + Alpha,
  and hooks up `_normal` companion maps when present.
- **Extras** (sidebar):
  - *Batch Import Folder* — import every `.cas` in a directory.
  - *Generate LODs* — Decimate-based LOD1–3 like the CA pipeline.
  - *Collapse to Single Weights* — required for lod1+ and weapon meshes.
  - *Validate for RTW* — flags >1 material per group, >200 dual-weighted verts,
    missing UVs.
  - *Inspect .cas Header* — hex/float/int dump to reconcile the binary layout.
  - *Render Unit Card* — quick framed thumbnail of the model.

## Kitbash Texture Baker (sidebar ▸ "Kitbash Texture Baker")

For building a new asset (e.g. a shield) out of parts taken from several
differently-textured meshes, without re-puzzling UVs in Photoshop:

1. Select all the kitbash mesh parts.
2. **Bake Kitbash Atlas** ▸ set a name (e.g. `new_shield`), size (default 512),
   and options.

It joins the parts, packs every island into one fresh **RTW_Atlas** UV layout,
pins each part's source texture to its *original* UVs, then bakes the diffuse
colour (and optionally the alpha mask) into a single square power-of-two image,
saves it as **.tga**, and assigns one clean RTW-style single-diffuse material.
The result is a game-ready unit/asset texture + matching UVs in one click.

Options: UV method (Repack islands / Smart UV / Lightmap), texture size
(128–2048), seam-bleed padding, alpha baking, output folder/format, and whether
to replace the old materials and drop the source UV layers.

> Baking runs in Cycles and a real render context, so it executes inside
> Blender (it can't be unit-tested head-less).


## Importing meshes (geometry) — works from a bare .cas

The full model `.cas` mesh format is decoded and validated byte-for-byte against
a glTF reference: every object's positions, normals, faces and UVs reconstruct
with **zero error**, for both single-bone parts and multi-bone meshes (e.g. the
254-vertex `body` spanning 14 bones, via a per-vertex bone-index table in the
object header). **No glTF/GLB sidecar is required.**

What you need for correct world placement is the **bind pose**, because `.cas`
stores vertices bone-local. The importer gets it from, in order:

1. a **skeletons.dat** you point at (the "Skeleton .dat" field) — reads the real
   bind pose for that skeleton (validated to sub-mm), or
2. the **built-in bind table** for the common `fs_semi_naked` human family, used
   automatically when no `.dat` is given.

With either, a bare `.cas` imports as the complete model — all meshes named
(`body`, `Object01`…), world-placed, upright (Y-up→Z-up corrected), and skinned
with per-vertex bone weights to the armature.

Optional: tick "Prefer Sidecar Over .cas" to use a same-named `.glb`/`.gltf`
instead of decoding the `.cas` directly (off by default). Export preserves the
original mesh names and round-trips orientation.

## Exporting

The exporter offers two formats (Export dialog ▸ Format):

- **Vanilla (game-loadable)** — writes the real RTW `.cas` the game loads by
  **injecting your edited geometry into the original unit `.cas`**. Set the
  **Template .cas** field (Export dialog) to the unmodified unit file. Its
  skeleton/scene-graph (class-0), scene-settings (class 9), the empty list
  chunks (class 3/8/10) and the material (class 5) are kept **byte-for-byte** —
  the game requires the class-0 scene/node chunk, and a from-scratch file that
  omits it triggers the loader's fatal *"Scene data chunk not found"*. Only the
  **rigid** (single-bone) and **flexi** (multi-bone) geometry chunks are rebuilt,
  in the exact verified layout (origin transform, per-vertex bone table, vertex
  colours, UVs and `exclude_lights` included). Parts are matched to the template
  by name: a topology-preserving edit reuses the original part's structure and
  swaps in your new positions/normals/UVs (a no-change export reproduces the
  source file exactly); a vertex-count change is rebuilt best-effort, and for
  heavy retopology IWTE or Feral's `casconv` remains the safer route. **Without a
  Template .cas the file will not load** (the exporter warns).
- **Round-trip (Blender)** — the add-on's tagged format for byte-perfect
  re-import into Blender (not loadable by the game).

Set "Texture Name" to control the material's texture reference, or leave it
blank to use the object's material image (falling back to `<casname>.tga`).

## About the binary format (reconciled against a real file)

The importer now parses `.cas` the way Creative Assembly's own loader does
(confirmed against their `cas_loader.cpp`, `cas_flexi_data.cpp` and the rigid
loader source). The file is a float32 version, scene data, then a sequence of
chunks. Geometry objects come in two kinds: **rigid** parts are single-bone (one
node index for the whole part — head, weapons, shields) and **flexi** parts are
multi-bone (a per-vertex node index — the body). Each object stores a name, an
optional properties string, an optional local origin (quaternion + translation),
vertex/face counts, an `is_textured` flag (UVs are present only when set), an
`uses_cverts` flag (optional per-vertex colours), the per-vertex node indices
(flexi) or a single header node index (rigid), positions, normals, faces, a
material index, then UVs and colours. A primary weapon is placed first in the
buffer and a secondary weapon last. This matches the byte layout reverse-
engineered here, which reconstructs a reference model with zero error; a tolerant
structural scan still backs up the parser for any unusual variant.

### Recent additions
- **Faithful chunk parser** (rigid/flexi/material/cverts/origin) with the
  structural scanner as a fallback, so all meshes — including the body and the
  primary weapon — come through.
- **Import Vertex Colors** option: brings in per-vertex colours (cverts) as a
  Color attribute when the file has them.
- **Part metadata**: each imported object records whether it was rigid or flexi,
  its material index, and any weapon role, as custom properties (useful for
  inspection and faithful re-export).

`.cas` is a proprietary Creative Assembly format with **no official public
spec**. The layout in **`cas_format.py`** was reconciled against a real vanilla
model (`gaul_revenger.cas`, version 3.18). Verified and implemented:

- `float32` version at offset 0.
- The skeleton: bone **names** are length-prefixed with the length **including
  the null terminator** (this was the bug behind the old "implausible string
  length" crash), plus an early `int32` **parent-index array** — so bone names
  and the full hierarchy import correctly.
- Mesh group / object names and the texture path are extracted too.

Not yet byte-decoded for vanilla files: per-vertex mesh geometry and the
embedded animation frames, and bone **bind positions** (RTW models take the
bind pose from the external skeleton `.dat`, so those slots are zero in the
model file). For vanilla files the importer therefore builds the correct,
named, correctly-parented armature with an automatic readable layout, loads the
referenced texture, lists the mesh groups, and reports the rest — it never
crashes. To get vanilla meshes as geometry today, convert via IWTE or Feral's
`casconv` to FBX/DAE.

Files **exported by this add-on** carry a small `CASB` tag after the version
float and round-trip with full fidelity (bones, weights, UVs, geometry,
animation) — that's the FBX-like Blender↔cas workflow. `cas_format.py` is the
single point of truth; share an IWTE-converted reference of a file and the
vanilla geometry decode can be extended there.
