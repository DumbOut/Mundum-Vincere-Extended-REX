# SPDX-License-Identifier: GPL-3.0-or-later
"""
ui.py
=====
Sidebar (N-panel) UI for the add-on, living in the 3D viewport under a
"Rome: Total War" tab, headed with the Julii icon. Mirrors the Blender Source
Tools "Source Engine Exportables" panel idea: quick import/export plus the
extra tools, all in one place.
"""

import bpy


class VIEW3D_PT_rtw_cas(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Rome: Total War"
    bl_label = "Rome: Total War .cas"

    def draw_header(self, context):
        from . import get_icon_id
        self.layout.label(text="", icon_value=get_icon_id("julii"))

    def draw(self, context):
        from . import get_icon_id
        layout = self.layout

        box = layout.box()
        box.label(text="Import / Export", icon='FILE_TICK')
        col = box.column(align=True)
        col.scale_y = 1.2
        col.operator("import_scene.rtw_cas", text="Import .cas",
                     icon_value=get_icon_id("julii"))
        col.operator("export_scene.rtw_cas", text="Export .cas",
                     icon_value=get_icon_id("julii"))
        box.operator("rtw.batch_import", text="Batch Import Folder",
                     icon='FILEBROWSER')

        box = layout.box()
        box.label(text="Modeling Tools", icon='MODIFIER')
        box.operator("rtw.make_lods", text="Generate LODs", icon='MOD_DECIM')
        box.operator("rtw.single_weights", text="Collapse to Single Weights",
                     icon='GROUP_VERTEX')
        box.operator("rtw.validate", text="Validate for RTW", icon='CHECKMARK')

        box = layout.box()
        box.label(text="Kitbash Texture Baker", icon='TEXTURE')
        col = box.column(align=True)
        col.scale_y = 1.2
        col.operator("rtw.bake_atlas", text="Bake Kitbash Atlas",
                     icon='RENDERLAYERS')
        box.label(text="Select parts \u2192 one clean .tga", icon='INFO')

        box = layout.box()
        box.label(text="Diagnostics & Cards", icon='ZOOM_ALL')
        box.operator("rtw.inspect_cas", text="Inspect .cas Header",
                     icon='VIEWZOOM')
        box.operator("rtw.unit_card", text="Render Unit Card", icon='RENDER_STILL')


class VIEW3D_PT_rtw_about(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Rome: Total War"
    bl_label = "About"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.label(text="RTW .cas Tools", icon='INFO')
        col.label(text="Import/export Rome: Total War")
        col.label(text="models, skeletons & animation.")
        col.separator()
        col.label(text="Binary layout lives in cas_format.py")
        col.label(text="— adjust there to match a file.")


classes = (
    VIEW3D_PT_rtw_cas,
    VIEW3D_PT_rtw_about,
)
