# SPDX-License-Identifier: GPL-3.0-or-later
"""
import_cas.py
=============
Imports a Rome: Total War .cas model into Blender: builds the armature from the
skeleton, one mesh object per group, single/dual bone vertex weights, materials
with auto-loaded textures, and (if present) the animation as an Action at 20fps.
"""

import os
import math
import bpy
import mathutils
from bpy.props import StringProperty, BoolProperty, FloatProperty, EnumProperty
from bpy_extras.io_utils import ImportHelper

from . import cas_format
from . import cas_geometry
from . import skeletons as skel_lib
from . import skeleton_dat
from . import textures as tex_mod


def _rot_to_matrix(rot9, translation):
    m = mathutils.Matrix((
        (rot9[0], rot9[1], rot9[2], translation[0]),
        (rot9[3], rot9[4], rot9[5], translation[1]),
        (rot9[6], rot9[7], rot9[8], translation[2]),
        (0.0, 0.0, 0.0, 1.0),
    ))
    return m


def _axis_conversion(scale):
    # RTW is Z-up, X-forward-ish; Blender is Z-up. Apply uniform scale + keep
    # orientation. A correction matrix is exposed so users can flip if needed.
    return mathutils.Matrix.Scale(scale, 4)


class ImportCAS(bpy.types.Operator, ImportHelper):
    """Import a Rome: Total War .cas model (mesh, skeleton, weights, textures)"""
    bl_idname = "import_scene.rtw_cas"
    bl_label = "Import Rome: Total War (.cas)"
    bl_options = {'PRESET', 'UNDO'}

    filename_ext = ".cas"
    filter_glob: StringProperty(default="*.cas", options={'HIDDEN'})

    global_scale: FloatProperty(
        name="Scale", default=1.0, min=0.0001, max=1000.0,
        description="Uniform scale applied on import")
    import_skeleton: BoolProperty(
        name="Import Skeleton", default=True,
        description="Build an armature from the .cas bones")
    import_animation: BoolProperty(
        name="Import Animation", default=True,
        description="Load embedded animation as an Action (20 fps)")
    auto_textures: BoolProperty(
        name="Auto-load Textures", default=True,
        description="Search nearby folders for matching .tga/.dds and build materials")
    recalc_normals: BoolProperty(
        name="Recalculate Normals", default=False,
        description="Recompute normals instead of using the stored ones")
    two_sided: BoolProperty(
        name="Two-sided (no backface cull)", default=True,
        description="Make materials render both sides so single-sided RTW "
                    "shields/capes/weapons don't appear black or see-through")
    import_vertex_colors: BoolProperty(
        name="Import Vertex Colors", default=False,
        description="If the .cas stores per-vertex colours (cverts), import "
                    "them as a 'Color' attribute")
    decode_geometry: BoolProperty(
        name="Decode .cas Geometry", default=True,
        description="Attempt to decode mesh geometry directly from the .cas "
                    "(bone-local; experimental for vanilla files)")
    use_sidecar: BoolProperty(
        name="Allow glTF/GLB Sidecar", default=True,
        description="Permit using a same-named .glb/.gltf if present")
    prefer_sidecar: BoolProperty(
        name="Prefer Sidecar Over .cas", default=False,
        description="When a sidecar exists, use it instead of decoding the .cas "
                    "directly (off by default: the .cas decodes fully on its own)")
    skeleton_dat_path: StringProperty(
        name="Skeleton .dat", default="", subtype='FILE_PATH',
        description="Optional path to skeletons.dat (data/animations/). Supplies "
                    "the bind pose so a bare .cas places bones and meshes in "
                    "world space for ANY unit on that skeleton")

    def execute(self, context):
        try:
            with open(self.filepath, "rb") as f:
                data = f.read()
            model = cas_format.read_model(data)
        except Exception as e:
            self.report({'ERROR'}, "Failed to read .cas: %s" % e)
            return {'CANCELLED'}

        name = os.path.splitext(os.path.basename(self.filepath))[0]

        # Build ONE shared material for the whole unit. Every mesh in an RTW unit
        # references the same texture (e.g. barb_headhunting_maiden.tga), so all
        # imported meshes share a single material/texture map rather than getting
        # a separate material each.
        self._shared_material = None
        if self.auto_textures:
            tex_ref = ""
            for g in model.groups:
                if g.texture:
                    tex_ref = g.texture
                    break
            if not tex_ref:
                # fall back to the model's embedded/scanned texture name, else
                # assume <casname>.tga sitting alongside.
                tex_ref = name + ".tga"
            mat, _ = tex_mod.build_material(name, self.filepath, tex_ref,
                                            auto_load=True)
            self._shared_material = mat

        # Decide orientation up front. RTW data (skeleton .dat bind pose, .cas
        # mesh data) and glTF sidecars are all Y-up; Blender is Z-up. Apply the
        # standard +90 deg X rotation so the model stands upright and matches a
        # reference .blend, and use the SAME correction for bones and meshes so
        # they stay aligned.
        yup_to_zup = mathutils.Matrix.Rotation(math.radians(90.0), 4, 'X')
        corr = _axis_conversion(self.global_scale) @ yup_to_zup

        armature_obj = None
        if self.import_skeleton and model.bones:
            armature_obj = self._build_armature(context, name, model, corr)

        built_groups = 0
        for gi, group in enumerate(model.groups):
            if not group.vertices:
                continue  # vanilla group name with no decoded geometry
            self._build_group(context, name, gi, group, model,
                               armature_obj, corr)
            built_groups += 1

        # --- Geometry for vanilla files ----------------------------------- #
        # Primary path: decode meshes directly from the .cas (no GLB needed).
        # A glTF/GLB sidecar is used only if the user opts in AND one is found,
        # as an override for cases where they prefer the DCC-exported mesh.
        sidecar_built = 0
        cas_decoded = 0
        if model.partial:
            sidecar = None
            if self.use_sidecar:
                sidecar = cas_geometry.find_sidecar(self.filepath)
            if sidecar and self.prefer_sidecar:
                sidecar_built = self._build_from_sidecar(
                    context, name, sidecar, armature_obj, corr)
            if not sidecar_built and self.decode_geometry:
                cas_decoded = self._build_from_cas_geometry(
                    context, name, data, model, armature_obj, corr)
            # Fall back to sidecar if direct decode produced nothing.
            if not cas_decoded and not sidecar_built and sidecar:
                sidecar_built = self._build_from_sidecar(
                    context, name, sidecar, armature_obj, corr)

        if (self.import_animation and model.animation and armature_obj):
            self._apply_animation(context, armature_obj, model, corr)

        if model.notes:
            print("\n=== RTW .cas import: %s ===" % self.filepath)
            for n in model.notes:
                print("  - " + n)

        if model.partial and (sidecar_built or cas_decoded):
            src = ("glTF/GLB sidecar" if sidecar_built else ".cas geometry")
            self.report({'INFO'}, "Imported %d bone(s) + %d mesh(es) from %s"
                         % (len(model.bones),
                            sidecar_built or cas_decoded, src))
            return {'FINISHED'}

        if model.partial:
            tex = model.groups[0].texture if model.groups else ""
            if tex and self.auto_textures:
                from . import textures as _t
                tp = _t.find_texture(self.filepath, tex)
                if tp:
                    try:
                        bpy.data.images.load(tp, check_existing=True)
                    except Exception:
                        pass
            self.report(
                {'WARNING'},
                "Imported skeleton (%d bones). %d mesh group(s) named but "
                "geometry not decoded for this vanilla file - see console. "
                "Use IWTE/casconv for meshes."
                % (len(model.bones), len(model.groups)))
        else:
            self.report({'INFO'}, "Imported %d group(s), %d bone(s)%s"
                         % (built_groups, len(model.bones),
                            " + animation" if model.animation else ""))
        return {'FINISHED'}

    # ----------------------------------------------------------------- #
    def _needs_autolayout(self, model):
        """True when bind positions are absent (all bone translations ~0)."""
        if model.partial:
            return True
        return all(abs(b.translation[0]) < 1e-6 and abs(b.translation[1]) < 1e-6
                   and abs(b.translation[2]) < 1e-6 for b in model.bones)

    def _build_armature(self, context, name, model, corr):
        arm_data = bpy.data.armatures.new("armature")
        arm_obj = bpy.data.objects.new("armature", arm_data)
        context.collection.objects.link(arm_obj)
        context.view_layer.objects.active = arm_obj
        bpy.ops.object.mode_set(mode='EDIT')

        if self._needs_autolayout(model):
            self._build_armature_autolayout(arm_data, model, corr)
        else:
            self._build_armature_from_transforms(arm_data, model, corr)

        bpy.ops.object.mode_set(mode='OBJECT')
        return arm_obj

    def _resolve_binds(self, model):
        """Return (source_name, [world bind pos per bone]) or (None, None).
        Prefers a user-supplied skeletons.dat, then the built-in table."""
        names = [b.name for b in model.bones]
        parents = [b.parent for b in model.bones]
        dat_path = bpy.path.abspath(self.skeleton_dat_path) if self.skeleton_dat_path else ""
        if dat_path and os.path.isfile(dat_path):
            try:
                with open(dat_path, "rb") as fh:
                    dat = fh.read()
                binds = skeleton_dat.bind_world_positions(dat, names, parents)
                if binds:
                    return ("skeletons.dat", binds)
            except Exception as e:
                print("[RTW] skeleton.dat read failed: %s" % e)
        sk_name, binds = skel_lib.bind_positions_for(names)
        if binds and any(b is not None for b in binds):
            # The built-in table is ALREADY in the same (glTF / Y-up, +Z)
            # convention the importer's axis-correction (corr) expects, so it is
            # used DIRECTLY — with no Z flip.
            #
            # The previous code flipped Z here ("to match the .dat/mesh Y-up
            # convention"), but that mirrored the whole rig front-to-back: it
            # threw the cloak bones off by ~0.4-0.7, the arms/feet by a few cm,
            # and corrupted the world mesh placement that re-uses these binds.
            # Used unflipped, the rig reproduces the reference glTF/GLB exactly.
            #
            # Any bone the table does not know (e.g. weapon / shield / finger
            # bones on a fuller skeleton) inherits its parent's already-resolved
            # position, so a partial match still places the ENTIRE rig instead
            # of collapsing to the fallback auto-layout (parents precede
            # children in .cas bone order, so the parent is always resolved
            # first).
            filled = []
            for i, bp in enumerate(binds):
                if bp is not None:
                    filled.append((bp[0], bp[1], bp[2]))
                else:
                    p = parents[i] if i < len(parents) else cas_format.NO_PARENT
                    filled.append(filled[p] if 0 <= p < len(filled)
                                  else (0.0, 0.0, 0.0))
            tag = "built-in:%s" % sk_name
            if any(b is None for b in binds):
                tag += " (unrecognised bones inherited from parent)"
            return (tag, filled)
        return (None, None)

    def _build_armature_autolayout(self, arm_data, model, corr):
        """Place bones at their real world bind positions when the file's bone
        set matches a known RTW skeleton; otherwise lay out a readable rig."""
        bones = model.bones
        children = {i: [] for i in range(len(bones))}
        roots = []
        for i, b in enumerate(bones):
            if b.parent != cas_format.NO_PARENT and 0 <= b.parent < len(bones):
                children[b.parent].append(i)
            else:
                roots.append(i)

        # Try real bind positions from a .dat or the built-in skeleton library.
        sk_name, binds = self._resolve_binds(model)
        head = [None] * len(bones)
        if binds and all(bp is not None for bp in binds):
            for i, bp in enumerate(binds):
                head[i] = corr @ mathutils.Vector((bp[0], bp[1], bp[2]))
            model.notes.append("Armature placed using bind pose from %s."
                               % sk_name)
        else:
            STEP = 0.18

            def place(i, depth, x):
                head[i] = corr @ mathutils.Vector((x, 0.0, depth * STEP))
                kids = children[i]
                span = (len(kids) - 1) * STEP
                for n, k in enumerate(kids):
                    place(k, depth + 1, x - span / 2 + n * STEP)
            for n, r in enumerate(roots):
                place(r, 0, n * 1.0)
            model.notes.append("Bone set didn't match a known skeleton; used a "
                               "readable auto-layout (positions approximate).")

        ebones = [None] * len(bones)

        def _is_scene_root(nm):
            return nm.strip().lower() == "scene root"

        # Effective parent that skips any "Scene Root" link so bone_pelvis
        # becomes the armature root (no Scene Root bone is created).
        def eff_parent(i):
            p = bones[i].parent
            while p != cas_format.NO_PARENT and 0 <= p < len(bones) \
                    and _is_scene_root(bones[p].name):
                p = bones[p].parent
            return p

        for i, b in enumerate(bones):
            if _is_scene_root(b.name):
                continue  # don't create a bone for Scene Root
            eb = arm_data.edit_bones.new(b.name)
            eb.head = head[i]
            kids = [k for k in children[i] if not _is_scene_root(bones[k].name)]
            if kids:
                eb.tail = head[kids[0]]
            else:
                eb.tail = head[i] + mathutils.Vector((0, 0.05, 0))
            if (eb.tail - eb.head).length < 1e-4:
                eb.tail = eb.head + mathutils.Vector((0, 0.05, 0))
            ebones[i] = eb
        for i, b in enumerate(bones):
            if ebones[i] is None:
                continue
            p = eff_parent(i)
            if p != cas_format.NO_PARENT and 0 <= p < len(bones) and ebones[p]:
                ebones[i].parent = ebones[p]

    def _build_armature_from_transforms(self, arm_data, model, corr):
        bones = model.bones
        ebones = [None] * len(bones)

        def _is_scene_root(nm):
            return nm.strip().lower() == "scene root"

        def eff_parent(i):
            p = bones[i].parent
            while p != cas_format.NO_PARENT and 0 <= p < len(bones) \
                    and _is_scene_root(bones[p].name):
                p = bones[p].parent
            return p

        # The exporter writes each bone's ARMATURE-SPACE (already accumulated)
        # matrix as scale_m @ bone.matrix_local, so the stored rotation+
        # translation IS the world transform - it must NOT be re-accumulated
        # through the parent (doing so compounded every bone by its depth and
        # blew the rig apart). corr @ stored undoes the export axis swap, so a
        # default-scale export -> import round-trip is the identity.
        world_mat = [corr @ _rot_to_matrix(b.rotation, b.translation)
                     for b in bones]
        head = [world_mat[i].to_translation() for i in range(len(bones))]

        # Effective children (Scene Root collapsed away) so a bone's tail can
        # reach toward its first real child, matching the bind-pose builder.
        children = {i: [] for i in range(len(bones))}
        for i in range(len(bones)):
            p = eff_parent(i)
            if p != cas_format.NO_PARENT and 0 <= p < len(bones):
                children[p].append(i)

        for i, b in enumerate(bones):
            if _is_scene_root(b.name):
                continue  # don't create a bone for Scene Root
            eb = arm_data.edit_bones.new(b.name)
            eb.head = head[i]
            kids = [k for k in children[i] if not _is_scene_root(bones[k].name)]
            if kids:
                eb.tail = head[kids[0]]
            else:
                ydir = world_mat[i].to_3x3() @ mathutils.Vector((0, 1, 0))
                eb.tail = head[i] + ydir.normalized() * 0.1
            if (eb.tail - eb.head).length < 1e-4:
                eb.tail = eb.head + mathutils.Vector((0, 0.05, 0))
            ebones[i] = eb
        for i, b in enumerate(bones):
            if ebones[i] is None:
                continue
            p = eff_parent(i)
            if p != cas_format.NO_PARENT and 0 <= p < len(bones) and ebones[p]:
                ebones[i].parent = ebones[p]

    # ----------------------------------------------------------------- #
    def _make_mesh_object(self, context, objname, verts, faces, uvs, normals,
                          corr, texture, armature_obj):
        mesh = bpy.data.meshes.new(objname)
        obj = bpy.data.objects.new(objname, mesh)
        context.collection.objects.link(obj)
        bverts = [corr @ mathutils.Vector(v) for v in verts]
        # Drop degenerate faces and clamp indices.
        clean = [tuple(f) for f in faces
                 if len(set(f)) == 3 and max(f) < len(bverts)]
        mesh.from_pydata(bverts, [], clean)
        mesh.update()
        if uvs:
            uvl = mesh.uv_layers.new(name="UVMap")
            for poly in mesh.polygons:
                for li in poly.loop_indices:
                    vi = mesh.loops[li].vertex_index
                    if vi < len(uvs):
                        u, v = uvs[vi]
                        # .cas/glTF put V=0 at the top; Blender puts V=0 at the
                        # bottom, so flip V (matches Blender's glTF importer).
                        uvl.data[li].uv = (u, 1.0 - v)
        # Smooth shading so the imported normals light correctly.
        for poly in mesh.polygons:
            poly.use_smooth = True
        if normals and not self.recalc_normals:
            # Normalize stored normals (some objects store non-unit vectors,
            # which break shading and cause black faces) and rotate them into
            # the mesh's final space with the SAME correction as the verts.
            # Drop to Blender's computed normals if any are degenerate.
            rot3 = corr.to_3x3()
            norm_ok = True
            clean_normals = []
            for nrm in normals:
                ln = (nrm[0] ** 2 + nrm[1] ** 2 + nrm[2] ** 2) ** 0.5
                if ln < 1e-6:
                    norm_ok = False
                    break
                nv = rot3 @ mathutils.Vector((nrm[0] / ln, nrm[1] / ln,
                                              nrm[2] / ln))
                nv.normalize()
                clean_normals.append((nv.x, nv.y, nv.z))
            if norm_ok:
                try:
                    mesh.normals_split_custom_set_from_vertices(clean_normals)
                except Exception:
                    pass
        else:
            # No usable stored normals: make winding-consistent outward normals
            # so flat parts (shields) face the right way.
            try:
                import bmesh
                bm = bmesh.new()
                bm.from_mesh(mesh)
                bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
                bm.to_mesh(mesh)
                bm.free()
            except Exception:
                pass
        # Assign the single shared unit material (all meshes share one texture).
        if getattr(self, "_shared_material", None) is not None:
            mesh.materials.append(self._shared_material)
        elif self.auto_textures and texture:
            mat, _ = tex_mod.build_material(objname, self.filepath, texture,
                                            auto_load=True)
            mesh.materials.append(mat)
        if armature_obj:
            obj.parent = armature_obj
            mod = obj.modifiers.new("Armature", 'ARMATURE')
            mod.object = armature_obj
        return obj

    def _build_from_sidecar(self, context, name, sidecar, armature_obj, corr):
        """Import full world-space meshes from a glTF/GLB sidecar. The Y-up to
        Z-up correction is already baked into *corr* by execute()."""
        try:
            meshes = cas_geometry.read_gltf(sidecar)
        except Exception as e:
            print("[RTW] sidecar read failed: %s" % e)
            return 0
        built = 0
        for m in meshes:
            orig = m["name"].replace("__", " ")
            obj = self._make_mesh_object(
                context, orig,
                m["verts"], m["faces"], m.get("uvs"), m.get("normals"),
                corr, "", armature_obj)
            obj["rtw_name"] = orig
            obj.data["rtw_name"] = orig
            built += 1
        if built:
            print("[RTW] Imported %d mesh(es) from sidecar %s"
                  % (built, os.path.basename(sidecar)))
        return built

    def _build_from_cas_geometry(self, context, name, data, model,
                                 armature_obj, corr):
        """Decode and build ALL meshes directly from the .cas bytes, placing
        every vertex at its bind bone's world position (per-vertex), and binding
        each vertex to that bone with a weight. No glTF sidecar required."""
        try:
            objs = cas_geometry.locate_objects(data)
        except Exception as e:
            print("[RTW] geometry decode failed: %s" % e)
            return 0

        _sk, binds = self._resolve_binds(model)
        texture = model.groups[0].texture if model.groups else ""
        nbones = len(model.bones)

        built = 0
        for od in objs:
            bone_table = od.get("bone_table") or []
            # World position per vertex: bind[bone] + (x, y, -z).
            verts = []
            for i, v in enumerate(od["verts"]):
                bi = bone_table[i] if i < len(bone_table) else 0
                if binds and 0 <= bi < len(binds) and binds[bi] is not None:
                    bx, by, bz = binds[bi]
                else:
                    bx = by = bz = 0.0
                verts.append((v[0] + bx, v[1] + by, -v[2] + bz))
            normals = [(nrm[0], nrm[1], -nrm[2]) for nrm in od["normals"]]
            faces = [(f[0], f[2], f[1]) for f in od["faces"]]  # winding swap
            obj = self._make_mesh_object(
                context, od["name"], verts, faces, od["uvs"], normals,
                corr, texture, armature_obj)
            obj["rtw_name"] = od["name"]
            obj.data["rtw_name"] = od["name"]
            # Feature: store source metadata for fidelity & inspection.
            obj["rtw_part_type"] = "flexi" if od.get("is_flexi") else "rigid"
            obj["rtw_material_index"] = int(od.get("mtrl_index", -1))
            if od.get("weapon_type"):
                obj["rtw_weapon"] = od["weapon_type"]

            # Feature: import per-vertex colours (cverts) as a colour attribute
            # when present and requested.
            if self.import_vertex_colors and od.get("cverts"):
                try:
                    cv = od["cverts"]
                    col = obj.data.color_attributes.new(
                        name="Color", type='BYTE_COLOR', domain='CORNER')
                    for poly in obj.data.polygons:
                        for li in poly.loop_indices:
                            vi = obj.data.loops[li].vertex_index
                            if vi < len(cv):
                                col.data[li].color = cv[vi]
                except Exception:
                    pass

            # Per-vertex bone weights -> proper skinning. Scene Root no longer
            # exists as a bone (pelvis is the root), so any vertex bound to it
            # is re-routed to bone_pelvis.
            if armature_obj and binds and nbones:
                def _bone_name_for(bi):
                    nm = model.bones[bi].name
                    if nm.strip().lower() == "scene root":
                        for bb in model.bones:
                            if bb.name.lower().endswith("pelvis"):
                                return bb.name
                    return nm
                groups = {}
                for vi, bi in enumerate(bone_table):
                    if 0 <= bi < nbones:
                        groups.setdefault(_bone_name_for(bi), []).append(vi)
                for bname, vlist in groups.items():
                    if armature_obj.data.bones.get(bname) is None and \
                            bname not in [bb.name for bb in model.bones]:
                        continue
                    vg = obj.vertex_groups.get(bname) or obj.vertex_groups.new(name=bname)
                    vg.add(vlist, 1.0, 'REPLACE')
            built += 1
        if built:
            src = "world-placed via bind pose" if binds else \
                  "bone-local (no skeleton; supply skeletons.dat)"
            print("[RTW] Decoded %d mesh(es) directly from .cas (%s)."
                  % (built, src))
        return built

    # ----------------------------------------------------------------- #
    def _build_group(self, context, name, gi, group, model, armature_obj, corr):
        mesh = bpy.data.meshes.new("%s_%s_%d" % (name, group.name, gi))
        obj = bpy.data.objects.new(mesh.name, mesh)
        context.collection.objects.link(obj)

        verts = [corr @ mathutils.Vector(v.co) for v in group.vertices]
        faces = [f for f in group.faces]
        mesh.from_pydata(verts, [], faces)
        mesh.update()

        # UVs
        if group.vertices and any(v.uv != (0.0, 0.0) for v in group.vertices):
            uv_layer = mesh.uv_layers.new(name="UVMap")
            for poly in mesh.polygons:
                for li in poly.loop_indices:
                    vi = mesh.loops[li].vertex_index
                    u, v = group.vertices[vi].uv
                    uv_layer.data[li].uv = (u, 1.0 - v)  # flip V to Blender space

        # Normals
        if not self.recalc_normals and group.vertices:
            try:
                mesh.normals_split_custom_set_from_vertices(
                    [v.normal for v in group.vertices])
            except Exception:
                pass

        # Materials + textures (shared single material for the whole unit)
        if getattr(self, "_shared_material", None) is not None:
            mesh.materials.append(self._shared_material)
        elif self.auto_textures:
            mat, _ = tex_mod.build_material(group.name, self.filepath,
                                            group.texture, auto_load=True)
            mesh.materials.append(mat)

        # Skinning
        if armature_obj and model.bones:
            for b in model.bones:
                obj.vertex_groups.new(name=b.name)
            vg = obj.vertex_groups
            for vi, cv in enumerate(group.vertices):
                if 0 <= cv.bone0 < len(model.bones) and cv.weight0 > 0:
                    vg[model.bones[cv.bone0].name].add([vi], cv.weight0, 'REPLACE')
                if group.is_type3 and 0 <= cv.bone1 < len(model.bones) and cv.weight1 > 0:
                    vg[model.bones[cv.bone1].name].add([vi], cv.weight1, 'REPLACE')

            mod = obj.modifiers.new("Armature", 'ARMATURE')
            mod.object = armature_obj
            obj.parent = armature_obj

        return obj

    # ----------------------------------------------------------------- #
    def _apply_animation(self, context, arm_obj, model, corr):
        anim = model.animation
        context.view_layer.objects.active = arm_obj
        bpy.ops.object.mode_set(mode='POSE')

        action = bpy.data.actions.new(arm_obj.name + "_action")
        if arm_obj.animation_data is None:
            arm_obj.animation_data_create()
        arm_obj.animation_data.action = action

        scene = context.scene
        scene.render.fps = anim.fps
        scene.frame_start = 1
        scene.frame_end = max(1, len(anim.frames))

        pbones = arm_obj.pose.bones
        for fi, frame in enumerate(anim.frames):
            for bi, b in enumerate(model.bones):
                if b.name not in pbones or bi >= len(frame.rotations):
                    continue
                pb = pbones[b.name]
                rot9 = frame.rotations[bi]
                mat = _rot_to_matrix(rot9, (0, 0, 0))
                quat = mat.to_quaternion()
                pb.rotation_mode = 'QUATERNION'
                pb.rotation_quaternion = quat
                pb.keyframe_insert("rotation_quaternion", frame=fi + 1)
                if frame.translations and anim.bones_with_position \
                        and bi < len(anim.bones_with_position) \
                        and anim.bones_with_position[bi]:
                    t = corr @ mathutils.Vector(frame.translations[bi])
                    pb.location = t
                    pb.keyframe_insert("location", frame=fi + 1)

        bpy.ops.object.mode_set(mode='OBJECT')


def menu_func_import(self, context):
    from . import get_icon_id
    self.layout.operator(ImportCAS.bl_idname,
                         text="Rome: Total War (.cas)",
                         icon_value=get_icon_id("julii"))
