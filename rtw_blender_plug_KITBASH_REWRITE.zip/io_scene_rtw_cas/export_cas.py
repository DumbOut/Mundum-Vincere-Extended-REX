# SPDX-License-Identifier: GPL-3.0-or-later
"""
export_cas.py
=============
Exports Blender meshes + armature to a Rome: Total War .cas file, preserving
bone hierarchy, vertex weighting (single, or dual for type-3/model_flexi_m),
UVs, normals, the texture reference, and optionally a baked animation at 20fps.
"""

import os
import re
import bpy
import mathutils
from bpy.props import StringProperty, BoolProperty, FloatProperty, EnumProperty
from bpy_extras.io_utils import ExportHelper

from . import cas_format
from . import cas_vanilla


def _matrix_to_rot_trans(mat):
    rot = mat.to_3x3()
    rot9 = (rot[0][0], rot[0][1], rot[0][2],
            rot[1][0], rot[1][1], rot[1][2],
            rot[2][0], rot[2][1], rot[2][2])
    t = mat.to_translation()
    return rot9, (t.x, t.y, t.z)


class ExportCAS(bpy.types.Operator, ExportHelper):
    """Export selection to a Rome: Total War .cas model"""
    bl_idname = "export_scene.rtw_cas"
    bl_label = "Export Rome: Total War (.cas)"
    bl_options = {'PRESET'}

    filename_ext = ".cas"
    filter_glob: StringProperty(default="*.cas", options={'HIDDEN'})

    version: FloatProperty(
        name="CAS Version", default=3.22, min=2.0, max=4.0,
        description="Version float written to the header")
    global_scale: FloatProperty(
        name="Scale", default=1.0, min=0.0001, max=1000.0)
    use_selection: BoolProperty(
        name="Selected Only", default=False,
        description="Export only selected mesh objects")
    export_animation: BoolProperty(
        name="Export Animation", default=True,
        description="Bake the active armature action into the .cas (20 fps)")
    weighting: EnumProperty(
        name="Weighting",
        items=[('SINGLE', "Single bone", "100% weight to the strongest bone (classic RTW)"),
               ('DUAL', "Dual bone (type 3)", "Up to two bones per vertex (model_flexi_m / Remastered)")],
        default='SINGLE')
    apply_modifiers: BoolProperty(name="Apply Modifiers", default=True)
    file_format: EnumProperty(
        name="Format",
        items=[('ROUNDTRIP', "Round-trip (Blender) — for re-importing",
                "Full-fidelity format that re-imports into Blender perfectly "
                "(keeps skeleton + exact positions of every part). Use this when "
                "you'll open the file again in Blender. NOT loadable by the game."),
               ('VANILLA', "Vanilla (game) — for Rome: Total War",
                "The real RTW .cas the GAME loads. Use this only for the final "
                "in-game model. It carries no skeleton (RTW keeps that "
                "separately), so re-importing a vanilla file needs a "
                "skeletons.dat and won't perfectly round-trip rigid parts.")],
        default='VANILLA')
    export_texture_name: StringProperty(
        name="Texture Name", default="",
        description="Texture file the material references (e.g. unit_x.tga). "
                    "Leave blank to use the object's material image name")
    template_cas: StringProperty(
        name="Template .cas", default="", subtype='FILE_PATH',
        description="VANILLA export: the ORIGINAL unit .cas to inject the edited "
                    "geometry into. Its skeleton/scene/material chunks are kept "
                    "byte-for-byte (the game requires them) and only the mesh is "
                    "replaced. Without this, a vanilla file lacks the scene/node "
                    "chunks and the game won't load it.")

    def execute(self, context):
        depsgraph = context.evaluated_depsgraph_get()
        import math
        # Blender is Z-up; RTW/.cas is Y-up. Apply the inverse of the import
        # rotation (-90 deg X) so exported coordinates are RTW-correct and a
        # round-trip is identity.
        zup_to_yup = mathutils.Matrix.Rotation(math.radians(-90.0), 4, 'X')
        scale_m = mathutils.Matrix.Scale(self.global_scale, 4) @ zup_to_yup

        objs = [o for o in (context.selected_objects if self.use_selection
                            else context.scene.objects) if o.type == 'MESH']
        if not objs:
            self.report({'ERROR'}, "No mesh objects to export")
            return {'CANCELLED'}

        armature = self._find_armature(objs)
        model = cas_format.CasModel(version=self.version)

        bone_index = {}
        if armature:
            order = self._bone_order(armature)
            for bname in order:
                bone_index[bname] = len(model.bones)
            for bname in order:
                bone = armature.data.bones[bname]
                mat = scale_m @ bone.matrix_local
                rot9, trans = _matrix_to_rot_trans(mat)
                parent = (bone_index[bone.parent.name]
                          if bone.parent and bone.parent.name in bone_index
                          else cas_format.NO_PARENT)
                model.bones.append(cas_format.CasBone(
                    name=bname, parent=parent, translation=trans, rotation=rot9))

        for obj in objs:
            grp = self._build_group(obj, depsgraph, scale_m, bone_index)
            if grp.vertices:
                model.groups.append(grp)

        if self.export_animation and armature and armature.animation_data \
                and armature.animation_data.action:
            model.animation = self._bake_animation(context, armature,
                                                    bone_index, scale_m)

        try:
            if self.file_format == 'VANILLA':
                data = self._build_vanilla(objs, depsgraph, scale_m, bone_index,
                                           model)
            else:
                data = cas_format.write_model(model)
            with open(self.filepath, "wb") as f:
                f.write(data)
        except Exception as e:
            self.report({'ERROR'}, "Write failed: %s" % e)
            return {'CANCELLED'}

        self.report({'INFO'}, "Exported %d group(s), %d bone(s)%s"
                     % (len(model.groups), len(model.bones),
                        " + animation" if model.animation else ""))
        return {'FINISHED'}

    # ----------------------------------------------------------------- #
    def _find_armature(self, objs):
        # 1) an Armature modifier on any exported mesh
        for o in objs:
            for m in o.modifiers:
                if m.type == 'ARMATURE' and m.object:
                    return m.object
        # 2) a mesh parented to an armature
        for o in objs:
            p = o.parent
            while p is not None:
                if p.type == 'ARMATURE':
                    return p
                p = p.parent
        # 3) any armature in the scene (single-armature scenes are the norm)
        arms = [ob for ob in bpy.context.scene.objects if ob.type == 'ARMATURE']
        if arms:
            return arms[0]
        return None
        for o in bpy.context.scene.objects:
            if o.type == 'ARMATURE':
                return o
        return None

    def _bone_order(self, armature):
        # Parents must precede children so parent indices are valid.
        ordered = []
        seen = set()

        def visit(b):
            if b.name in seen:
                return
            if b.parent and b.parent.name not in seen:
                visit(b.parent)
            seen.add(b.name)
            ordered.append(b.name)

        for b in armature.data.bones:
            visit(b)
        return ordered

    # ----------------------------------------------------------------- #
    def _clean_group_name(self, obj):
        """Recover the original RTW mesh-group name for export.

        Preference order:
          1) the 'rtw_name' custom property stored on import (exact original),
          2) the object name with a leading 'modelname_' prefix removed and any
             Blender '.001' duplicate suffix stripped.
        """
        rn = obj.get("rtw_name")
        if not rn and obj.data is not None:
            rn = obj.data.get("rtw_name")
        if rn:
            return rn
        nm = obj.name
        nm = re.sub(r"\.\d{3}$", "", nm)          # drop .001/.002 suffixes
        nm = re.sub(r"_lod\d+$", "", nm, flags=re.IGNORECASE)
        # Strip a leading 'modelname_' prefix when the remainder is a
        # recognisable RTW group name. Model stems often contain underscores
        # (e.g. 'gaul_revenger_body'), so test progressively longer prefixes.
        low = nm.lower()
        markers = ("body", "plane", "object", "primary", "secondary",
                   "weapon", "shield", "head", "cloak")
        if "_" in nm:
            parts = nm.split("_")
            for cut in range(len(parts) - 1, 0, -1):
                tail = "_".join(parts[cut:])
                tl = tail.lower()
                if tl.startswith(markers) or any(mk in tl for mk in markers):
                    nm = tail
                    break
        return nm

    def _build_vanilla(self, objs, depsgraph, scale_m, bone_index, model):
        """Build a game-loadable .cas from the Blender mesh objects, following
        Creative Assembly's format (rigid = single-bone, flexi = multi-bone).

        Vertices are written bone-local with Z negated, which is the inverse of
        the importer's world placement. Per-vertex node indices use the model's
        bone order so they match the exported skeleton."""
        from . import skeletons as skel_lib

        # Resolve bind positions for the exported bone order (to make verts
        # bone-local again). This MUST mirror the importer's resolver exactly so
        # export is the precise inverse of import:
        #   * the built-in table is used directly, in its native glTF / +Z
        #     convention (NO Z flip - the old "match Y-up" flip here is what made
        #     re-imported vertices land on the wrong side, since the vertex
        #     formula below already negates Z), and
        #   * any bone missing from the table inherits its parent's resolved
        #     bind (parents precede children in the export order) so a partial
        #     match still subtracts a real bind from every vertex.
        names = [b.name for b in model.bones]
        parents = [b.parent for b in model.bones]
        binds = None
        try:
            sk_name, b = skel_lib.bind_positions_for(names)
            if b and any(x is not None for x in b):
                filled = []
                for i, bp in enumerate(b):
                    if bp is not None:
                        filled.append((bp[0], bp[1], bp[2]))
                    else:
                        p = parents[i] if i < len(parents) \
                            else cas_format.NO_PARENT
                        filled.append(filled[p] if 0 <= p < len(filled)
                                      else (0.0, 0.0, 0.0))
                binds = filled
        except Exception:
            binds = None

        # Z-up -> Y-up rotation only (no scale) to take Blender coords back to
        # RTW space; we then subtract the bind and negate Z per the format.
        import math
        rot = mathutils.Matrix.Rotation(math.radians(-90.0), 4, 'X')
        rot3 = rot.to_3x3()

        texture_name = self.export_texture_name.strip()

        # Resolve template before reading weights so rebuilt parts can map
        # Blender vertex-group names to the REAL RTW node indices in class-0.
        # If the user imported a vanilla CAS with this plugin, the importer
        # stores that source path on the scene and mesh objects; use it when the
        # export panel's Template field is blank.
        template_path = bpy.path.abspath(self.template_cas) if self.template_cas else ""
        if not template_path:
            for o in objs:
                tp = o.get("rtw_source_cas") or (o.data.get("rtw_source_cas") if o.data else "")
                if tp and os.path.isfile(bpy.path.abspath(tp)):
                    template_path = bpy.path.abspath(tp)
                    break
        if not template_path:
            tp = context.scene.get("rtw_last_imported_cas", "")
            if tp and os.path.isfile(bpy.path.abspath(tp)):
                template_path = bpy.path.abspath(tp)

        template_node_index = {}
        template_bytes = None
        if template_path and os.path.isfile(template_path):
            with open(template_path, "rb") as fh:
                template_bytes = fh.read()
            # CASB is the add-on roundtrip format, NOT a game-loadable template.
            if template_bytes[4:8] == b"CASB":
                raise RuntimeError(
                    "Template is a CASB round-trip file, not a vanilla game CAS. "
                    "Use the original unchanged RTW .cas as Template .cas.")
            for i, nm in enumerate(cas_vanilla.read_node_names(template_bytes)):
                template_node_index[nm] = i
                template_node_index[nm.lower()] = i

        out_objs = []
        for obj in objs:
            # IMPORTANT: never use the armature-deformed (posed) mesh for export.
            # We want the rest/bind mesh with vertex groups intact. Temporarily
            # disable armature modifiers so to_mesh() gives undeformed geometry,
            # and always read vertex groups from the ORIGINAL object.
            disabled = []
            for m in obj.modifiers:
                if m.type == 'ARMATURE' and m.show_viewport:
                    m.show_viewport = False
                    disabled.append(m)
            try:
                if self.apply_modifiers and any(
                        m.type != 'ARMATURE' for m in obj.modifiers):
                    mesh = obj.evaluated_get(depsgraph).to_mesh()
                else:
                    mesh = obj.to_mesh()
            finally:
                for m in disabled:
                    m.show_viewport = True
            try:
                mesh.calc_loop_triangles()
            except Exception:
                pass
            mat_world = obj.matrix_world

            # Determine each vertex's bone (strongest weight) in model order.
            # The game's .cas numbers nodes with "Scene Root" at index 0, but the
            # Blender armature starts at bone_pelvis (Scene Root is not a bone),
            # so file_node = blender_bone_index + scene_root_offset.
            has_scene_root_bone = any(
                bb.name.strip().lower() == "scene root" for bb in model.bones)
            scene_root_offset = 0 if has_scene_root_bone else 1
            vg_index_to_bone = {}
            for vg in obj.vertex_groups:
                # Prefer the template's class-0 node order. This is what RTW
                # actually uses for flexi node tables. Falling back to Blender
                # bone_index + Scene Root offset caused many exports to bind the
                # whole body to one node and appear as a static T-pose.
                if vg.name in template_node_index:
                    vg_index_to_bone[vg.index] = template_node_index[vg.name]
                elif vg.name.lower() in template_node_index:
                    vg_index_to_bone[vg.index] = template_node_index[vg.name.lower()]
                elif vg.name in bone_index:
                    vg_index_to_bone[vg.index] = bone_index[vg.name] + scene_root_offset
            # Read weights from the ORIGINAL object's mesh data (vertex groups
            # are reliable there even if to_mesh() dropped them).
            src_vsrc = obj.data.vertices if len(obj.data.vertices) == len(mesh.vertices) else mesh.vertices
            vert_bone = [scene_root_offset] * len(mesh.vertices)
            for vi in range(len(mesh.vertices)):
                vsrc = src_vsrc[vi] if vi < len(src_vsrc) else None
                best_w = -1.0
                best_b = scene_root_offset
                if vsrc is not None:
                    for g in vsrc.groups:
                        if g.group in vg_index_to_bone and g.weight > best_w:
                            best_w = g.weight
                            best_b = vg_index_to_bone[g.group]
                vert_bone[vi] = best_b
            distinct = len(set(vert_bone))
            is_flexi = distinct > 1

            # Build bone-local verts/normals.
            verts = []
            normals = []
            for vi, v in enumerate(mesh.vertices):
                world = mat_world @ v.co            # Blender world
                ry = rot3 @ world                   # -> RTW Y-up world
                bi = vert_bone[vi]
                # binds is indexed by the Blender bone order (pelvis first), but
                # bi is file-numbered (Scene Root at 0); undo the offset to look
                # up the right bind position.
                bind_i = bi - scene_root_offset
                if binds and 0 <= bind_i < len(binds):
                    bx, by, bz = binds[bind_i]
                else:
                    bx = by = bz = 0.0
                # inverse of import: local.x = wx-bx, local.y = wy-by,
                # local.z = -(wz-bz)
                verts.append((ry.x - bx, ry.y - by, -(ry.z - bz)))
                nl = rot3 @ (mat_world.to_3x3() @ v.normal)
                nl.normalize()
                normals.append((nl.x, nl.y, -nl.z))

            # Faces (triangulate) with winding swapped back (import swapped b<->c).
            faces = []
            for tri in mesh.loop_triangles:
                a, b, c = tri.vertices
                faces.append((a, c, b))

            # UVs per vertex (un-flip V back to RTW space).
            uvs = None
            if mesh.uv_layers.active:
                uvs = [(0.0, 0.0)] * len(mesh.vertices)
                uvl = mesh.uv_layers.active.data
                for poly in mesh.polygons:
                    for li in poly.loop_indices:
                        vi = mesh.loops[li].vertex_index
                        u, vv = uvl[li].uv
                        uvs[vi] = (u, 1.0 - vv)

            nm = obj.get("rtw_name") or self._clean_group_name(obj)
            if not texture_name:
                # try the object's material image
                for ms in obj.data.materials:
                    if ms and ms.get("rtw_texture"):
                        texture_name = os.path.basename(ms["rtw_texture"]); break

            out_objs.append(dict(
                name=nm, verts=verts, normals=normals, faces=faces, uvs=uvs,
                bone_table=vert_bone, is_flexi=is_flexi, mtrl_index=0))
            try:
                obj.evaluated_get(depsgraph).to_mesh_clear()
            except Exception:
                pass

        # Diagnostics: how many parts carry real (multi-bone) weighting?
        total_bones = set()
        for o in out_objs:
            total_bones.update(o["bone_table"])
        n_flexi = sum(1 for o in out_objs if o["is_flexi"])
        print("[RTW] Vanilla export: %d object(s), %d flexi (multi-bone), "
              "%d distinct nodes used." % (len(out_objs), n_flexi,
                                           len(total_bones)))
        if len(total_bones) <= 1:
            self.report({'WARNING'},
                        "Exported geometry is bound to a single node — the unit "
                        "will be static (T-pose) in game. Make sure the meshes "
                        "have an Armature modifier and vertex weights to the "
                        "bones before exporting.")

        # ---- assemble the game file ----
        # The game requires chunks (notably the class-0 scene/node-graph with
        # the skeleton) that cannot be synthesised reliably. So inject the edited
        # geometry into the ORIGINAL .cas, keeping every non-geometry chunk
        # verbatim. Without a template we cannot produce a loadable file.
        if template_bytes is not None:
            return self._inject_into_template(template_bytes, out_objs)

        raise RuntimeError(
            "Vanilla/game CAS export requires Template .cas. Import the original "
            "unchanged RTW CAS first, or set Template .cas to that original file. "
            "The add-on will not write a fake no-skeleton CAS because RTW crashes "
            "with 'Scene data chunk not found'.")

    def _inject_into_template(self, tdata, out_objs):
        """Rebuild only the rigid/flexi geometry from the edited Blender meshes
        and splice it into the original .cas, preserving the skeleton, scene and
        material chunks exactly. Objects are matched to the template by name: a
        topology-preserving edit reuses the template part's structure (per-vertex
        bone table, vertex colours, origin) and just swaps in the new positions/
        normals/UVs; a vertex-count change is rebuilt best-effort."""
        import struct as _s
        node_names = cas_vanilla.read_node_names(tdata)
        n_nodes = len(node_names)
        t_rigids, t_flexis, rt, ft = cas_vanilla.parse_geometry(tdata)

        def cname(b):
            return b.rstrip(b"\x00").decode("latin-1", "replace")
        t_by_name = {}
        for ob in t_rigids + t_flexis:
            template_name = cname(ob["name"])
            t_by_name[template_name] = ob
            t_by_name[template_name.lower()] = ob

        def lookup_template(name):
            if name in t_by_name:
                return t_by_name[name]
            low = name.lower()
            if low in t_by_name:
                return t_by_name[low]
            stripped = re.sub(r"_lod\d+$", "", low, flags=re.IGNORECASE)
            return t_by_name.get(stripped)

        def packf(seq, comps):
            flat = [c for item in seq for c in item]
            return _s.pack("<%df" % (comps * len(seq)), *flat)

        new_rigids, new_flexis = [], []
        for o in out_objs:
            nm = o["name"]
            nv = len(o["verts"]); nf = len(o["faces"])
            tob = lookup_template(nm)
            is_flexi = (tob["kind"] == "flexi") if tob else bool(o.get("is_flexi"))
            verts_b = packf(o["verts"], 3)
            norms_b = packf(o["normals"], 3)
            faces_b = _s.pack("<%dH" % (3 * nf),
                              *[c for f in o["faces"] for c in f])

            if tob is not None and tob["nv"] == nv and tob["nf"] == nf:
                # Topology preserved: keep the template part's structure and
                # only replace the geometry the user actually edited.
                d = dict(tob)
                d["verts"] = verts_b
                d["norms"] = norms_b
                d["faces"] = faces_b
                if tob["tex"] and o.get("uvs"):
                    d["uvs"] = packf(o["uvs"], 2)
            else:
                # Rebuilt part (vertex count changed or new object).
                name_b = nm.encode("latin-1", "replace") + b"\x00"
                tex = 1 if o.get("uvs") else (tob["tex"] if tob else 0)
                cv = tob["cv"] if tob else 0
                uvs_b = packf(o["uvs"], 2) if (tex and o.get("uvs")) else b""
                cverts_b = (b"\xff\xff\xff\xff" * nv) if cv else b""
                origin = (tob["origin"] if tob else
                          (b"\x00" * 28 if is_flexi
                           else _s.pack("<7f", 0, 0, 0, 1, 0, 0, 0)))
                props = tob["props"] if tob else b"\x00"
                grp = tob["grp"] if (tob and tob["grp"] is not None) else b"\x00"
                mtrl = tob["mtrl"] if tob else 0
                bt = o.get("bone_table") or [0] * nv
                if is_flexi:
                    nodes = [int(b) if 0 <= int(b) < n_nodes else 0 for b in bt]
                    node = None
                else:
                    nodes = None
                    node = (tob["node"] if tob
                            else (max(set(bt), key=bt.count) if bt else 0))
                d = dict(kind="flexi" if is_flexi else "rigid", name=name_b,
                         props=props, grp=grp, node=node, origin=origin,
                         nv=nv, nf=nf, tex=tex, cv=cv, nodes=nodes,
                         verts=verts_b, norms=norms_b, faces=faces_b,
                         mtrl=mtrl, uvs=uvs_b, cverts=cverts_b, excl=0)
            (new_flexis if is_flexi else new_rigids).append(d)

        print("[RTW] Injected %d rigid + %d flexi part(s) into template %s"
              % (len(new_rigids), len(new_flexis),
                 os.path.basename(self.template_cas)))
        return cas_vanilla.inject_geometry(tdata, new_rigids, new_flexis, rt, ft)

    def _build_group(self, obj, depsgraph, scale_m, bone_index):
        eval_obj = obj.evaluated_get(depsgraph) if self.apply_modifiers else obj
        mesh = eval_obj.to_mesh()
        try:
            mesh.calc_loop_triangles()
            try:
                mesh.calc_normals_split()
            except Exception:
                pass

            uv_layer = mesh.uv_layers.active.data if mesh.uv_layers.active else None

            # Texture reference: from material custom prop or image name.
            texture = ""
            if obj.data.materials and obj.data.materials[0]:
                mat = obj.data.materials[0]
                texture = mat.get("rtw_texture", "")
                if not texture and mat.use_nodes:
                    for n in mat.node_tree.nodes:
                        if n.type == 'TEX_IMAGE' and n.image:
                            texture = os.path.basename(n.image.filepath) or n.image.name
                            break

            group_name = self._clean_group_name(obj)
            grp = cas_format.CasGroup(name=group_name, texture=texture,
                                      is_type3=(self.weighting == 'DUAL'))

            # Build per-loop vertices (split by UV/normal like an FBX export).
            vg_names = {vg.index: vg.name for vg in obj.vertex_groups}
            loop_map = {}
            mat_world = scale_m @ obj.matrix_world

            for tri in mesh.loop_triangles:
                tri_indices = []
                for li in tri.loops:
                    loop = mesh.loops[li]
                    vidx = loop.vertex_index
                    co = mat_world @ mesh.vertices[vidx].co
                    nrm = (mat_world.to_3x3() @ loop.normal).normalized()
                    uv = uv_layer[li].uv if uv_layer else (0.0, 0.0)
                    uvf = (uv[0], 1.0 - uv[1])
                    key = (vidx, round(uvf[0], 6), round(uvf[1], 6),
                           round(nrm.x, 4), round(nrm.y, 4), round(nrm.z, 4))
                    if key not in loop_map:
                        b0, w0, b1, w1 = self._vertex_weights(
                            mesh.vertices[vidx], vg_names, bone_index)
                        cv = cas_format.CasVertex(
                            co=(co.x, co.y, co.z),
                            normal=(nrm.x, nrm.y, nrm.z),
                            uv=uvf, bone0=b0, weight0=w0, bone1=b1, weight1=w1)
                        loop_map[key] = len(grp.vertices)
                        grp.vertices.append(cv)
                    tri_indices.append(loop_map[key])
                grp.faces.append(tuple(tri_indices))
            return grp
        finally:
            eval_obj.to_mesh_clear()

    def _vertex_weights(self, vert, vg_names, bone_index):
        weights = []
        for g in vert.groups:
            bname = vg_names.get(g.group)
            if bname in bone_index and g.weight > 0:
                weights.append((bone_index[bname], g.weight))
        weights.sort(key=lambda x: -x[1])
        if not weights:
            return (0, 1.0, -1, 0.0)
        if self.weighting == 'SINGLE' or len(weights) == 1:
            return (weights[0][0], 1.0, -1, 0.0)
        # Dual-bone: take top two, renormalise.
        (b0, w0), (b1, w1) = weights[0], weights[1]
        s = w0 + w1
        return (b0, w0 / s, b1, w1 / s)

    # ----------------------------------------------------------------- #
    def _bake_animation(self, context, armature, bone_index, scale_m):
        scene = context.scene
        anim = cas_format.CasAnimation(fps=cas_format.RTW_ANIM_FPS)
        order = self._bone_order(armature)
        n = len(order)

        has_pos = [False] * n
        frames_data = []
        for f in range(scene.frame_start, scene.frame_end + 1):
            scene.frame_set(f)
            rots, transes = [], []
            for bname in order:
                pb = armature.pose.bones.get(bname)
                if pb is None:
                    rots.append((1, 0, 0, 0, 1, 0, 0, 0, 1))
                    transes.append((0, 0, 0))
                    continue
                m = scale_m @ pb.matrix
                rot9, t = _matrix_to_rot_trans(m)
                rots.append(rot9)
                transes.append(t)
            frames_data.append((rots, transes))

        # Detect which bones actually move (carry position animation).
        if frames_data:
            base = frames_data[0][1]
            for fi in range(1, len(frames_data)):
                for bi in range(n):
                    if any(abs(frames_data[fi][1][bi][k] - base[bi][k]) > 1e-5
                           for k in range(3)):
                        has_pos[bi] = True

        anim.bones_with_position = has_pos
        for rots, transes in frames_data:
            anim.frames.append(cas_format.CasAnimFrame(
                rotations=rots, translations=transes))
        return anim


def menu_func_export(self, context):
    from . import get_icon_id
    self.layout.operator(ExportCAS.bl_idname,
                         text="Rome: Total War (.cas)",
                         icon_value=get_icon_id("julii"))
