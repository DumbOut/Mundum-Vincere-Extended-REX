# RTW CAS Importing, Kitbashing, and LOD Guide

This add-on is built around one important rule: final game exports should inject your edited mesh back into the original vanilla `.cas` template. The template preserves the scene, skeleton, material, node, and rigid attachment chunks that Rome: Total War expects.

## Import Setup

1. Install the zip in Blender through Preferences > Add-ons > Install.
2. Import the original unit `.cas` first.
3. Keep the original `.cas` path as the export template. The importer stores this automatically on imported objects, but you can also set it manually in the export panel.
4. Do your kitbash work in the imported scene instead of starting from an empty file.

## Kitbashing Rules

1. Keep imported object custom properties such as `rtw_name`, `rtw_part_type`, `rtw_weapon`, and `rtw_material_index`.
2. For swords, shields, and other rigid attachments, do not apply transforms after positioning unless you know the template node still matches.
3. Keep attachment objects parented and weighted to the same weapon/hand node they came from.
4. If you duplicate a part, copy the source object first so the RTW metadata follows it.
5. Export with the original game `.cas` as Template `.cas`, not a round-trip CASB file.

## Generating LODs

The Generate LODs operator creates in-place `_lod0`, `_lod1`, `_lod2`, and `_lod3` copies from the selected mesh objects.

- `_lod0` is a clean copy with no decimation.
- `_lod1`, `_lod2`, and `_lod3` use Blender Decimate ratios from the operator settings.
- Decimation is applied immediately.
- Duplicate vertices are merged with a `0.000001` threshold.
- Loose vertices/edges are removed.
- LOD1+ meshes are collapsed to single-bone weights, which matches the classic RTW LOD expectation.

This follows the same useful steps as the Rome Remastered LOD generator workflow: decimate, apply the modifier, remove doubles, delete loose geometry, strip `_lod0` from output naming, and limit LOD bone weights.

## Preventing Moving Swords and Attachments

The LOD tool now keeps duplicate object `matrix_world`, parent, and RTW metadata unchanged. It does not move preview LODs sideways. That prevents offset duplicates from being exported as if their shifted preview position was real geometry.

If an attachment still moves in-game:

1. Make sure the object kept its original `rtw_name`.
2. Make sure the original vanilla `.cas` is used as Template `.cas`.
3. Keep the attachment's vertex group/node the same as the imported source part.
4. Prefer editing the attachment mesh in place over replacing it with a differently named object.

## Export Checklist

1. Select only the meshes you want in the target LOD, or leave selection export off for the whole scene.
2. Choose `Vanilla (game)`.
3. Set Template `.cas` to the original unchanged unit CAS.
4. Export each LOD to the filename your mod's `descr_model_battle.txt` references.
5. Check swords, shields, banners, and mounts in-game before batch-exporting a whole unit family.
