RTW / OpenRTW / REX Faction Creator

1. Install Node.js if you do not have it.
2. Copy this folder into your mod or VS Code workspace.
3. Edit faction.config.json. Set modDataPath to your mod's data folder.
4. Double-click Run_Faction_Creator.bat, or run:
   node faction_creator.mjs --config faction.config.json
5. The tool creates .bak backups before editing files.

Current capabilities:
- Adds descr_sm_factions block.
- Adds banner/building banner blocks.
- Adds DMB/EDU ownership to existing units.
- Copies slave UI unit cards into faction folders.
- Adds names to descr_names and text/names.
- Adds temple blocks to EDB/UI/text strings.
- Adds basic descr_strat faction block.
- Adds win conditions and campaign text.
- Adds faction to playable section when found.

Notes:
- It is intentionally conservative: it appends marked blocks and skips if faction markers already exist.
- It does not create new models or new unit textures.
- It does not edit map_regions.tga.
- Coordinates currently default to x 0 y 0 if exact region parsing is not implemented for your map format.
