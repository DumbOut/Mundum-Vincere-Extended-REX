#!/usr/bin/env node
/* RTW/OpenRTW/REX Faction Creator - non-Python Node.js CLI */
import fs from 'fs';
import path from 'path';

const args = process.argv.slice(2);
const configPath = valueAfter('--config') || 'faction.config.json';
function valueAfter(flag){ const i=args.indexOf(flag); return i>=0 ? args[i+1] : null; }
const cfg = JSON.parse(fs.readFileSync(configPath,'utf8'));
const DATA = path.resolve(cfg.modDataPath || './data');
const faction = cfg.faction;
const markerStart = `;; ${faction} START`;
const markerEnd = `;; ${faction} END`;
const report = [];

function p(...parts){ return path.join(DATA, ...parts); }
function exists(file){ return fs.existsSync(file); }
function read(file){ return exists(file) ? fs.readFileSync(file,'utf8') : ''; }
function write(file, text){
  fs.mkdirSync(path.dirname(file), {recursive:true});
  if (cfg.backup && exists(file) && !exists(file+'.bak')) fs.copyFileSync(file, file+'.bak');
  if (!cfg.dryRun) fs.writeFileSync(file, text);
  report.push(`PATCHED ${path.relative(DATA,file)}`);
}
function appendOnce(file, block){
  let text = read(file);
  if (text.includes(`faction\t\t\t\t\t\t\t${faction}`) || text.includes(markerStart) || text.includes(faction)) { report.push(`SKIPPED existing ${path.relative(DATA,file)}`); return; }
  write(file, text.replace(/\s*$/, '\n\n') + block + '\n');
}
function patchFile(file, patcher){
  const old = read(file); if (!old) { report.push(`MISSING ${path.relative(DATA,file)}`); return; }
  const next = patcher(old);
  if (next !== old) write(file,next); else report.push(`UNCHANGED ${path.relative(DATA,file)}`);
}
function color(c){ return `red ${c.red}, green ${c.green}, blue ${c.blue}`; }
function block(s){ return `${markerStart}\n${s.trimEnd()}\n${markerEnd}\n`; }
function factionUpper(){ return faction.toUpperCase(); }

function descrSmFactions(){
  appendOnce(p('descr_sm_factions.txt'), block(`faction\t\t\t\t\t\t\t${faction}
culture\t\t\t\t\t\t\t${cfg.culture}
symbol\t\t\t\t\t\t\t${cfg.symbol}
rebel_symbol\t\t\t\t\t${cfg.rebelSymbol || cfg.symbol}
primary_colour\t\t\t\t\t${color(cfg.primaryColour)}
secondary_colour\t\t\t\t${color(cfg.secondaryColour)}
loading_logo\t\t\t\t\t${cfg.loadingLogo}
standard_index\t\t\t\t\t${cfg.standardIndex}
logo_index\t\t\t\t\t\t${cfg.logoIndex || 'FACTION_LOGO_'+factionUpper()}
small_logo_index\t\t\t\t${cfg.smallLogoIndex || 'SMALL_FACTION_LOGO_'+factionUpper()}
triumph_value\t\t\t\t\t5
intro_movie\t\t\t\t\t\tfmv/intros/julii_intro_final.wmv
victory_movie\t\t\t\t\tfmv/victory/julii_outro_320x240.wmv
defeat_movie\t\t\t\t\tfmv/lose/julii_eliminated.wmv
death_movie\t\t\t\t\t\tfmv/death/death_julii_grass_320x240.wmv
custom_battle_availability\tyes
can_sap\t\t\t\t\t\t\tyes
prefers_naval_invasions\t\tno`));
}
function simpleTextFiles(){
  appendOnce(p('descr_banners.txt'), block(`banner campaign_banner_${faction}
model\t\t\t\t\t\tmodels_strat/banner.CAS
texture\t\t\t\t\t\tmodels_strat/textures/${faction}_campaign_banner.tga

banner battle_banner_${faction}
model\t\t\t\t\t\tmodels_unit/banner.CAS
texture\t\t\t\t\t\tmodels_unit/textures/${faction}_battle_banner.tga`));
  appendOnce(p('descr_building_battle.txt'), block(`building_banner\t\t\t${faction}
texture\t\t\t\t\tmodels_unit/textures/${faction}_battle_banner.tga`));
  appendOnce(p('descr_lbc_db.txt'), block(`${faction}`));
  appendOnce(p('descr_offmap_models.txt'), block(`${faction}`));
}
function patchOwnershipList(file, unitNames){
  patchFile(file, txt => {
    let out = txt;
    for (const u of unitNames) {
      const re = new RegExp(`(type\\s+${escapeReg(u)}[\\s\\S]*?ownership\\s+)([^\\n]+)`, 'i');
      out = out.replace(re, (m,a,b)=> b.includes(faction) ? m : `${a}${b.trim()}, ${faction}`);
    }
    return out;
  });
}
function escapeReg(s){ return s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'); }
function unitCards(){
  for (const dir of ['units','unit_info']) {
    const from = p('ui',dir,cfg.copyUnitCardsFrom || 'slave');
    const to = p('ui',dir,faction);
    fs.mkdirSync(to,{recursive:true});
    if (!exists(from)) { report.push(`MISSING card source ui/${dir}/${cfg.copyUnitCardsFrom}`); continue; }
    for (const f of fs.readdirSync(from)) {
      const low = f.toLowerCase();
      const wanted = cfg.units.some(u => low.includes(u.replaceAll(' ','_').toLowerCase()) || low.includes(u.replaceAll(' ','').toLowerCase()));
      if (wanted || cfg.copyAllSlaveCards) fs.copyFileSync(path.join(from,f), path.join(to,f));
    }
    report.push(`COPIED cards to ui/${dir}/${faction}`);
  }
}
function names(){
  appendOnce(p('descr_names.txt'), block(`names ${faction}
\tcharacters
${cfg.names.men.map(n=>'\t\t'+n).join('\n')}

\tsurnames
${cfg.names.surnames.map(n=>'\t\t'+n).join('\n')}

\twomen
${cfg.names.women.map(n=>'\t\t'+n).join('\n')}`));
  appendOnce(p('text','names.txt'), `{${faction}_name}\t\t${prettyFaction()}\n` + cfg.names.men.map(n=>`{${n}}\t\t${n}`).join('\n') + '\n' + cfg.names.women.map(n=>`{${n}}\t\t${n}`).join('\n') + '\n' + cfg.names.surnames.map(n=>`{${n}}\t\t${n}`).join('\n'));
}
function prettyFaction(){ return faction.split('_').map(x=>x[0]?.toUpperCase()+x.slice(1)).join(' '); }
function buildings(){
 const templeBlocks = cfg.temples.map(t=>`\tbuilding ${t.id}\n\t{\n\t\tlevels ${t.id}_shrine ${t.id}_temple\n\t\t{\n\t\t\t${t.id}_shrine requires factions { ${faction}, }\n\t\t\t{\n${t.effects.map(e=>'\t\t\t\t'+e).join('\n')}\n\t\t\t}\n\t\t\t${t.id}_temple requires factions { ${faction}, }\n\t\t\t{\n${t.effects.map(e=>'\t\t\t\t'+e).join('\n')}\n\t\t\t}\n\t\t}\n\t}`).join('\n\n');
 appendOnce(p('export_descr_buildings.txt'), block(templeBlocks));
 appendOnce(p('descr_ui_buildings.txt'), block(cfg.temples.map(t=>`${t.id}_shrine\t\tdata/ui/buildings/${faction}/${t.id}_shrine.tga
${t.id}_temple\t\tdata/ui/buildings/${faction}/${t.id}_temple.tga`).join('\n')));
 appendOnce(p('text','export_buildings.txt'), cfg.temples.map(t=>`{${t.id}_shrine} ${t.displayName}
{${t.id}_shrine_desc} ${t.description}
{${t.id}_temple} Great ${t.displayName}
{${t.id}_temple_desc} ${t.description}`).join('\n'));
}
function descrStrat(){
 const region = cfg.regions[0];
 appendOnce(p('world','maps','base','descr_strat.txt'), block(`faction\t${faction}, balanced smith
ai_label\tdefault

settlement
{
\tlevel large_town
\tregion ${region}
\tyear_founded 0
\tpopulation 2400
\tplan_set default_set
\tfaction_creator ${faction}
\tbuilding
\t{
\t\ttype core_building governors_house
\t}
\tbuilding
\t{
\t\ttype defenses wooden_pallisade
\t}
}

character\tWahb al-Thamudi, named character, male, leader, age 42, x 0, y 0
traits GoodCommander 1 , GoodAdministrator 1 , PublicFaith 1
ancillaries clear
army
unit\t\tarab infantry\t\t\texp 1 armour 0 weapon_lvl 0
unit\t\tarab archers\t\t\texp 1 armour 0 weapon_lvl 0
unit\t\teastern infantry\t\texp 0 armour 0 weapon_lvl 0

character\tZayd al-Hegri, named character, male, heir, age 24, x 0, y 0
traits GoodCommander 1
ancillaries clear
army
unit\t\tdesert cavalry\t\t\texp 0 armour 0 weapon_lvl 0

relative\tWahb al-Thamudi,\tZayd al-Hegri,\tend`));
}
function winConditions(){ appendOnce(p('world','maps','base','descr_win_conditions.txt'), block(`${faction}
\tshort_campaign\toutlive_factions\t${cfg.clientKingdomOf || 'romans_senate'}
\tlong_campaign\toutlive_factions\t${cfg.clientKingdomOf || 'romans_senate'}`)); }
function campaignDesc(){ appendOnce(p('text','campaign_descriptions.txt'), `{IMPERIAL_CAMPAIGN_${factionUpper()}_TITLE}${prettyFaction()}\n{IMPERIAL_CAMPAIGN_${factionUpper()}_DESCR}${description32()}`); }
function expandedBi(){ appendOnce(p('text','expanded_bi.txt'), `{${factionUpper()}_DESCR}\t\t${prettyFaction()}\n{${factionUpper()}_STRENGTHS}\t\tDesert trade, loyal client diplomacy, eastern auxiliaries, and strong local temples.`); }
function description32(){ return Array.from({length:32},(_,i)=>`The ${prettyFaction()} represent a northern Arabian desert kingdom rooted in caravan settlements, oasis control, and the memory of ancient Thamudic peoples before 270 BC. Paragraph ${i+1} describes their trade routes, local clans, sacred stones, Dushara and al-Lat cults, relations with Nabataean, Lihyanite, Dedanite, Egyptian, Persian, and Hellenistic powers, and their client relationship with SPQR in this campaign setting.`).join('\\n\\n'); }
function playable(){
 patchFile(p('world','maps','campaign','imperial_campaign','descr_strat.txt'), txt => {
   if (txt.includes(`\n\t${faction}`) || txt.includes(`\n${faction}\n`)) return txt;
   return txt.replace(/(playable\s*\n)/i, `$1\t${faction}\n`);
 });
}
function main(){
 descrSmFactions(); simpleTextFiles(); patchOwnershipList(p('export_descr_unit.txt'), cfg.units); patchOwnershipList(p('descr_model_battle.txt'), cfg.units); unitCards(); names(); buildings(); descrStrat(); winConditions(); campaignDesc(); expandedBi(); playable();
 fs.writeFileSync(path.resolve('faction_creator_report.txt'), report.join('\n'));
 console.log(report.join('\n'));
 console.log('\nDone. Check faction_creator_report.txt. Backups use .bak files.');
}
main();
