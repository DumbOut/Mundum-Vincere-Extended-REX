@echo off
cd /d %~dp0
node faction_creator.mjs --config faction.config.json
pause
